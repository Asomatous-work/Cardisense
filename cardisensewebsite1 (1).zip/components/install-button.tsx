"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { useDeviceType } from "@/hooks/use-device-type"

// Define download URLs for different platforms
const DOWNLOAD_LINKS = {
  android: "/downloads/cardisense-app.apk",
  ios: "https://apps.apple.com/app/cardisense/id123456789", // This would be your App Store link
  macos: "/downloads/cardisense-app.dmg",
  windows: "/downloads/cardisense-setup.exe",
  linux: "/downloads/cardisense-app.AppImage",
}

export function InstallButton() {
  const { deviceType, isMobile, isTablet } = useDeviceType()
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [isInstallable, setIsInstallable] = useState(true)
  const [isInstalled, setIsInstalled] = useState(false)
  const [isStandalone, setIsStandalone] = useState(false)
  const [isVisible, setIsVisible] = useState(true)
  const autoHideTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const startYRef = useRef<number | null>(null)

  // Add these new state variables after the existing state declarations
  const [tapCount, setTapCount] = useState(0)
  const [isIOS, setIsIOS] = useState(false)
  const [isAndroid, setIsAndroid] = useState(false)
  const [isMacOS, setIsMacOS] = useState(false)
  const [isWindows, setIsWindows] = useState(false)
  const [showIOSGuide, setShowIOSGuide] = useState(false)
  const [showDownloadOptions, setShowDownloadOptions] = useState(false)
  const tapTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // New state variables for platform detection and download dialog
  const [platform, setPlatform] = useState<"android" | "ios" | "macos" | "windows" | "linux" | "unknown">("unknown")
  const [showDownloadDialog, setShowDownloadDialog] = useState(false)
  const [downloadProgress, setDownloadProgress] = useState(0)
  const [isDownloading, setIsDownloading] = useState(false)
  const [downloadError, setDownloadError] = useState<string | null>(null)

  // Define isAndroidWebView function outside useEffect to avoid duplicate declaration
  const isAndroidWebView = () => {
    return (
      typeof window !== "undefined" &&
      /Android/.test(window.navigator.userAgent) &&
      /wv/.test(window.navigator.userAgent)
    )
  }

  useEffect(() => {
    // Check if the app is running in standalone mode (installed)
    // Update the checkStandalone function to include more robust detection methods
    const checkStandalone = () => {
      // Check multiple ways to detect if app is installed
      const isRunningStandalone =
        window.matchMedia("(display-mode: standalone)").matches ||
        (window.navigator as any).standalone ||
        document.referrer.includes("android-app://") ||
        window.navigator.userAgent.includes("wv") || // Android WebView
        window.navigator.userAgent.includes("CARDISENSE") || // Custom APK user agent
        !!document.querySelector('meta[name="apple-mobile-web-app-capable"][content="yes"]')

      console.log("Standalone detection:", {
        mediaQuery: window.matchMedia("(display-mode: standalone)").matches,
        navigatorStandalone: (window.navigator as any).standalone,
        androidApp: document.referrer.includes("android-app://"),
        webView: window.navigator.userAgent.includes("wv"),
        userAgent: window.navigator.userAgent,
      })

      setIsStandalone(isRunningStandalone)

      if (isRunningStandalone) {
        console.log("App is running in standalone/installed mode")
        setIsInstalled(true)
        setIsVisible(false) // Ensure button is hidden when installed
      }
    }

    if (typeof window !== "undefined") {
      // Check standalone status on initial load
      checkStandalone()

      // Add this inside the useEffect, near the beginning after the checkStandalone function
      // Detect device OS
      const detectDeviceOS = () => {
        const userAgent = navigator.userAgent.toLowerCase()

        const isIOSDevice = /iphone|ipad|ipod/.test(userAgent) && !(window as any).MSStream
        const isAndroidDevice = /android/.test(userAgent)
        const isMacOSDevice = /macintosh|mac os x/.test(userAgent) && !isIOSDevice
        const isWindowsDevice = /windows/.test(userAgent)

        setIsIOS(isIOSDevice)
        setIsAndroid(isAndroidDevice)
        setIsMacOS(isMacOSDevice)
        setIsWindows(isWindowsDevice)

        console.log("Device detection:", { isIOSDevice, isAndroidDevice, isMacOSDevice, isWindowsDevice })
      }

      // Call the device detection function in useEffect
      detectDeviceOS()

      // Listen for the beforeinstallprompt event
      const handleBeforeInstallPrompt = (e: Event) => {
        // Prevent Chrome 67 and earlier from automatically showing the prompt
        e.preventDefault()
        // Stash the event so it can be triggered later
        setDeferredPrompt(e)
        setIsInstallable(true)
        console.log("Install prompt captured and ready")
      }

      window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

      // Listen for app installed event
      window.addEventListener("appinstalled", () => {
        setIsInstalled(true)
        setIsInstallable(false)
        setDeferredPrompt(null)
        console.log("App was installed")
      })

      // Listen for display mode changes
      window.matchMedia("(display-mode: standalone)").addEventListener("change", (e) => {
        setIsStandalone(e.matches)
        if (e.matches) {
          setIsInstalled(true)
        }
      })

      // Set up touch event listeners for pull-down gesture
      const handleTouchStart = (e: TouchEvent) => {
        startYRef.current = e.touches[0].clientY
      }

      const handleTouchMove = (e: TouchEvent) => {
        if (startYRef.current === null) return

        const currentY = e.touches[0].clientY
        const diff = currentY - startYRef.current

        // If pulled down more than 60px from the top of the page and we're near the top
        if (diff > 60 && startYRef.current < 100) {
          setIsVisible(true)
          // Reset the auto-hide timer
          if (autoHideTimeoutRef.current) {
            clearTimeout(autoHideTimeoutRef.current)
          }
          startAutoHideTimer()
        }
      }

      const handleTouchEnd = () => {
        startYRef.current = null
      }

      document.addEventListener("touchstart", handleTouchStart)
      document.addEventListener("touchmove", handleTouchMove)
      document.addEventListener("touchend", handleTouchEnd)

      // Start the auto-hide timer
      startAutoHideTimer()

      // Check if running in Android WebView
      if (isAndroidWebView()) {
        console.log("Running in Android WebView, hiding install button")
        setIsInstalled(true)
        setIsVisible(false)
      }

      return () => {
        if (typeof window !== "undefined") {
          window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
          window.removeEventListener("appinstalled", () => {})
          window.matchMedia("(display-mode: standalone)").removeEventListener("change", () => {})
          document.removeEventListener("touchstart", handleTouchStart)
          document.removeEventListener("touchmove", handleTouchMove)
          document.removeEventListener("touchend", handleTouchEnd)

          if (autoHideTimeoutRef.current) {
            clearTimeout(autoHideTimeoutRef.current)
          }
          if (tapTimeoutRef.current) {
            clearTimeout(tapTimeoutRef.current)
          }
        }
      }
    }
  }, [])

  // Function to start the auto-hide timer
  const startAutoHideTimer = () => {
    if (autoHideTimeoutRef.current) {
      clearTimeout(autoHideTimeoutRef.current)
    }

    // Hide the button after 10 seconds
    autoHideTimeoutRef.current = setTimeout(() => {
      setIsVisible(false)
    }, 10000)
  }

  // Handle direct download based on device type
  const handleDirectDownload = () => {
    if (isAndroid) {
      // Provide direct APK download link for Android
      window.location.href = "https://cardisense.vercel.app/downloads/cardisense.apk"
    } else if (isIOS) {
      // Show iOS installation guide
      setShowIOSGuide(true)
    } else if (isMacOS) {
      // Provide DMG download for macOS
      window.location.href = "https://cardisense.vercel.app/downloads/cardisense.dmg"
    } else if (isWindows) {
      // Provide EXE download for Windows
      window.location.href = "https://cardisense.vercel.app/downloads/cardisense-setup.exe"
    } else {
      // Show download options for other platforms
      setShowDownloadOptions(true)
    }
  }

  // Replace the handleInstallClick function with this updated version
  const handleInstallClick = async () => {
    // For direct download based on device type
    if (isIOS || isAndroid || isMacOS || isWindows) {
      handleDirectDownload()
      return
    }

    // For browser-based installation
    if (deferredPrompt) {
      // Show the install prompt
      deferredPrompt.prompt()

      // Wait for the user to respond to the prompt
      const { outcome } = await deferredPrompt.userChoice

      // We've used the prompt, and can't use it again, throw it away
      setDeferredPrompt(null)

      if (outcome === "accepted") {
        console.log("User accepted the install prompt")
      } else {
        console.log("User dismissed the install prompt")
      }
    } else {
      // If no deferred prompt is available, show download options
      setShowDownloadOptions(true)
    }
  }

  // Add this function to close the iOS guide
  const closeIOSGuide = () => {
    setShowIOSGuide(false)
  }

  // Add this function to close the download options
  const closeDownloadOptions = () => {
    setShowDownloadOptions(false)
  }

  // Update the return statement to include the iOS installation guide
  // Replace the entire return statement with this updated version
  // Hide the button if the app is already installed, running in standalone mode, or in a WebView
  if (isInstalled || isStandalone || (typeof window !== "undefined" && isAndroidWebView())) {
    console.log("Install button hidden due to detected installation")
    return null
  }

  // Show the button with animation
  return (
    <>
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Button
              onClick={handleInstallClick}
              className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 relative"
              size={isMobile ? "sm" : "default"}
            >
              <Download className="h-4 w-4 mr-2" />
              {isMobile ? "Install" : "Install App"}
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* iOS Installation Guide Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-slate-800 border border-white/20 rounded-xl max-w-sm w-full p-6 shadow-2xl"
          >
            <h3 className="text-xl font-bold mb-4 text-white">Install on iOS</h3>

            <div className="space-y-4">
              <div className="bg-white/10 rounded-lg p-4">
                <p className="text-white/80 text-sm mb-2">To install CARDISENSE on your iOS device:</p>
                <ol className="list-decimal pl-5 text-white/80 text-sm space-y-2">
                  <li>
                    Tap the <span className="inline-block px-2 py-1 bg-white/20 rounded text-white">Share</span> button
                    in Safari
                  </li>
                  <li>
                    Scroll down and tap{" "}
                    <span className="inline-block px-2 py-1 bg-white/20 rounded text-white">Add to Home Screen</span>
                  </li>
                  <li>
                    Tap <span className="inline-block px-2 py-1 bg-white/20 rounded text-white">Add</span> in the
                    top-right corner
                  </li>
                </ol>
              </div>

              <div className="flex justify-center">
                <img
                  src="/ios-install-guide.svg"
                  alt="iOS Installation Steps"
                  className="h-40 object-contain bg-white/5 rounded-lg p-2"
                  onError={(e) => {
                    // Fallback if image doesn't exist
                    ;(e.target as HTMLImageElement).style.display = "none"
                  }}
                />
              </div>
            </div>

            <Button
              onClick={closeIOSGuide}
              className="w-full mt-6 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500"
            >
              Got it
            </Button>
          </motion.div>
        </div>
      )}

      {/* Download Options Modal */}
      {showDownloadOptions && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-slate-800 border border-white/20 rounded-xl max-w-sm w-full p-6 shadow-2xl"
          >
            <h3 className="text-xl font-bold mb-4 text-white">Download CARDISENSE</h3>

            <div className="space-y-3">
              <Button
                onClick={() => {
                  window.location.href = "https://cardisense.vercel.app/downloads/cardisense.apk"
                  closeDownloadOptions()
                }}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500"
              >
                Download for Android (APK)
              </Button>

              <Button
                onClick={() => {
                  window.location.href = "https://cardisense.vercel.app/downloads/cardisense.dmg"
                  closeDownloadOptions()
                }}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500"
              >
                Download for macOS (DMG)
              </Button>

              <Button
                onClick={() => {
                  window.location.href = "https://cardisense.vercel.app/downloads/cardisense-setup.exe"
                  closeDownloadOptions()
                }}
                className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
              >
                Download for Windows (EXE)
              </Button>

              <Button
                onClick={closeDownloadOptions}
                variant="outline"
                className="w-full mt-2 border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
              >
                Cancel
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </>
  )
}
