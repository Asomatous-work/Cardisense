"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { createClientSupabaseClient } from "@/lib/supabase/client"

type Message = {
  sender: "user" | "bot"
  text: string
}

const basicReplies: Record<string, string> = {
  hi: "Hello! How can I assist you today?",
  hello: "Hi there! 😊 How are you feeling today?",
  bye: "Take care! If anything changes, I'm here for you.",
  goodbye: "Goodbye! Stay safe and healthy.",
}

const alertKeywords = ["chest pain", "faint", "palpitation", "shortness of breath", "severe", "bleeding"]

const generateBotReply = (input: string, history: string[]): { reply: string; alert: boolean } => {
  const cleaned = input.toLowerCase().trim()

  // Basic greeting replies
  if (basicReplies[cleaned]) {
    return { reply: basicReplies[cleaned], alert: false }
  }

  // Alert handling
  const isAlert = alertKeywords.some((keyword) => cleaned.includes(keyword))
  if (isAlert) {
    return {
      reply: "⚠️ That sounds serious. I recommend seeking immediate medical attention or contacting a doctor.",
      alert: true,
    }
  }

  // Simulated memory-based reply (very simple RNN-like behavior)
  const memoryContext = history.slice(-2).join(" → ")
  return {
    reply: `Hmm... based on what you said earlier: "${memoryContext}", I'd suggest staying hydrated and taking rest.`,
    alert: false,
  }
}

export default function SenseChat() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [showAlert, setShowAlert] = useState(false)
  const [patientId, setPatientId] = useState<number | null>(null) // Assuming you have access to patientId

  useEffect(() => {
    // Fetch patient ID (replace with your actual logic)
    const fetchPatientId = async () => {
      // Example: Fetch from Supabase or local storage
      const supabase = createClientSupabaseClient()
      const { data, error } = await supabase.auth.getSession()
      if (data?.session?.user?.id) {
        // Fetch patient ID from your patients table based on user ID
        const { data: patientData, error: patientError } = await supabase
          .from("patients")
          .select("id")
          .eq("user_id", data.session.user.id)
          .single()

        if (patientError) {
          console.error("Error fetching patient ID:", patientError)
        } else if (patientData) {
          setPatientId(patientData.id)
        }
      }
    }

    fetchPatientId()
  }, [])

  const handleSend = async () => {
    if (!input.trim()) return

    const userMessage: Message = { sender: "user", text: input }
    const messageHistory = [...messages.map((m) => m.text), input]
    const { reply, alert } = generateBotReply(input, messageHistory)

    const botMessage: Message = { sender: "bot", text: reply }

    setMessages((prev) => [...prev, userMessage, botMessage])
    setShowAlert(alert)

    // Trigger alert in doctor dashboard if necessary
    if (alert && patientId) {
      try {
        const supabase = createClientSupabaseClient()
        await supabase.from("alerts").insert({
          patient_id: patientId,
          message: `Patient ${patientId} says: ${input}`,
          is_urgent: true,
        })
      } catch (error) {
        console.error("Error triggering alert:", error)
      }
    }

    setInput("")
  }

  return (
    <Card className="max-w-md mx-auto mt-10 shadow-lg border border-gray-300">
      <CardHeader>
        <CardTitle>Sense+ Chatbot 💬</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-64 p-2 border rounded mb-4 bg-gray-50">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`mb-2 text-sm ${msg.sender === "user" ? "text-right text-blue-700" : "text-left text-green-700"}`}
            >
              <span className="block">{msg.text}</span>
            </div>
          ))}
        </ScrollArea>

        {showAlert && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Urgent Symptom Detected</AlertTitle>
            <AlertDescription>
              Please visit the nearest hospital or call emergency services immediately.
            </AlertDescription>
          </Alert>
        )}

        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type something..."
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
          />
          <Button onClick={handleSend}>Send</Button>
        </div>
      </CardContent>
    </Card>
  )
}
