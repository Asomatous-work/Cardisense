"use client"

import { motion } from "framer-motion"
import { X, Github, Linkedin, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

interface TeamModalProps {
  isOpen: boolean
  onClose: () => void
}

export function TeamModal({ isOpen, onClose }: TeamModalProps) {
  const teamMembers = [
    {
      name: "ARAVIND G",
      role: "Lead Developer",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202024-10-15%20at%2017.04.52%20%281%29-8k7KM0PDmDcJKLjJPkp8COO3eE4wFQ.jpeg",
      linkedin: "https://www.linkedin.com/in/asomatous/",
    },
    {
      name: "RAFI KHAN L",
      role: "Team Manager & Technical Support",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-15%20at%2022.08.55-VvEUbT54CEL5FHGn2jpRvg35noctlL.jpeg",
      linkedin: "https://www.linkedin.com/in/rafikhanl",
    },
    {
      name: "SETHU RAJA P",
      role: "Backend Engineer",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-14%20at%2019.40.03-9SpQoj1UUtE2W1e5WdhrYm64lkPwv4.jpeg",
      linkedin: "#",
    },
    {
      name: "KIRUPA D",
      role: "Medical Consultant",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-03-14%20at%2019.49.43-hdNjCRdHvXC4uD6U4BBEGS2g4VeEHM.jpeg",
      linkedin: "#",
    },
    {
      name: "MANDHRAMOORTHY N",
      role: "Team Advisor",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/312821243017.jpg-kCPmigFcdvaKm5RDx2mqw4ddGccn6P.jpeg",
      linkedin: "#",
    },
    {
      name: "JEYASURYA S",
      role: "Project Manager",
      image: "/placeholder.svg?height=200&width=200",
      linkedin: "#",
    },
  ]

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-gradient-to-br from-slate-800 to-slate-900 border border-white/20 rounded-xl max-w-6xl w-full max-h-[90vh] overflow-auto shadow-2xl"
      >
        <div className="p-6">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-500 text-transparent bg-clip-text">
              Meet Our Team
            </h2>
            <Button variant="ghost" size="icon" onClick={onClose} className="hover:bg-white/10 text-white">
              <X className="h-5 w-5" />
            </Button>
          </div>

          <p className="text-white/80 mb-8 text-lg">
            Our dedicated team of professionals is committed to revolutionizing healthcare through technology. Each
            member brings unique expertise to make CARDISENSE a reality.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {teamMembers.map((member, index) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl overflow-hidden hover:border-pink-500/50 transition-all duration-300 group"
              >
                <div className="aspect-square overflow-hidden relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-pink-500/20 to-purple-500/20 group-hover:opacity-70 opacity-40 transition-opacity duration-300"></div>
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-xl font-bold text-white">{member.name}</h3>
                  <p className="text-white/70">{member.role}</p>
                  <div className="flex gap-2 mt-3">
                    <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full bg-white/10 hover:bg-white/20">
                      <Github className="h-4 w-4" />
                    </Button>
                    <a href={member.linkedin} target="_blank" rel="noopener noreferrer">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 rounded-full bg-white/10 hover:bg-white/20"
                      >
                        <Linkedin className="h-4 w-4" />
                      </Button>
                    </a>
                    <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full bg-white/10 hover:bg-white/20">
                      <Mail className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="flex justify-end">
            <Button
              onClick={onClose}
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
            >
              Close
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
