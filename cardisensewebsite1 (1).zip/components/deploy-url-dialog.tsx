"use client"

import { useState } from "react"
import { Check, Copy, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Patient, Doctor } from "@/lib/supabase/server"

interface DeployUrlDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  selectedUser: (Patient | Doctor) | null
  userType: "patient" | "doctor"
}

export function DeployUrlDialog({ open, onOpenChange, selectedUser, userType }: DeployUrlDialogProps) {
  const [copied, setCopied] = useState(false)
  const [urlType, setUrlType] = useState<"temporary" | "permanent">("temporary")

  if (!selectedUser) return null

  const baseUrl = typeof window !== "undefined" ? window.location.origin : ""
  const userName = selectedUser.name
  const userPath = userType === "patient" ? "dashboard" : "doctor-dashboard"

  // Generate a simple token (in a real app, this would be a secure JWT or similar)
  const generateToken = () => {
    const timestamp = Date.now()
    const randomString = Math.random().toString(36).substring(2, 10)
    return `${timestamp}-${randomString}`
  }

  const token = generateToken()

  const temporaryUrl = `${baseUrl}/${userPath}/${encodeURIComponent(userName)}?access_token=${token}&expires=24h`
  const permanentUrl = `${baseUrl}/${userPath}/${encodeURIComponent(userName)}?access_token=${token}`

  const currentUrl = urlType === "temporary" ? temporaryUrl : permanentUrl

  const handleCopy = () => {
    navigator.clipboard.writeText(currentUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleOpenPreview = () => {
    window.open(currentUrl, "_blank")
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] bg-slate-900 border-white/10 text-white">
        <DialogHeader>
          <DialogTitle>Deploy Access URL</DialogTitle>
          <DialogDescription className="text-white/70">
            Generate a unique URL for {userType === "patient" ? "patient" : "doctor"} access
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="flex items-center gap-3 bg-white/5 p-3 rounded-lg">
            <div
              className={`h-10 w-10 rounded-full ${userType === "patient" ? "bg-pink-500/20" : "bg-cyan-500/20"} flex items-center justify-center flex-shrink-0`}
            >
              <span className={`text-sm font-bold ${userType === "patient" ? "text-pink-500" : "text-cyan-500"}`}>
                {userName
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </span>
            </div>
            <div>
              <h3 className="font-medium">
                {userType === "doctor" ? "Dr. " : ""}
                {userName}
              </h3>
              <p className="text-sm text-white/70">
                {userType === "patient" ? "Patient Dashboard" : "Doctor Dashboard"}
              </p>
            </div>
          </div>

          <Tabs defaultValue="temporary" onValueChange={(value) => setUrlType(value as "temporary" | "permanent")}>
            <TabsList className="grid w-full grid-cols-2 bg-white/5">
              <TabsTrigger value="temporary">Temporary Access</TabsTrigger>
              <TabsTrigger value="permanent">Permanent Access</TabsTrigger>
            </TabsList>
            <TabsContent value="temporary" className="mt-4">
              <div className="space-y-2">
                <p className="text-sm text-white/70">
                  This URL will expire after 24 hours and provides temporary access to the dashboard.
                </p>
              </div>
            </TabsContent>
            <TabsContent value="permanent" className="mt-4">
              <div className="space-y-2">
                <p className="text-sm text-white/70">
                  This URL provides permanent access to the dashboard. Only share with trusted users.
                </p>
              </div>
            </TabsContent>
          </Tabs>

          <div className="space-y-2">
            <label className="text-sm text-white/70">Access URL</label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={currentUrl}
                readOnly
                className="flex-1 bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white text-sm"
              />
              <Button
                size="sm"
                variant="outline"
                className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                onClick={handleCopy}
              >
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
            <h4 className="text-sm font-medium mb-3">Dashboard Preview</h4>
            <div className="aspect-video bg-slate-800 rounded-lg border border-white/10 flex flex-col items-center justify-center p-4 overflow-hidden">
              <div className="w-full max-w-[400px] h-[200px] bg-slate-700/50 rounded-lg mb-2 relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-12 bg-slate-700 border-b border-white/10 flex items-center px-4">
                  <div className="h-6 w-6 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 flex items-center justify-center mr-2">
                    <span className="text-xs font-bold text-white">
                      {userName
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </span>
                  </div>
                  <div className="h-4 w-32 bg-white/20 rounded"></div>
                </div>
                <div className="absolute top-16 left-4 right-4 flex gap-2">
                  <div className="h-20 flex-1 bg-white/10 rounded"></div>
                  <div className="h-20 flex-1 bg-white/10 rounded"></div>
                  <div className="h-20 flex-1 bg-white/10 rounded"></div>
                </div>
                <div className="absolute top-40 left-4 right-4">
                  <div className="h-24 bg-white/10 rounded"></div>
                </div>
              </div>
              <p className="text-sm text-white/60 mt-2">
                {userType === "patient" ? "Patient" : "Doctor"} will see their personalized dashboard
              </p>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
          >
            Cancel
          </Button>
          <Button
            className={`${
              userType === "patient"
                ? "bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
                : "bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
            }`}
            onClick={handleOpenPreview}
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Open Preview
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
