"use client"

import { useState } from "react"
import { Bell } from "lucide-react"
import { usePathname } from "next/navigation"

interface DashboardHeaderProps {
  userName: string
  userType: "patient" | "doctor"
}

export function DashboardHeader({ userName, userType }: DashboardHeaderProps) {
  const pathname = usePathname()
  const [notificationCount, setNotificationCount] = useState(3)

  // Get page title from pathname
  const getPageTitle = () => {
    const path = pathname.split("/").pop() || ""

    if (path === "dashboard" || path === "doctor-dashboard") {
      return "Dashboard"
    }

    // Convert kebab-case to Title Case
    return path
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  return (
    <div className="flex items-center justify-between mb-6">
      <div className="flex items-center space-x-2">
        <img src="/yoga_icon.png" alt="CardisenseWebsite Logo" className="h-8 w-8" />
        <span className="font-bold text-lg">CardisenseWebsite</span>
      </div>
      <div>
        <h1 className="text-2xl font-bold">{getPageTitle()}</h1>
        <p className="text-white/60">
          Welcome, {userType === "doctor" ? "Dr. " : ""}
          {userName}
        </p>
      </div>

      <div className="relative">
        <button className="h-10 w-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors">
          <Bell className="h-5 w-5 text-white/70" />
          {notificationCount > 0 && (
            <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-pink-500 text-[10px] font-bold text-white">
              {notificationCount}
            </span>
          )}
        </button>
      </div>
    </div>
  )
}
