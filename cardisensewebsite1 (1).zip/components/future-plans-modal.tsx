"use client"

import { motion } from "framer-motion"
import { X, Rocket, Zap, Heart, Brain, Globe, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"

interface FuturePlansModalProps {
  isOpen: boolean
  onClose: () => void
}

export function FuturePlansModal({ isOpen, onClose }: FuturePlansModalProps) {
  const plans = [
    {
      title: "AI-Powered Diagnostics",
      description: "Developing advanced machine learning algorithms to predict cardiac events before they happen.",
      icon: Brain,
      timeline: "Q3 2025",
    },
    {
      title: "Global Health Network",
      description: "Expanding our platform to connect patients with specialists worldwide for remote consultations.",
      icon: Globe,
      timeline: "Q1 2026",
    },
    {
      title: "Wearable Integration",
      description: "Seamless integration with popular wearable devices for continuous health monitoring.",
      icon: Zap,
      timeline: "Q4 2025",
    },
    {
      title: "Preventive Care Module",
      description: "Personalized preventive care recommendations based on individual health data and risk factors.",
      icon: Shield,
      timeline: "Q2 2025",
    },
    {
      title: "Community Support Groups",
      description:
        "Building virtual communities for patients with similar conditions to share experiences and support.",
      icon: Heart,
      timeline: "In Development",
    },
  ]

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-gradient-to-br from-slate-800 to-slate-900 border border-white/20 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-auto shadow-2xl"
      >
        <div className="p-6">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-500 text-transparent bg-clip-text">
              Our Vision for the Future
            </h2>
            <Button variant="ghost" size="icon" onClick={onClose} className="hover:bg-white/10 text-white">
              <X className="h-5 w-5" />
            </Button>
          </div>

          <div className="mb-8 space-y-4">
            <div className="flex items-start gap-4">
              <div className="rounded-full bg-gradient-to-r from-pink-500/20 to-purple-500/20 p-3 mt-1">
                <Rocket className="h-6 w-6 text-pink-500" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Improving Lives Through Technology</h3>
                <p className="text-white/80 text-lg">
                  At CARDISENSE, we're constantly working to bridge the gap between advanced medical technology and
                  everyday healthcare. Our roadmap is focused on making cardiac care more accessible, personalized, and
                  effective for everyone.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-xl p-6 mb-8">
            <h3 className="text-xl font-bold text-white mb-4">Currently Updating</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3 bg-white/10 rounded-lg p-3 border border-white/10">
                <div className="h-2 w-2 rounded-full bg-green-500"></div>
                <p className="text-white/80">Mobile application with offline capabilities</p>
                <div className="ml-auto px-2 py-1 rounded-full bg-green-500/20 text-green-400 text-xs">In Progress</div>
              </div>
              <div className="flex items-center gap-3 bg-white/10 rounded-lg p-3 border border-white/10">
                <div className="h-2 w-2 rounded-full bg-green-500"></div>
                <p className="text-white/80">Enhanced data visualization for medical professionals</p>
                <div className="ml-auto px-2 py-1 rounded-full bg-green-500/20 text-green-400 text-xs">In Progress</div>
              </div>
              <div className="flex items-center gap-3 bg-white/10 rounded-lg p-3 border border-white/10">
                <div className="h-2 w-2 rounded-full bg-amber-500"></div>
                <p className="text-white/80">Multi-language support for global accessibility</p>
                <div className="ml-auto px-2 py-1 rounded-full bg-amber-500/20 text-amber-400 text-xs">Planning</div>
              </div>
            </div>
          </div>

          <h3 className="text-xl font-bold text-white mb-4">Future Roadmap</h3>
          <div className="space-y-4 mb-8">
            {plans.map((plan, index) => (
              <motion.div
                key={plan.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg p-4 hover:border-pink-500/50 transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="rounded-full bg-gradient-to-r from-pink-500/20 to-purple-500/20 p-2 mt-1">
                    <plan.icon className="h-5 w-5 text-pink-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h4 className="text-lg font-bold text-white">{plan.title}</h4>
                      <span className="px-2 py-1 rounded-full bg-purple-500/20 text-purple-400 text-xs">
                        {plan.timeline}
                      </span>
                    </div>
                    <p className="text-white/80 mt-1">{plan.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="flex justify-end">
            <Button
              onClick={onClose}
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
            >
              Close
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
