"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { useDeviceType } from "@/hooks/use-device-type"
import {
  Home,
  Heart,
  FileText,
  Calendar,
  MessageSquare,
  Shield,
  Trophy,
  User,
  Settings,
  Menu,
  Bell,
  DollarSign,
} from "lucide-react"

// Define navigation items for patient dashboard
const patientNavItems = [
  {
    title: "Home",
    href: "/dashboard",
    icon: Home,
  },
  {
    title: "Medical Card",
    href: "/dashboard/nfc-card",
    icon: Heart,
  },
  {
    title: "Reports",
    href: "/dashboard/reports",
    icon: FileText,
  },
  {
    title: "Appointments",
    href: "/dashboard/appointments",
    icon: Calendar,
  },
  {
    title: "Chatbot",
    href: "/dashboard/chatbot",
    icon: MessageSquare,
  },
]

// Define navigation items for doctor dashboard
const doctorNavItems = [
  {
    title: "Home",
    href: "/doctor-dashboard",
    icon: Home,
  },
  {
    title: "Patients",
    href: "/doctor-dashboard/patients",
    icon: User,
  },
  {
    title: "Appointments",
    href: "/doctor-dashboard/appointments",
    icon: Calendar,
  },
  {
    title: "Alerts",
    href: "/doctor-dashboard/alerts",
    icon: Bell,
  },
  {
    title: "Payments",
    href: "/doctor-dashboard/payments",
    icon: DollarSign,
  },
]

// Secondary navigation items
const secondaryNavItems = {
  patient: [
    {
      title: "Insurance",
      href: "/dashboard/insurance",
      icon: Shield,
    },
    {
      title: "Rewards",
      href: "/dashboard/rewards",
      icon: Trophy,
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
    },
  ],
  doctor: [
    {
      title: "Settings",
      href: "/doctor-dashboard/settings",
      icon: Settings,
    },
  ],
}

interface FloatingNavProps {
  type: "patient" | "doctor"
}

export function FloatingNav({ type }: FloatingNavProps) {
  const pathname = usePathname()
  const { isMobile } = useDeviceType()
  const [showMoreMenu, setShowMoreMenu] = useState(false)
  const [isVisible, setIsVisible] = useState(true)
  const [lastScrollY, setLastScrollY] = useState(0)

  // Determine which nav items to use based on type
  const primaryNavItems = type === "patient" ? patientNavItems : doctorNavItems
  const moreNavItems = secondaryNavItems[type]

  // Handle scroll to hide/show nav
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY

      // Show nav when scrolling up, hide when scrolling down
      if (currentScrollY > lastScrollY + 10) {
        setIsVisible(false)
        setShowMoreMenu(false)
      } else if (currentScrollY < lastScrollY - 10) {
        setIsVisible(true)
      }

      setLastScrollY(currentScrollY)
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [lastScrollY])

  // Close more menu when route changes
  useEffect(() => {
    setShowMoreMenu(false)
  }, [pathname])

  return (
    <>
      {/* Main floating navigation */}
      <motion.div
        className="fixed bottom-6 left-0 right-0 mx-auto z-50 flex items-center justify-center"
        style={{ maxWidth: "fit-content" }}
        initial={{ y: 100, opacity: 0 }}
        animate={{
          y: isVisible ? 0 : 100,
          opacity: isVisible ? 1 : 0,
        }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex items-center gap-1 bg-slate-800/95 backdrop-blur-md border border-white/10 rounded-full p-1.5 shadow-lg">
          {primaryNavItems.map((item) => {
            const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`)
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "relative flex flex-col items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full transition-all",
                  isActive ? "text-white scale-110 z-10" : "text-white/50 hover:text-white/80 hover:scale-105",
                )}
                aria-label={item.title}
              >
                <div className={cn("flex items-center justify-center", isActive && "relative")}>
                  {isActive && (
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-pink-600/20 to-purple-600/20 rounded-full"
                      layoutId="navBackground"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                      style={{ width: "100%", height: "100%" }}
                    />
                  )}
                  <item.icon
                    className={cn("h-5 w-5 sm:h-6 sm:w-6 transition-all duration-300", isActive && "text-pink-500")}
                  />
                </div>
                <span
                  className={cn(
                    "text-[9px] sm:text-[10px] mt-1 font-medium transition-all duration-300",
                    isActive && "text-pink-500",
                  )}
                >
                  {item.title}
                </span>
                {isActive && (
                  <motion.div
                    className="absolute -bottom-1 w-8 sm:w-10 h-1 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full"
                    layoutId="activeIndicator"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
              </Link>
            )
          })}

          {/* More menu button */}
          <button
            className={cn(
              "relative flex flex-col items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full transition-all",
              showMoreMenu ? "text-white scale-110 z-10" : "text-white/50 hover:text-white/80 hover:scale-105",
            )}
            onClick={() => setShowMoreMenu(!showMoreMenu)}
            aria-label="More options"
          >
            <div className={cn("flex items-center justify-center", showMoreMenu && "relative")}>
              {showMoreMenu && (
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-pink-600/20 to-purple-600/20 rounded-full"
                  layoutId="moreBackground"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  style={{ width: "100%", height: "100%" }}
                />
              )}
              <Menu
                className={cn("h-5 w-5 sm:h-6 sm:w-6 transition-all duration-300", showMoreMenu && "text-pink-500")}
              />
            </div>
            <span
              className={cn(
                "text-[9px] sm:text-[10px] mt-1 font-medium transition-all duration-300",
                showMoreMenu && "text-pink-500",
              )}
            >
              More
            </span>
            {showMoreMenu && (
              <motion.div
                className="absolute -bottom-1 w-8 sm:w-10 h-1 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full"
                layoutId="moreIndicator"
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              />
            )}
          </button>
        </div>
      </motion.div>

      {/* More menu */}
      <AnimatePresence>
        {showMoreMenu && (
          <motion.div
            className="fixed bottom-28 left-0 right-0 mx-auto z-40 bg-slate-800/95 backdrop-blur-md border border-white/10 rounded-2xl p-3 shadow-lg"
            style={{ maxWidth: "320px" }}
            initial={{ y: 20, opacity: 0, scale: 0.95 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 20, opacity: 0, scale: 0.95 }}
            transition={{ type: "spring", bounce: 0.1, duration: 0.4 }}
          >
            <div className="grid grid-cols-3 gap-3 w-full">
              {moreNavItems.map((item) => {
                const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`)
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "flex flex-col items-center justify-center p-3 rounded-xl transition-all",
                      isActive
                        ? "text-pink-500 bg-white/10 scale-105"
                        : "text-white/60 hover:text-white/90 hover:bg-white/5 hover:scale-105",
                    )}
                    aria-label={item.title}
                  >
                    <item.icon className="h-6 w-6 mb-1" />
                    <span className="text-xs font-medium">{item.title}</span>
                  </Link>
                )
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Overlay for more menu */}
      <AnimatePresence>
        {showMoreMenu && (
          <motion.div
            className="fixed inset-0 z-30 bg-black/20 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowMoreMenu(false)}
            aria-hidden="true"
          />
        )}
      </AnimatePresence>
    </>
  )
}

// Make sure to export the component as default as well
export default FloatingNav
