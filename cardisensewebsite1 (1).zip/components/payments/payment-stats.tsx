import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getPaymentStats } from "@/lib/actions/payment-actions"
import { DollarSign, CreditCard, AlertTriangle, CheckCircle } from "lucide-react"

export async function PaymentStats() {
  const stats = await getPaymentStats()

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 w-full">
      <Card className="w-full">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Outstanding</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₹{stats.totalOutstanding.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">{stats.pendingCount} pending payments</p>
        </CardContent>
      </Card>

      <Card className="w-full">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Collected This Month</CardTitle>
          <CreditCard className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₹{stats.collectedThisMonth.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">{stats.paidThisMonth} payments received</p>
        </CardContent>
      </Card>

      <Card className="w-full">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Overdue Payments</CardTitle>
          <AlertTriangle className="h-4 w-4 text-destructive" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₹{stats.overdueAmount.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">{stats.overdueCount} overdue payments</p>
        </CardContent>
      </Card>

      <Card className="w-full">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Payment Success Rate</CardTitle>
          <CheckCircle className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.successRate}%</div>
          <p className="text-xs text-muted-foreground">
            {stats.paidCount} of {stats.totalCount} payments
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
