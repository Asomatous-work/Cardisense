"use client"

import { useState } from "react"
import { sendPaymentReminder } from "@/lib/actions/payment-actions"
import { Button } from "@/components/ui/button"
import { toast } from "@/hooks/use-toast"
import { Mail } from "lucide-react"

interface SendPaymentReminderButtonProps {
  paymentId: number
  patientEmail: string
}

export function SendPaymentReminderButton({ paymentId, patientEmail }: SendPaymentReminderButtonProps) {
  const [isLoading, setIsLoading] = useState(false)

  async function handleSendReminder() {
    setIsLoading(true)

    try {
      await sendPaymentReminder(paymentId, patientEmail)

      toast({
        title: "Reminder sent",
        description: "Payment reminder has been sent to the patient.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send payment reminder. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button variant="outline" size="icon" onClick={handleSendReminder} disabled={isLoading}>
      <Mail className="h-4 w-4" />
    </Button>
  )
}
