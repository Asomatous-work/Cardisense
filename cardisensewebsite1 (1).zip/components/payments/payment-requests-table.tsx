import { getPaymentRequests } from "@/lib/actions/payment-actions"
import { formatDate } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { UpdatePaymentStatusDialog } from "./update-payment-status-dialog"
import { SendPaymentReminderButton } from "./send-payment-reminder-button"

interface PaymentRequestsTableProps {
  filter: "all" | "pending" | "paid" | "overdue"
}

export async function PaymentRequestsTable({ filter }: PaymentRequestsTableProps) {
  const paymentRequests = await getPaymentRequests(filter)

  return (
    <div className="rounded-md border w-full overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Patient</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Description</TableHead>
            <TableHead>Service Type</TableHead>
            <TableHead>Due Date</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {paymentRequests.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="h-24 text-center">
                No payment requests found.
              </TableCell>
            </TableRow>
          ) : (
            paymentRequests.map((payment) => (
              <TableRow key={payment.id}>
                <TableCell className="font-medium">{payment.patientName}</TableCell>
                <TableCell>₹{payment.amount.toLocaleString()}</TableCell>
                <TableCell>{payment.description}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="capitalize">
                    {payment.service_type}
                  </Badge>
                </TableCell>
                <TableCell>{formatDate(payment.due_date)}</TableCell>
                <TableCell>
                  <PaymentStatusBadge status={payment.status} />
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <UpdatePaymentStatusDialog paymentId={payment.id} currentStatus={payment.status} />
                    {payment.status === "pending" || payment.status === "overdue" ? (
                      <SendPaymentReminderButton paymentId={payment.id} patientEmail={payment.patientEmail} />
                    ) : null}
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}

function PaymentStatusBadge({ status }: { status: string }) {
  const variants = {
    pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
    paid: "bg-green-100 text-green-800 border-green-200",
    overdue: "bg-red-100 text-red-800 border-red-200",
    cancelled: "bg-gray-100 text-gray-800 border-gray-200",
  }

  return (
    <Badge variant="outline" className={`capitalize ${variants[status as keyof typeof variants]}`}>
      {status}
    </Badge>
  )
}
