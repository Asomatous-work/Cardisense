"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Filter } from "lucide-react"
import { format } from "date-fns"

export function PaymentFilters() {
  const router = useRouter()
  const searchParams = useSearchParams()

  const [serviceTypes, setServiceTypes] = useState<string[]>([])
  const [dateRange, setDateRange] = useState<{
    from: Date | undefined
    to: Date | undefined
  }>({
    from: undefined,
    to: undefined,
  })

  function handleServiceTypeChange(value: string) {
    setServiceTypes((current) => {
      const updated = current.includes(value) ? current.filter((type) => type !== value) : [...current, value]

      updateFilters({ serviceTypes: updated })
      return updated
    })
  }

  function handleDateRangeChange(range: { from: Date | undefined; to: Date | undefined }) {
    setDateRange(range)

    if (range.from && range.to) {
      updateFilters({
        fromDate: format(range.from, "yyyy-MM-dd"),
        toDate: format(range.to, "yyyy-MM-dd"),
      })
    }
  }

  function updateFilters(filters: Record<string, any>) {
    const params = new URLSearchParams(searchParams.toString())

    Object.entries(filters).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        if (value.length > 0) {
          params.set(key, value.join(","))
        } else {
          params.delete(key)
        }
      } else if (value) {
        params.set(key, String(value))
      } else {
        params.delete(key)
      }
    })

    router.push(`?${params.toString()}`)
  }

  function clearFilters() {
    setServiceTypes([])
    setDateRange({ from: undefined, to: undefined })
    router.push("")
  }

  return (
    <div className="flex items-center gap-2">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[200px]">
          <DropdownMenuLabel>Service Type</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuCheckboxItem
            checked={serviceTypes.includes("consultation")}
            onCheckedChange={() => handleServiceTypeChange("consultation")}
          >
            Consultation
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem
            checked={serviceTypes.includes("diagnostic")}
            onCheckedChange={() => handleServiceTypeChange("diagnostic")}
          >
            Diagnostic
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem
            checked={serviceTypes.includes("procedure")}
            onCheckedChange={() => handleServiceTypeChange("procedure")}
          >
            Procedure
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem
            checked={serviceTypes.includes("emergency")}
            onCheckedChange={() => handleServiceTypeChange("emergency")}
          >
            Emergency
          </DropdownMenuCheckboxItem>
          <DropdownMenuCheckboxItem
            checked={serviceTypes.includes("medication")}
            onCheckedChange={() => handleServiceTypeChange("medication")}
          >
            Medication
          </DropdownMenuCheckboxItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm">
            <CalendarIcon className="mr-2 h-4 w-4" />
            {dateRange.from ? (
              dateRange.to ? (
                <>
                  {format(dateRange.from, "LLL dd")} - {format(dateRange.to, "LLL dd")}
                </>
              ) : (
                format(dateRange.from, "LLL dd")
              )
            ) : (
              "Date Range"
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="end">
          <Calendar mode="range" selected={dateRange} onSelect={handleDateRangeChange} initialFocus />
        </PopoverContent>
      </Popover>

      {(serviceTypes.length > 0 || dateRange.from) && (
        <Button variant="ghost" size="sm" onClick={clearFilters}>
          Clear
        </Button>
      )}
    </div>
  )
}
