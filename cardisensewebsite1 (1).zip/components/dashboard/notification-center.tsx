"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Bell, DollarSign, Calendar, FileText, X, ChevronRight, AlertCircle } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { PaymentNotification } from "@/components/dashboard/payment-notification"
import { useDeviceType } from "@/hooks/use-device-type"
import { motion, AnimatePresence } from "framer-motion"

interface Notification {
  id: string
  type: "payment" | "appointment" | "report" | "alert"
  title: string
  message: string
  time: string
  read: boolean
  data?: any
}

export function NotificationCenter() {
  const { isMobile } = useDeviceType()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null)
  const [showPaymentDialog, setShowPaymentDialog] = useState(false)
  const [expanded, setExpanded] = useState(!isMobile)

  // Sample notifications - in a real app, these would come from an API
  useEffect(() => {
    const sampleNotifications: Notification[] = [
      {
        id: "1",
        type: "payment",
        title: "Payment Request",
        message: "Dr. KIRUPA D has requested a payment of ₹1,500 for Cardiology Checkup",
        time: "10 minutes ago",
        read: false,
        data: {
          doctor: "KIRUPA D",
          service: "Cardiology Checkup",
          amount: 1500,
          upiId: "lovelykirupa1610@okaxis",
        },
      },
      {
        id: "2",
        type: "appointment",
        title: "Appointment Reminder",
        message: "You have an appointment with Dr. JEYASURYA S tomorrow at 10:30 AM",
        time: "2 hours ago",
        read: false,
      },
      {
        id: "3",
        type: "report",
        title: "New Report Available",
        message: "Your blood test results are now available",
        time: "Yesterday",
        read: true,
      },
      {
        id: "4",
        type: "alert",
        title: "Medication Reminder",
        message: "Remember to take your evening medication",
        time: "Yesterday",
        read: true,
      },
    ]

    setNotifications(sampleNotifications)
  }, [])

  const unreadCount = notifications.filter((n) => !n.read).length

  const handleNotificationClick = (notification: Notification) => {
    setSelectedNotification(notification)

    // Mark as read
    setNotifications(notifications.map((n) => (n.id === notification.id ? { ...n, read: true } : n)))

    // Handle different notification types
    if (notification.type === "payment") {
      setShowPaymentDialog(true)
    }
    // Other types would have their own handlers
  }

  const handleDismiss = (id: string) => {
    setNotifications(notifications.filter((n) => n.id !== id))
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "payment":
        return <DollarSign className="h-5 w-5 text-pink-500" />
      case "appointment":
        return <Calendar className="h-5 w-5 text-cyan-500" />
      case "report":
        return <FileText className="h-5 w-5 text-purple-500" />
      case "alert":
        return <AlertCircle className="h-5 w-5 text-amber-500" />
      default:
        return <Bell className="h-5 w-5 text-white/70" />
    }
  }

  const toggleExpand = () => {
    setExpanded(!expanded)
  }

  return (
    <>
      <Card className="bg-white/5 border-white/10">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-pink-500" />
              <h3 className="font-medium">Notifications</h3>
              {unreadCount > 0 && (
                <span className="bg-pink-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{unreadCount}</span>
              )}
            </div>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={toggleExpand}>
              {expanded ? <X className="h-4 w-4 text-white/70" /> : <ChevronRight className="h-4 w-4 text-white/70" />}
            </Button>
          </div>

          <AnimatePresence>
            {expanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                  {notifications.length > 0 ? (
                    notifications.map((notification) => (
                      <div
                        key={notification.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-all ${
                          notification.read ? "bg-white/5 border-white/10" : "bg-white/10 border-pink-500/30"
                        }`}
                        onClick={() => handleNotificationClick(notification)}
                      >
                        <div className="flex gap-3">
                          <div
                            className={`h-10 w-10 rounded-full ${
                              notification.type === "payment"
                                ? "bg-pink-500/20"
                                : notification.type === "appointment"
                                  ? "bg-cyan-500/20"
                                  : notification.type === "report"
                                    ? "bg-purple-500/20"
                                    : "bg-amber-500/20"
                            } flex items-center justify-center flex-shrink-0`}
                          >
                            {getNotificationIcon(notification.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between">
                              <h4 className="font-medium truncate">{notification.title}</h4>
                              <button
                                className="text-white/40 hover:text-white/70 ml-2"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  handleDismiss(notification.id)
                                }}
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                            <p className="text-sm text-white/70 line-clamp-2">{notification.message}</p>
                            <p className="text-xs text-white/50 mt-1">{notification.time}</p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-6 text-white/50">
                      <Bell className="h-8 w-8 mx-auto mb-2 text-white/30" />
                      <p>No notifications</p>
                    </div>
                  )}
                </div>

                {notifications.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full mt-3 text-white/70 hover:text-white hover:bg-white/10"
                  >
                    View All Notifications
                  </Button>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {!expanded && notifications.length > 0 && (
            <div className="flex items-center justify-between text-sm text-white/70">
              <span>{unreadCount} unread notifications</span>
              <Button
                variant="ghost"
                size="sm"
                className="text-pink-400 hover:text-pink-300 p-0 h-auto"
                onClick={toggleExpand}
              >
                View
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payment Dialog */}
      {selectedNotification?.type === "payment" && (
        <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
          <DialogContent className="bg-slate-900 border-white/10 text-white sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Payment Request</DialogTitle>
            </DialogHeader>

            <PaymentNotification
              doctor={selectedNotification.data.doctor}
              service={selectedNotification.data.service}
              amount={selectedNotification.data.amount}
              upiId={selectedNotification.data.upiId}
              onClose={() => setShowPaymentDialog(false)}
              isDialog={true}
            />

            <DialogFooter className="mt-4">
              <Button
                variant="outline"
                onClick={() => setShowPaymentDialog(false)}
                className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
              >
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  )
}
