"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Users, Calendar, Clock, CheckCircle, TrendingUp, Activity } from "lucide-react"
import { createClientSupabaseClient } from "@/lib/supabase/client"

export function DoctorStats() {
  const [stats, setStats] = useState({
    totalPatients: 0,
    appointmentsToday: 0,
    averageWaitTime: 0,
    completedAppointments: 0,
    patientGrowth: 0,
    activePatients: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()

    // Set up real-time subscription for stats updates
    const supabase = createClientSupabaseClient()

    const statsSubscription = supabase
      .channel("stats-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "appointments",
        },
        () => {
          fetchStats()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(statsSubscription)
    }
  }, [])

  const fetchStats = async () => {
    setLoading(true)
    try {
      const supabase = createClientSupabaseClient()

      // Fetch total patients
      const { count: totalPatients, error: patientsError } = await supabase
        .from("patients")
        .select("*", { count: "exact", head: true })

      // Fetch appointments for today
      const today = new Date().toISOString().split("T")[0]
      const { count: appointmentsToday, error: appointmentsError } = await supabase
        .from("appointments")
        .select("*", { count: "exact", head: true })
        .eq("appointment_date", today)

      // Fetch completed appointments
      const { count: completedAppointments, error: completedError } = await supabase
        .from("appointments")
        .select("*", { count: "exact", head: true })
        .eq("status", "completed")

      // Fetch active patients (currently present)
      const { count: activePatients, error: activeError } = await supabase
        .from("patients")
        .select("*", { count: "exact", head: true })
        .eq("is_present", true)

      // Calculate patient growth (new patients in the last 30 days)
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
      const { count: newPatients, error: newPatientsError } = await supabase
        .from("patients")
        .select("*", { count: "exact", head: true })
        .gte("created_at", thirtyDaysAgo.toISOString())

      // Calculate average wait time (in minutes) from appointments
      const { data: waitTimeData, error: waitTimeError } = await supabase
        .from("appointments")
        .select("wait_time")
        .not("wait_time", "is", null)
        .limit(50)

      let averageWaitTime = 0
      if (waitTimeData && waitTimeData.length > 0) {
        const totalWaitTime = waitTimeData.reduce((sum, appointment) => sum + (appointment.wait_time || 0), 0)
        averageWaitTime = Math.round(totalWaitTime / waitTimeData.length)
      }

      setStats({
        totalPatients: totalPatients || 0,
        appointmentsToday: appointmentsToday || 0,
        averageWaitTime,
        completedAppointments: completedAppointments || 0,
        patientGrowth: newPatients || 0,
        activePatients: activePatients || 0,
      })
    } catch (error) {
      console.error("Error fetching stats:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      <Card className="bg-white/5 border-white/10 p-4">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-white/70">Total Patients</h3>
            <Users className="h-4 w-4 text-cyan-500" />
          </div>
          <div className="mt-auto">
            {loading ? (
              <div className="h-6 w-16 bg-white/10 rounded animate-pulse"></div>
            ) : (
              <p className="text-2xl font-bold">{stats.totalPatients}</p>
            )}
            <p className="text-xs text-white/60 mt-1">Registered patients</p>
          </div>
        </div>
      </Card>

      <Card className="bg-white/5 border-white/10 p-4">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-white/70">Today's Appointments</h3>
            <Calendar className="h-4 w-4 text-pink-500" />
          </div>
          <div className="mt-auto">
            {loading ? (
              <div className="h-6 w-16 bg-white/10 rounded animate-pulse"></div>
            ) : (
              <p className="text-2xl font-bold">{stats.appointmentsToday}</p>
            )}
            <p className="text-xs text-white/60 mt-1">Scheduled for today</p>
          </div>
        </div>
      </Card>

      <Card className="bg-white/5 border-white/10 p-4">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-white/70">Avg. Wait Time</h3>
            <Clock className="h-4 w-4 text-amber-500" />
          </div>
          <div className="mt-auto">
            {loading ? (
              <div className="h-6 w-16 bg-white/10 rounded animate-pulse"></div>
            ) : (
              <p className="text-2xl font-bold">{stats.averageWaitTime} min</p>
            )}
            <p className="text-xs text-white/60 mt-1">Average patient wait</p>
          </div>
        </div>
      </Card>

      <Card className="bg-white/5 border-white/10 p-4">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-white/70">Completed</h3>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </div>
          <div className="mt-auto">
            {loading ? (
              <div className="h-6 w-16 bg-white/10 rounded animate-pulse"></div>
            ) : (
              <p className="text-2xl font-bold">{stats.completedAppointments}</p>
            )}
            <p className="text-xs text-white/60 mt-1">Total completed</p>
          </div>
        </div>
      </Card>

      <Card className="bg-white/5 border-white/10 p-4">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-white/70">New Patients</h3>
            <TrendingUp className="h-4 w-4 text-purple-500" />
          </div>
          <div className="mt-auto">
            {loading ? (
              <div className="h-6 w-16 bg-white/10 rounded animate-pulse"></div>
            ) : (
              <p className="text-2xl font-bold">{stats.patientGrowth}</p>
            )}
            <p className="text-xs text-white/60 mt-1">Last 30 days</p>
          </div>
        </div>
      </Card>

      <Card className="bg-white/5 border-white/10 p-4">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-white/70">Active Now</h3>
            <Activity className="h-4 w-4 text-blue-500" />
          </div>
          <div className="mt-auto">
            {loading ? (
              <div className="h-6 w-16 bg-white/10 rounded animate-pulse"></div>
            ) : (
              <p className="text-2xl font-bold">{stats.activePatients}</p>
            )}
            <p className="text-xs text-white/60 mt-1">Currently present</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
