import type React from "react"
interface DashboardShellProps {
  children?: React.ReactNode
}

export function DashboardShell({ children }: DashboardShellProps) {
  return <div className="flex flex-col min-h-screen w-full bg-slate-950">{children}</div>
}
