"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { User, Search, FileText, Calendar, Pill, Activity, Plus, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function PatientMedicalHistory() {
  const { toast } = useToast()
  const [patients, setPatients] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<any | null>(null)
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false)
  const [addNoteDialogOpen, setAddNoteDialogOpen] = useState(false)
  const [noteText, setNoteText] = useState("")
  const [medicalHistory, setMedicalHistory] = useState<any[]>([])
  const [medications, setMedications] = useState<any[]>([])
  const [testResults, setTestResults] = useState<any[]>([])
  const [addingNote, setAddingNote] = useState(false)

  // Fetch patients from the database
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()

        // Fetch all patients
        const { data, error } = await supabase.from("patients").select("*").order("name")

        if (error) {
          throw error
        }

        // Transform the data
        const formattedData = (data || []).map((patient) => ({
          id: patient.id,
          name: patient.name,
          medicalCondition: patient.medical_condition || "No condition specified",
          contactNumber: patient.contact_number || "No contact number",
          lastVisit: patient.last_visit ? new Date(patient.last_visit).toLocaleDateString() : "First visit",
          status: patient.status || "active",
        }))

        setPatients(formattedData)
      } catch (error) {
        console.error("Error fetching patients:", error)
        toast({
          title: "Error",
          description: "Failed to fetch patients. Please try again.",
          variant: "destructive",
        })

        // Set some sample data for demonstration
        setPatients(getSamplePatients())
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  // Sample data for demonstration when database is not available
  const getSamplePatients = () => {
    return [
      {
        id: 1,
        name: "Aravind G",
        medicalCondition: "Hypertension, Diabetes",
        contactNumber: "+91 9876543210",
        lastVisit: "15 Mar 2025",
        status: "active",
      },
      {
        id: 2,
        name: "Rafikhan L",
        medicalCondition: "Post-surgery follow-up",
        contactNumber: "+91 9876543211",
        lastVisit: "2 Apr 2025",
        status: "active",
      },
      {
        id: 3,
        name: "Sethu Raja P",
        medicalCondition: "Chest pain evaluation",
        contactNumber: "+91 9876543212",
        lastVisit: "First visit",
        status: "pending",
      },
    ]
  }

  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      patient.medicalCondition.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleViewHistory = (patient: any) => {
    setSelectedPatient(patient)

    // Generate sample medical history for demonstration
    setMedicalHistory([
      {
        id: 1,
        date: "15 Mar 2025",
        type: "Consultation",
        doctor: "Dr. KIRUPA D",
        notes:
          "Patient presented with chest pain and shortness of breath. ECG showed normal sinus rhythm. Advised rest and follow-up in 2 weeks.",
      },
      {
        id: 2,
        date: "1 Feb 2025",
        type: "Consultation",
        doctor: "Dr. KIRUPA D",
        notes: "Regular checkup. Blood pressure slightly elevated at 140/90. Adjusted medication dosage.",
      },
      {
        id: 3,
        date: "15 Dec 2024",
        type: "Emergency",
        doctor: "Dr. JEYASURYA S",
        notes:
          "Patient admitted with severe chest pain. ECG and cardiac enzymes normal. Diagnosed as musculoskeletal pain. Discharged with pain medication.",
      },
    ])

    // Generate sample medications for demonstration
    setMedications([
      {
        id: 1,
        name: "Amlodipine",
        dosage: "5mg",
        frequency: "Once daily",
        startDate: "15 Dec 2024",
        endDate: "Ongoing",
        prescribedBy: "Dr. KIRUPA D",
      },
      {
        id: 2,
        name: "Metformin",
        dosage: "500mg",
        frequency: "Twice daily",
        startDate: "15 Dec 2024",
        endDate: "Ongoing",
        prescribedBy: "Dr. KIRUPA D",
      },
      {
        id: 3,
        name: "Aspirin",
        dosage: "75mg",
        frequency: "Once daily",
        startDate: "15 Dec 2024",
        endDate: "Ongoing",
        prescribedBy: "Dr. KIRUPA D",
      },
    ])

    // Generate sample test results for demonstration
    setTestResults([
      {
        id: 1,
        date: "15 Mar 2025",
        type: "ECG",
        result: "Normal sinus rhythm",
        orderedBy: "Dr. KIRUPA D",
      },
      {
        id: 2,
        date: "15 Mar 2025",
        type: "Blood Test",
        result: "Hemoglobin: 14.5 g/dL, WBC: 7500/µL, Platelets: 250,000/µL",
        orderedBy: "Dr. KIRUPA D",
      },
      {
        id: 3,
        date: "15 Dec 2024",
        type: "Cardiac Enzymes",
        result: "Troponin I: 0.01 ng/mL (Normal), CK-MB: 3.2 ng/mL (Normal)",
        orderedBy: "Dr. JEYASURYA S",
      },
    ])

    setHistoryDialogOpen(true)
  }

  const handleAddNote = () => {
    setAddNoteDialogOpen(true)
  }

  const handleSubmitNote = async () => {
    if (!noteText) {
      toast({
        title: "Missing Information",
        description: "Please enter a note.",
        variant: "destructive",
      })
      return
    }

    setAddingNote(true)

    try {
      // In a real application, you would save this to the database
      // For now, we'll just update the local state

      const newNote = {
        id: medicalHistory.length + 1,
        date: new Date().toLocaleDateString(),
        type: "Consultation",
        doctor: "Dr. KIRUPA D",
        notes: noteText,
      }

      setMedicalHistory([newNote, ...medicalHistory])

      toast({
        title: "Note Added",
        description: "The medical note has been added successfully.",
        variant: "default",
      })

      setNoteText("")
      setAddNoteDialogOpen(false)
    } catch (error) {
      console.error("Error adding note:", error)
      toast({
        title: "Error",
        description: "Failed to add note. Please try again.",
        variant: "destructive",
      })
    } finally {
      setAddingNote(false)
    }
  }

  return (
    <>
      <Card className="bg-white/5 border-white/10 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <FileText className="h-5 w-5 text-cyan-500" />
            <span>Patient Medical History</span>
          </h2>
          <div className="relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40" />
            <input
              type="text"
              placeholder="Search patients..."
              className="bg-white/10 border border-white/20 rounded-md pl-9 pr-4 py-1 text-sm text-white w-48"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-cyan-500" />
          </div>
        ) : (
          <>
            {filteredPatients.length > 0 ? (
              <div className="space-y-4">
                {filteredPatients.map((patient) => (
                  <div key={patient.id} className="bg-white/10 rounded-lg p-4 border border-white/10">
                    <div className="flex items-start justify-between">
                      <div className="flex gap-3">
                        <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                          <User className="h-5 w-5 text-pink-500" />
                        </div>
                        <div>
                          <h3 className="font-medium">{patient.name}</h3>
                          <p className="text-sm text-white/70">{patient.medicalCondition}</p>
                          <div className="flex items-center gap-3 mt-1">
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3 text-white/60" />
                              <span className="text-xs text-white/60">Last visit: {patient.lastVisit}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="h-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                        onClick={() => handleViewHistory(patient)}
                      >
                        View Medical History
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-white/60 bg-white/5 rounded-lg border border-white/10">
                <FileText className="h-12 w-12 mx-auto mb-3 text-white/30" />
                <p>No patients found</p>
                <p className="text-sm mt-1">Try adjusting your search</p>
              </div>
            )}
          </>
        )}
      </Card>

      {/* Medical History Dialog */}
      <Dialog open={historyDialogOpen} onOpenChange={setHistoryDialogOpen}>
        <DialogContent className="bg-slate-900 border-white/10 text-white max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span>Medical History - {selectedPatient?.name}</span>
              <Button
                size="sm"
                className="h-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                onClick={handleAddNote}
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Note
              </Button>
            </DialogTitle>
          </DialogHeader>

          {selectedPatient && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3 bg-white/5 p-3 rounded-lg">
                <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                  <User className="h-5 w-5 text-pink-500" />
                </div>
                <div>
                  <h3 className="font-medium">{selectedPatient.name}</h3>
                  <p className="text-sm text-white/70">{selectedPatient.medicalCondition}</p>
                </div>
              </div>

              <Tabs defaultValue="consultations" className="w-full">
                <TabsList className="grid grid-cols-3 mb-4">
                  <TabsTrigger value="consultations">Consultations</TabsTrigger>
                  <TabsTrigger value="medications">Medications</TabsTrigger>
                  <TabsTrigger value="test-results">Test Results</TabsTrigger>
                </TabsList>

                <TabsContent value="consultations" className="mt-0">
                  <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                    {medicalHistory.map((entry) => (
                      <div key={entry.id} className="bg-white/5 rounded-lg p-4 border border-white/10">
                        <div className="flex items-start gap-3">
                          <div className="flex-shrink-0">
                            <div className="h-8 w-8 rounded-full bg-cyan-500/20 flex items-center justify-center">
                              <FileText className="h-4 w-4 text-cyan-500" />
                            </div>
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">{entry.type}</span>
                              <span className="text-xs text-white/60">{entry.date}</span>
                            </div>
                            <p className="text-xs text-white/60 mt-1">Doctor: {entry.doctor}</p>
                            <p className="text-sm mt-2">{entry.notes}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="medications" className="mt-0">
                  <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                    {medications.map((medication) => (
                      <div key={medication.id} className="bg-white/5 rounded-lg p-4 border border-white/10">
                        <div className="flex items-start gap-3">
                          <div className="flex-shrink-0">
                            <div className="h-8 w-8 rounded-full bg-pink-500/20 flex items-center justify-center">
                              <Pill className="h-4 w-4 text-pink-500" />
                            </div>
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">{medication.name}</span>
                              <span className="px-2 py-0.5 rounded-full bg-white/10 text-white/70 text-xs">
                                {medication.dosage}
                              </span>
                            </div>
                            <p className="text-xs text-white/60 mt-1">Frequency: {medication.frequency}</p>
                            <p className="text-xs text-white/60">
                              {medication.startDate} - {medication.endDate}
                            </p>
                            <p className="text-xs text-white/60 mt-1">Prescribed by: {medication.prescribedBy}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="test-results" className="mt-0">
                  <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                    {testResults.map((test) => (
                      <div key={test.id} className="bg-white/5 rounded-lg p-4 border border-white/10">
                        <div className="flex items-start gap-3">
                          <div className="flex-shrink-0">
                            <div className="h-8 w-8 rounded-full bg-green-500/20 flex items-center justify-center">
                              <Activity className="h-4 w-4 text-green-500" />
                            </div>
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">{test.type}</span>
                              <span className="text-xs text-white/60">{test.date}</span>
                            </div>
                            <p className="text-sm mt-2">{test.result}</p>
                            <p className="text-xs text-white/60 mt-1">Ordered by: {test.orderedBy}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setHistoryDialogOpen(false)}
              className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Note Dialog */}
      <Dialog open={addNoteDialogOpen} onOpenChange={setAddNoteDialogOpen}>
        <DialogContent className="bg-slate-900 border-white/10 text-white">
          <DialogHeader>
            <DialogTitle>Add Medical Note</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="flex items-center gap-3 bg-white/5 p-3 rounded-lg">
              <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                <User className="h-5 w-5 text-pink-500" />
              </div>
              <div>
                <h3 className="font-medium">{selectedPatient?.name}</h3>
                <p className="text-sm text-white/70">{selectedPatient?.medicalCondition}</p>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm text-white/70">Medical Note</label>
              <textarea
                className="w-full bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white"
                rows={6}
                placeholder="Enter your medical notes here..."
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
              ></textarea>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setAddNoteDialogOpen(false)}
              className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            >
              Cancel
            </Button>
            <Button
              className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
              onClick={handleSubmitNote}
              disabled={addingNote}
            >
              {addingNote ? (
                <>
                  <Loader2 className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" />
                  Saving...
                </>
              ) : (
                "Save Note"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
