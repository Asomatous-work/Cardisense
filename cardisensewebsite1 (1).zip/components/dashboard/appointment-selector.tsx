"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, User, CheckCircle, AlertCircle, Loader2 } from "lucide-react"
import { doctors } from "@/lib/utils/doctor-data"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { bookAppointment, getAvailableAppointmentSlots } from "@/lib/actions/appointment-actions"
import { getAvailableCoupons, applyDiscountToAppointment } from "@/lib/actions/rewards-actions"

interface AppointmentSelectorProps {
  patientName: string
  patientId?: string
  patientEmail?: string
}

export function AppointmentSelector({ patientName, patientId, patientEmail }: AppointmentSelectorProps) {
  const { toast } = useToast()
  const [selectedDate, setSelectedDate] = useState<string | null>(null)
  const [selectedTime, setSelectedTime] = useState<string | null>(null)
  const [selectedDoctor, setSelectedDoctor] = useState<any | null>(null)
  const [availableDoctors, setAvailableDoctors] = useState<any[]>([])
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [appointmentType, setAppointmentType] = useState("Cardiology Checkup")
  const [availableTimeSlots, setAvailableTimeSlots] = useState<string[]>([])
  const [fetchingTimeSlots, setFetchingTimeSlots] = useState(false)
  const [availableCoupons, setAvailableCoupons] = useState<any[]>([])
  const [selectedCoupon, setSelectedCoupon] = useState<any | null>(null)
  const [fetchingCoupons, setFetchingCoupons] = useState(false)
  const [notes, setNotes] = useState("")

  // Filter to only show available doctors
  useEffect(() => {
    // In a real app, this would fetch from an API
    // For now, we'll use the mock data
    const available = doctors.filter((doctor) => doctor.available)

    // If no doctors are available, show all doctors anyway with a note
    if (available.length === 0) {
      setAvailableDoctors(
        doctors.map((doctor) => ({
          ...doctor,
          // Mark as limited availability
          availabilityNote: "Limited Availability",
        })),
      )
    } else {
      setAvailableDoctors(available)
    }
  }, [])

  // Fetch available coupons when component mounts
  useEffect(() => {
    const fetchCoupons = async () => {
      if (!patientId) return

      setFetchingCoupons(true)
      try {
        const result = await getAvailableCoupons(Number(patientId))
        if (result.success) {
          setAvailableCoupons(result.coupons || [])
        } else {
          console.error("Error fetching coupons:", result.error)
        }
      } catch (error) {
        console.error("Error fetching coupons:", error)
      } finally {
        setFetchingCoupons(false)
      }
    }

    fetchCoupons()
  }, [patientId])

  // Generate dates for the next 7 days
  const generateDates = () => {
    const dates = []
    const today = new Date()

    for (let i = 0; i < 7; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() + i)
      dates.push({
        date: date.toISOString().split("T")[0],
        day: date.toLocaleDateString("en-US", { weekday: "short" }),
        dayOfMonth: date.getDate(),
      })
    }

    return dates
  }

  const handleDateSelect = async (date: string) => {
    setSelectedDate(date)
    setSelectedTime(null) // Reset time when date changes

    if (selectedDoctor) {
      // Fetch available time slots for this doctor and date
      await fetchAvailableTimeSlots(selectedDoctor.id, date)
    }
  }

  const fetchAvailableTimeSlots = async (doctorId: number, date: string) => {
    setFetchingTimeSlots(true)
    setAvailableTimeSlots([])

    try {
      const result = await getAvailableAppointmentSlots(doctorId, date)
      if (result.success) {
        setAvailableTimeSlots(result.availableSlots || [])
      } else {
        console.error("Error fetching time slots:", result.error)
        toast({
          title: "Error",
          description: "Failed to fetch available time slots. Using demo data instead.",
          variant: "destructive",
        })
        // Fallback to demo data
        setAvailableTimeSlots(["9:00", "10:30", "13:00", "14:30", "16:00"])
      }
    } catch (error) {
      console.error("Error fetching time slots:", error)
      // Fallback to demo data
      setAvailableTimeSlots(["9:00", "10:30", "13:00", "14:30", "16:00"])
    } finally {
      setFetchingTimeSlots(false)
    }
  }

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time)
  }

  const handleDoctorSelect = async (doctor: any) => {
    setSelectedDoctor(doctor)

    if (selectedDate) {
      // Fetch available time slots for this doctor and the selected date
      await fetchAvailableTimeSlots(doctor.id, selectedDate)
    }
  }

  const handleCouponSelect = (coupon: any) => {
    setSelectedCoupon(coupon)
  }

  const handleConfirmAppointment = () => {
    if (!selectedDate || !selectedTime || !selectedDoctor) {
      toast({
        title: "Missing Information",
        description: "Please select a date, time, and doctor for your appointment.",
        variant: "destructive",
      })
      return
    }

    setConfirmDialogOpen(true)
  }

  const handleSubmitAppointment = async () => {
    if (!patientId || !patientEmail) {
      toast({
        title: "Missing Information",
        description: "Patient information is incomplete. Please update your profile.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    try {
      // Book the appointment
      const result = await bookAppointment({
        patientId: Number(patientId),
        patientName,
        patientEmail,
        doctorId: selectedDoctor.id,
        doctorName: selectedDoctor.name,
        appointmentType,
        appointmentDate: selectedDate!,
        appointmentTime: selectedTime!,
        notes,
      })

      if (result.success) {
        // If a coupon was selected, apply it to the appointment
        if (selectedCoupon) {
          const discountResult = await applyDiscountToAppointment(result.appointmentId, selectedCoupon.id)

          if (discountResult.success) {
            toast({
              title: "Discount Applied",
              description: discountResult.message,
              variant: "default",
            })
          } else {
            console.error("Error applying discount:", discountResult.error)
            toast({
              title: "Discount Error",
              description: "Your appointment was booked, but we couldn't apply the discount. Please try again later.",
              variant: "destructive",
            })
          }
        }

        toast({
          title: "Appointment Booked",
          description: result.message,
          variant: "default",
        })

        // Reset selections
        setSelectedDate(null)
        setSelectedTime(null)
        setSelectedDoctor(null)
        setSelectedCoupon(null)
        setNotes("")
        setConfirmDialogOpen(false)
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to book appointment. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error booking appointment:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const dates = generateDates()

  return (
    <>
      <Card className="bg-white/5 border-white/10">
        {/* Pending Appointment Requests */}
        <div className="mb-6">
          <h3 className="text-lg font-medium mb-3">Your Pending Requests</h3>
          <div className="space-y-3">
            <div className="bg-white/10 rounded-lg p-4 border border-amber-500/30">
              <div className="flex items-start justify-between">
                <div className="flex gap-3">
                  <div className="h-10 w-10 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                    <Clock className="h-5 w-5 text-amber-500" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium">Dr. KIRUPA D</h4>
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-xs font-medium">
                        Awaiting Response
                      </span>
                    </div>
                    <p className="text-sm text-white/70">Cardiology Checkup</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Calendar className="h-3 w-3 text-white/60" />
                      <span className="text-xs text-white/60">April 18, 2025</span>
                      <Clock className="h-3 w-3 text-white/60 ml-2" />
                      <span className="text-xs text-white/60">10:30 AM</span>
                    </div>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-8 border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                  onClick={() => {
                    toast({
                      title: "Appointment Cancelled",
                      description: "Your appointment request has been cancelled.",
                      variant: "default",
                    })
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Rescheduled Appointments */}
        <div className="mb-6">
          <h3 className="text-lg font-medium mb-3">Rescheduled Appointments</h3>
          <div className="space-y-3">
            <div className="bg-white/10 rounded-lg p-4 border border-cyan-500/30">
              <div className="flex items-start justify-between">
                <div className="flex gap-3">
                  <div className="h-10 w-10 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                    <Calendar className="h-5 w-5 text-cyan-500" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium">Dr. JEYASURYA S</h4>
                      <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-medium">
                        Rescheduled
                      </span>
                    </div>
                    <p className="text-sm text-white/70">Follow-up Consultation</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Calendar className="h-3 w-3 text-white/60" />
                      <span className="text-xs text-white/60">April 20, 2025</span>
                      <Clock className="h-3 w-3 text-white/60 ml-2" />
                      <span className="text-xs text-white/60">2:00 PM</span>
                    </div>
                    <p className="text-xs text-white/60 mt-2 bg-white/5 p-2 rounded">
                      <span className="font-medium">Doctor's note:</span> I need to reschedule due to an emergency. I've
                      suggested a new time that works with my schedule.
                    </p>
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <Button
                    size="sm"
                    className="h-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                    onClick={() => {
                      toast({
                        title: "Appointment Confirmed",
                        description: "You have accepted the rescheduled appointment.",
                        variant: "default",
                      })
                    }}
                  >
                    Accept
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                    onClick={() => {
                      toast({
                        title: "Appointment Declined",
                        description: "You have declined the rescheduled appointment.",
                        variant: "default",
                      })
                    }}
                  >
                    Decline
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <CardContent className="p-6">
          <h2 className="text-xl font-bold mb-4">Schedule an Appointment</h2>

          <div className="space-y-6">
            {/* Appointment Type */}
            <div>
              <h3 className="text-lg font-medium mb-3">Step 1: Select Appointment Type</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {["Cardiology Checkup", "Follow-up Consultation", "Emergency Consultation"].map((type) => (
                  <div
                    key={type}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      appointmentType === type
                        ? "bg-pink-900/30 border-pink-500/50"
                        : "bg-white/5 border-white/10 hover:bg-white/10"
                    }`}
                    onClick={() => setAppointmentType(type)}
                  >
                    <div className="font-medium">{type}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Available Doctors */}
            <div>
              <h3 className="text-lg font-medium mb-3">Step 2: Select Doctor</h3>
              {availableDoctors.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {availableDoctors.map((doctor) => (
                    <div
                      key={doctor.id}
                      className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                        selectedDoctor?.id === doctor.id
                          ? "bg-pink-900/30 border-pink-500/50"
                          : "bg-white/5 border-white/10 hover:bg-white/10"
                      }`}
                      onClick={() => handleDoctorSelect(doctor)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
                          <User className="h-5 w-5 text-cyan-500" />
                        </div>
                        <div>
                          <div className="font-medium">Dr. {doctor.name}</div>
                          <div className="text-sm text-white/70">{doctor.specialty}</div>
                          <div className="flex items-center gap-1 mt-1">
                            {doctor.availabilityNote ? (
                              <>
                                <Clock className="h-3 w-3 text-amber-500" />
                                <span className="text-xs text-amber-500">{doctor.availabilityNote}</span>
                              </>
                            ) : doctor.available ? (
                              <>
                                <CheckCircle className="h-3 w-3 text-green-500" />
                                <span className="text-xs text-green-500">Available</span>
                              </>
                            ) : (
                              <>
                                <Clock className="h-3 w-3 text-amber-500" />
                                <span className="text-xs text-amber-500">Limited Availability</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-white">No Doctors Available</h4>
                      <p className="text-white/70 text-sm">
                        There are currently no doctors available for appointments. Please try again later.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Date Selection */}
            <div>
              <h3 className="text-lg font-medium mb-3">Step 3: Select Date</h3>
              <div className="grid grid-cols-7 gap-2">
                {dates.map((date) => (
                  <div
                    key={date.date}
                    className={`text-center p-2 rounded cursor-pointer transition-colors ${
                      selectedDate === date.date
                        ? "bg-pink-900/30 border border-pink-500/50"
                        : "bg-white/5 border border-white/10 hover:bg-white/10"
                    }`}
                    onClick={() => handleDateSelect(date.date)}
                  >
                    <div className="text-xs text-white/70">{date.day}</div>
                    <div className={`text-sm ${selectedDate === date.date ? "text-pink-400" : "text-white"}`}>
                      {date.dayOfMonth}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Time Selection */}
            {selectedDate && (
              <div>
                <h3 className="text-lg font-medium mb-3">Step 4: Select Time</h3>
                {fetchingTimeSlots ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-8 w-8 animate-spin text-pink-500" />
                  </div>
                ) : availableTimeSlots.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                    {availableTimeSlots.map((time) => (
                      <div
                        key={time}
                        className={`text-center p-2 rounded cursor-pointer transition-colors ${
                          selectedTime === time
                            ? "bg-pink-900/30 border border-pink-500/50 text-pink-400"
                            : "bg-white/5 border border-white/10 hover:bg-white/10 text-white"
                        }`}
                        onClick={() => handleTimeSelect(time)}
                      >
                        {time}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-white">No Available Time Slots</h4>
                        <p className="text-white/70 text-sm">
                          There are no available time slots for this doctor on the selected date. Please select a
                          different date.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Available Coupons */}
            {availableCoupons.length > 0 && (
              <div>
                <h3 className="text-lg font-medium mb-3">Step 5: Apply Discount (Optional)</h3>
                {fetchingCoupons ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-8 w-8 animate-spin text-pink-500" />
                  </div>
                ) : (
                  <div className="space-y-3">
                    {availableCoupons.map((coupon) => (
                      <div
                        key={coupon.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          selectedCoupon?.id === coupon.id
                            ? "bg-pink-900/30 border-pink-500/50"
                            : "bg-white/5 border-white/10 hover:bg-white/10"
                        }`}
                        onClick={() => handleCouponSelect(coupon)}
                      >
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="font-medium">{coupon.rewards.name}</div>
                            <div className="text-sm text-white/70">
                              {coupon.rewards.discount_type === "percentage"
                                ? `${coupon.rewards.discount_amount}% off`
                                : `₹${coupon.rewards.discount_amount} off`}
                            </div>
                          </div>
                          <div className="text-xs text-white/60">
                            Expires: {new Date(coupon.expiry_date).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Notes */}
            <div>
              <h3 className="text-lg font-medium mb-3">Step 6: Additional Notes (Optional)</h3>
              <textarea
                className="w-full bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white"
                rows={3}
                placeholder="Any specific concerns or information you'd like to share with the doctor..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              ></textarea>
            </div>

            {/* Submit Button */}
            <Button
              className="w-full mt-4 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
              onClick={handleConfirmAppointment}
              disabled={!selectedDate || !selectedTime || !selectedDoctor}
            >
              Request Appointment
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      <Dialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
        <DialogContent className="bg-slate-900 border-white/10 text-white">
          <DialogHeader>
            <DialogTitle>Confirm Appointment Request</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="bg-white/10 rounded-lg p-4 border border-white/10">
              <h3 className="font-medium text-lg mb-2">Appointment Details</h3>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-white/60" />
                  <span className="text-white/70">Patient:</span>
                  <span className="font-medium">{patientName}</span>
                </div>

                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-white/60" />
                  <span className="text-white/70">Doctor:</span>
                  <span className="font-medium">Dr. {selectedDoctor?.name}</span>
                </div>

                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-white/60" />
                  <span className="text-white/70">Date:</span>
                  <span className="font-medium">{selectedDate}</span>
                </div>

                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-white/60" />
                  <span className="text-white/70">Time:</span>
                  <span className="font-medium">{selectedTime}</span>
                </div>

                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-white/60" />
                  <span className="text-white/70">Type:</span>
                  <span className="font-medium">{appointmentType}</span>
                </div>

                {selectedCoupon && (
                  <div className="flex items-center gap-2">
                    <span className="text-white/70">Discount:</span>
                    <span className="font-medium text-green-400">
                      {selectedCoupon.rewards.discount_type === "percentage"
                        ? `${selectedCoupon.rewards.discount_amount}% off`
                        : `₹${selectedCoupon.rewards.discount_amount} off`}
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-white/5 rounded-lg p-4 border border-white/10">
              <p className="text-sm text-white/80">
                By confirming, you are requesting an appointment with the doctor. The doctor will need to approve this
                request before it's confirmed. A confirmation email will be sent to your registered email address.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setConfirmDialogOpen(false)}
              className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            >
              Cancel
            </Button>
            <Button
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
              onClick={handleSubmitAppointment}
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                "Confirm Request"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
