"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, Users, Search } from "lucide-react"

export function AppointmentRequests() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filter, setFilter] = useState("all")

  const appointments = [
    {
      id: 1,
      patient: "Rajesh Kumar",
      type: "Cardiology Checkup",
      date: "Apr 15, 2025",
      time: "10:30 AM",
      status: "pending",
      notes: "First-time patient, complaining of occasional chest pain",
    },
    {
      id: 2,
      patient: "Priya Sharma",
      type: "Follow-up Consultation",
      date: "Apr 16, 2025",
      time: "2:00 PM",
      status: "pending",
      notes: "Follow-up after medication change, needs to discuss side effects",
    },
    {
      id: 3,
      patient: "Suresh Patel",
      type: "Emergency Consultation",
      date: "Apr 14, 2025",
      time: "4:15 PM",
      status: "urgent",
      notes: "Experiencing severe chest pain and shortness of breath",
    },
    {
      id: 4,
      patient: "Ananya Desai",
      type: "Blood Pressure Check",
      date: "Apr 17, 2025",
      time: "11:00 AM",
      status: "pending",
      notes: "Regular BP monitoring, history of hypertension",
    },
    {
      id: 5,
      patient: "Vikram Singh",
      type: "ECG Review",
      date: "Apr 18, 2025",
      time: "9:30 AM",
      status: "pending",
      notes: "Review of recent ECG results from local clinic",
    },
  ]

  const filteredAppointments = appointments.filter((appointment) => {
    const matchesSearch =
      appointment.patient.toLowerCase().includes(searchQuery.toLowerCase()) ||
      appointment.type.toLowerCase().includes(searchQuery.toLowerCase())

    if (filter === "all") return matchesSearch
    if (filter === "urgent") return matchesSearch && appointment.status === "urgent"
    if (filter === "pending") return matchesSearch && appointment.status === "pending"

    return matchesSearch
  })

  return (
    <Card className="bg-white/5 border-white/10 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Calendar className="h-5 w-5 text-cyan-500" />
          <span>Appointment Requests</span>
        </h2>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40" />
            <input
              type="text"
              placeholder="Search patients..."
              className="bg-white/10 border border-white/20 rounded-md pl-9 pr-4 py-1 text-sm text-white w-48"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <select
            className="bg-white/10 border border-white/20 rounded-md px-3 py-1 text-sm text-white"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All Requests</option>
            <option value="urgent">Urgent Only</option>
            <option value="pending">Pending Only</option>
          </select>
        </div>
      </div>

      <div className="space-y-4">
        {filteredAppointments.length > 0 ? (
          filteredAppointments.map((appointment) => (
            <div
              key={appointment.id}
              className={`bg-white/10 rounded-lg p-4 border ${
                appointment.status === "urgent" ? "border-red-500/30" : "border-white/10"
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex gap-3">
                  <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                    <Users className="h-5 w-5 text-pink-500" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium">{appointment.patient}</h3>
                      {appointment.status === "urgent" && (
                        <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-xs font-medium">
                          Urgent
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-white/70">{appointment.type}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-white/60" />
                        <span className="text-xs text-white/60">{appointment.date}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3 text-white/60" />
                        <span className="text-xs text-white/60">{appointment.time}</span>
                      </div>
                    </div>
                    <p className="text-xs text-white/60 mt-2">{appointment.notes}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className={`h-8 ${
                      appointment.status === "urgent"
                        ? "bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400"
                        : "bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                    }`}
                  >
                    Accept
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                  >
                    Decline
                  </Button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-white/60">
            <Calendar className="h-12 w-12 mx-auto mb-3 text-white/30" />
            <p>No appointment requests found</p>
            <p className="text-sm mt-1">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </Card>
  )
}
