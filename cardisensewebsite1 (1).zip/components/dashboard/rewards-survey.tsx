"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trophy, CheckCircle, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { completeSurvey } from "@/lib/actions/rewards-actions"

interface RewardsSurveyProps {
  patientId: number
  patientName: string
}

export function RewardsSurvey({ patientId, patientName }: RewardsSurveyProps) {
  const { toast } = useToast()
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string | number>>({})
  const [loading, setLoading] = useState(false)
  const [completed, setCompleted] = useState(false)
  const [pointsAwarded, setPointsAwarded] = useState(0)

  // Sample survey questions
  const surveyQuestions = [
    {
      id: "q1",
      question: "How would you rate your overall experience with CARDISENSE?",
      type: "rating",
      options: [1, 2, 3, 4, 5],
    },
    {
      id: "q2",
      question: "How often do you use the CARDISENSE app?",
      type: "choice",
      options: ["Daily", "Weekly", "Monthly", "Rarely"],
    },
    {
      id: "q3",
      question: "Which feature do you find most useful?",
      type: "choice",
      options: ["NFC Medical Card", "Medical Reports", "Appointments", "Insurance", "Rewards"],
    },
    {
      id: "q4",
      question: "How likely are you to recommend CARDISENSE to friends or family?",
      type: "rating",
      options: [1, 2, 3, 4, 5],
    },
    {
      id: "q5",
      question: "What improvements would you like to see in CARDISENSE?",
      type: "text",
    },
  ]

  const handleAnswer = (questionId: string, answer: string | number) => {
    setAnswers({
      ...answers,
      [questionId]: answer,
    })
  }

  const handleNext = () => {
    if (currentQuestion < surveyQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      handleSubmit()
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleSubmit = async () => {
    setLoading(true)
    try {
      const result = await completeSurvey({
        patientId,
        surveyId: 1, // Using a fixed survey ID for this example
        responses: answers,
      })

      if (result.success) {
        setCompleted(true)
        setPointsAwarded(result.pointsAwarded || 50)
        toast({
          title: "Survey Completed",
          description: result.message,
          variant: "default",
        })
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to submit survey. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error submitting survey:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const currentQuestionData = surveyQuestions[currentQuestion]
  const isLastQuestion = currentQuestion === surveyQuestions.length - 1
  const canProceed = answers[currentQuestionData.id] !== undefined

  if (completed) {
    return (
      <Card className="bg-white/5 border-white/10">
        <CardContent className="p-6 text-center">
          <div className="flex flex-col items-center justify-center py-8">
            <div className="h-16 w-16 rounded-full bg-green-500/20 flex items-center justify-center mb-4">
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Thank You!</h2>
            <p className="text-white/70 mb-4">Your feedback is valuable to us.</p>

            <div className="bg-gradient-to-br from-amber-500/20 to-pink-500/20 border border-white/10 rounded-xl p-6 mb-6 max-w-md">
              <div className="flex items-center gap-4 mb-2">
                <Trophy className="h-8 w-8 text-amber-400" />
                <div>
                  <h3 className="text-xl font-medium text-white">Points Awarded</h3>
                </div>
              </div>
              <p className="text-3xl font-bold text-amber-400">+{pointsAwarded}</p>
              <p className="text-white/70 mt-2">Points have been added to your account</p>
            </div>

            <Button
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
              onClick={() => window.location.reload()}
            >
              Take Another Survey
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-white/5 border-white/10">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">Health & Wellness Survey</h2>
          <div className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-amber-400" />
            <span className="text-amber-400 font-medium">50 points</span>
          </div>
        </div>

        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-white/70">
              Question {currentQuestion + 1} of {surveyQuestions.length}
            </span>
            <span className="text-white/70">
              {Math.round(((currentQuestion + 1) / surveyQuestions.length) * 100)}% Complete
            </span>
          </div>
          <div className="w-full bg-white/10 h-2 rounded-full">
            <div
              className="h-full bg-gradient-to-r from-pink-500 to-purple-500 rounded-full transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / surveyQuestions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-lg font-medium mb-4">{currentQuestionData.question}</h3>

          {currentQuestionData.type === "rating" && (
            <div className="flex justify-center gap-4 my-6">
              {currentQuestionData.options.map((option) => (
                <button
                  key={option}
                  className={`h-12 w-12 rounded-full flex items-center justify-center text-lg font-medium transition-all ${
                    answers[currentQuestionData.id] === option
                      ? "bg-gradient-to-r from-pink-600 to-purple-600 text-white"
                      : "bg-white/10 text-white/70 hover:bg-white/20"
                  }`}
                  onClick={() => handleAnswer(currentQuestionData.id, option)}
                >
                  {option}
                </button>
              ))}
            </div>
          )}

          {currentQuestionData.type === "choice" && (
            <div className="space-y-3 my-6">
              {currentQuestionData.options.map((option) => (
                <button
                  key={option}
                  className={`w-full p-3 rounded-lg border text-left transition-colors ${
                    answers[currentQuestionData.id] === option
                      ? "bg-pink-900/30 border-pink-500/50 text-white"
                      : "bg-white/5 border-white/10 hover:bg-white/10 text-white/70"
                  }`}
                  onClick={() => handleAnswer(currentQuestionData.id, option)}
                >
                  {option}
                </button>
              ))}
            </div>
          )}

          {currentQuestionData.type === "text" && (
            <div className="my-6">
              <textarea
                className="w-full bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white min-h-[100px]"
                placeholder="Type your answer here..."
                value={(answers[currentQuestionData.id] as string) || ""}
                onChange={(e) => handleAnswer(currentQuestionData.id, e.target.value)}
              ></textarea>
            </div>
          )}
        </div>

        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0 || loading}
            className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
          >
            Previous
          </Button>
          <Button
            onClick={handleNext}
            disabled={!canProceed || loading}
            className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : isLastQuestion ? (
              "Submit"
            ) : (
              "Next"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
