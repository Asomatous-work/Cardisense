"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Bell, Calendar, MessageSquare, AlertCircle, CheckCircle, Clock, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function NotificationsPanel() {
  const { toast } = useToast()
  const [notifications, setNotifications] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  // Fetch notifications
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        // In a real application, you would fetch notifications from the database
        // For now, we'll just use sample data

        // Simulate API delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        setNotifications(getSampleNotifications())
      } catch (error) {
        console.error("Error fetching notifications:", error)
        toast({
          title: "Error",
          description: "Failed to fetch notifications. Please try again.",
          variant: "destructive",
        })

        // Set some sample data for demonstration
        setNotifications(getSampleNotifications())
      } finally {
        setLoading(false)
      }
    }

    fetchData()

    // Set up a polling interval to simulate real-time updates
    const interval = setInterval(() => {
      // 20% chance to add a new notification
      if (Math.random() < 0.2) {
        addRandomNotification()
      }
    }, 30000)

    return () => clearInterval(interval)
  }, [toast])

  // Sample data for demonstration
  const getSampleNotifications = () => {
    return [
      {
        id: 1,
        type: "appointment",
        message: "New appointment request from Sethu Raja P",
        time: "5 minutes ago",
        read: false,
        urgent: true,
      },
      {
        id: 2,
        type: "message",
        message: "Aravind G sent you a message",
        time: "10 minutes ago",
        read: false,
        urgent: false,
      },
      {
        id: 3,
        type: "alert",
        message: "Rafikhan L's blood pressure reading is high",
        time: "30 minutes ago",
        read: true,
        urgent: true,
      },
      {
        id: 4,
        type: "appointment",
        message: "Appointment with Aravind G confirmed",
        time: "1 hour ago",
        read: true,
        urgent: false,
      },
      {
        id: 5,
        type: "system",
        message: "System maintenance scheduled for tonight",
        time: "2 hours ago",
        read: true,
        urgent: false,
      },
    ]
  }

  const addRandomNotification = () => {
    const notificationTypes = ["appointment", "message", "alert", "system"]
    const type = notificationTypes[Math.floor(Math.random() * notificationTypes.length)]

    const patients = ["Aravind G", "Rafikhan L", "Sethu Raja P"]
    const patient = patients[Math.floor(Math.random() * patients.length)]

    let message = ""
    let urgent = Math.random() < 0.3 // 30% chance of being urgent

    switch (type) {
      case "appointment":
        message = `New appointment request from ${patient}`
        break
      case "message":
        message = `${patient} sent you a message`
        break
      case "alert":
        message = `${patient}'s heart rate is abnormal`
        urgent = true
        break
      case "system":
        message = "New lab results available for review"
        break
    }

    const newNotification = {
      id: Date.now(),
      type,
      message,
      time: "Just now",
      read: false,
      urgent,
    }

    setNotifications((prev) => [newNotification, ...prev])

    if (urgent) {
      toast({
        title: "Urgent Notification",
        description: message,
        variant: "destructive",
      })
    }
  }

  const handleMarkAsRead = (id: number) => {
    setNotifications(
      notifications.map((notification) => (notification.id === id ? { ...notification, read: true } : notification)),
    )
  }

  const handleMarkAllAsRead = () => {
    setNotifications(notifications.map((notification) => ({ ...notification, read: true })))

    toast({
      title: "Notifications Cleared",
      description: "All notifications have been marked as read.",
      variant: "default",
    })
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "appointment":
        return <Calendar className="h-4 w-4 text-cyan-500" />
      case "message":
        return <MessageSquare className="h-4 w-4 text-pink-500" />
      case "alert":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case "system":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      default:
        return <Bell className="h-4 w-4 text-white" />
    }
  }

  const unreadCount = notifications.filter((notification) => !notification.read).length

  return (
    <Card className="bg-white/5 border-white/10 p-6 h-full">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Bell className="h-5 w-5 text-cyan-500" />
          <span>Notifications</span>
          {unreadCount > 0 && (
            <span className="bg-cyan-500 text-white text-xs font-medium rounded-full h-5 min-w-5 flex items-center justify-center px-1.5">
              {unreadCount}
            </span>
          )}
        </h2>
        {notifications.length > 0 && (
          <Button
            size="sm"
            variant="ghost"
            className="h-8 text-white/70 hover:bg-white/10 hover:text-white"
            onClick={handleMarkAllAsRead}
          >
            Clear All
          </Button>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-cyan-500" />
        </div>
      ) : (
        <>
          {notifications.length > 0 ? (
            <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`rounded-lg p-3 border ${
                    notification.read
                      ? "bg-white/5 border-white/10"
                      : notification.urgent
                        ? "bg-red-950/20 border-red-500/30"
                        : "bg-white/10 border-white/20"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="h-8 w-8 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm ${notification.read ? "text-white/70" : "text-white"}`}>
                        {notification.message}
                      </p>
                      <div className="flex items-center justify-between mt-1">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3 text-white/60" />
                          <span className="text-xs text-white/60">{notification.time}</span>
                        </div>
                        {!notification.read && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-6 text-xs text-white/70 hover:bg-white/10 hover:text-white"
                            onClick={() => handleMarkAsRead(notification.id)}
                          >
                            Mark as read
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-white/60 bg-white/5 rounded-lg border border-white/10">
              <Bell className="h-12 w-12 mx-auto mb-3 text-white/30" />
              <p>No notifications</p>
              <p className="text-sm mt-1">You're all caught up!</p>
            </div>
          )}
        </>
      )}
    </Card>
  )
}
