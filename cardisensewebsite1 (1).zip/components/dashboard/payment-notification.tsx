"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { DollarSign, X, QrCode, Copy, CheckCircle2, ExternalLink, Loader2 } from "lucide-react"
import { generateUPIQRCode } from "@/lib/utils/payment-utils"
import { getDoctorUpiId } from "@/lib/utils/doctor-data"
import { useDeviceType } from "@/hooks/use-device-type"

interface PaymentNotificationProps {
  doctor: string
  service: string
  amount: number
  upiId?: string
  onClose: () => void
  isDialog?: boolean
}

export function PaymentNotification({
  doctor,
  service,
  amount,
  upiId,
  onClose,
  isDialog = false,
}: PaymentNotificationProps) {
  const { isMobile } = useDeviceType()
  const [upiCopied, setUpiCopied] = useState(false)
  const [qrCodeUrl, setQrCodeUrl] = useState<string>("")
  const [isGenerating, setIsGenerating] = useState(true)

  // Get the doctor's UPI ID from our data or use the provided one
  const doctorUpiId = upiId || getDoctorUpiId(doctor)

  useEffect(() => {
    async function generateQRCode() {
      setIsGenerating(true)
      try {
        const qrCode = await generateUPIQRCode({
          upiId: doctorUpiId,
          amount,
          name: `Dr. ${doctor}`,
          transactionNote: `Payment for ${service}`,
        })
        setQrCodeUrl(qrCode)
      } catch (error) {
        console.error("Failed to generate QR code:", error)
      } finally {
        setIsGenerating(false)
      }
    }

    generateQRCode()
  }, [doctor, service, amount, doctorUpiId])

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(doctorUpiId)
    setUpiCopied(true)
    setTimeout(() => setUpiCopied(false), 2000)
  }

  const handleOpenUpiApp = () => {
    const upiLink = `upi://pay?pa=${encodeURIComponent(doctorUpiId)}&pn=${encodeURIComponent(
      `Dr. ${doctor}`,
    )}&am=${amount}&tn=${encodeURIComponent(`Payment for ${service}`)}&cu=INR`

    window.location.href = upiLink
  }

  // If it's in a dialog, we don't need the Card wrapper
  const content = (
    <div className="space-y-4">
      {!isDialog && (
        <button onClick={onClose} className="absolute top-3 right-3 text-white/60 hover:text-white">
          <X className="h-5 w-5" />
        </button>
      )}

      <div className="flex items-center gap-3 mb-4">
        <div className="h-10 w-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
          <DollarSign className="h-5 w-5 text-cyan-500" />
        </div>
        <div>
          <h3 className="text-lg font-medium">Payment Request</h3>
          <p className="text-sm text-white/70">From Dr. {doctor}</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="bg-white/10 rounded-lg p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-white/70">Service</span>
            <span className="font-medium">{service}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-white/70">Amount</span>
            <span className="text-xl font-bold">₹{amount}</span>
          </div>
        </div>

        <div className="bg-white/10 rounded-lg p-4">
          <h4 className="text-sm font-medium mb-3">Pay using UPI</h4>
          <div className="flex items-center justify-center mb-4">
            {isGenerating ? (
              <div className="bg-white p-4 rounded-lg flex items-center justify-center w-[200px] h-[200px]">
                <Loader2 className="h-8 w-8 animate-spin text-slate-900" />
              </div>
            ) : qrCodeUrl ? (
              <div className="bg-white p-4 rounded-lg">
                <img src={qrCodeUrl || "/placeholder.svg"} alt="UPI Payment QR Code" className="w-[200px] h-[200px]" />
              </div>
            ) : (
              <div className="bg-white p-4 rounded-lg flex items-center justify-center w-[200px] h-[200px]">
                <QrCode className="h-32 w-32 text-slate-900" />
                <div className="absolute text-xs text-red-500">Failed to generate QR</div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={doctorUpiId}
              readOnly
              className="flex-1 bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white"
            />
            <Button
              size="sm"
              variant="outline"
              className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
              onClick={handleCopyUpi}
            >
              {upiCopied ? <CheckCircle2 className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            </Button>
          </div>
          <p className="text-xs text-white/60 mt-2">Scan the QR code or use the UPI ID to make the payment</p>
        </div>

        <div className="flex gap-3">
          <Button
            className="flex-1 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
            onClick={handleOpenUpiApp}
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Open UPI App
          </Button>
          <Button variant="outline" className="flex-1 border-white/20 text-white/70 hover:bg-white/10 hover:text-white">
            Pay Later
          </Button>
        </div>
      </div>
    </div>
  )

  if (isDialog) {
    return content
  }

  return <Card className="bg-white/5 border-white/10 p-6 relative">{content}</Card>
}
