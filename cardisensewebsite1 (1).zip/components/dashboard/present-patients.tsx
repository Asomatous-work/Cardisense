"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { User, Clock, Calendar, Heart, Activity, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { createClientSupabaseClient } from "@/lib/supabase/client"

export function PresentPatients() {
  const { toast } = useToast()
  const [patients, setPatients] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedPatient, setSelectedPatient] = useState<any | null>(null)
  const [detailsOpen, setDetailsOpen] = useState(false)
  const [vitalSigns, setVitalSigns] = useState({
    heartRate: 0,
    bloodPressure: "",
    oxygenSaturation: 0,
    temperature: 0,
  })

  // Fetch patients from the database
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()

        // Fetch patients who are present
        const { data, error } = await supabase.from("patients").select("*").eq("is_present", true).order("name")

        if (error) {
          throw error
        }

        // Transform the data
        const formattedData = (data || []).map((patient) => ({
          id: patient.id,
          name: patient.name,
          appointmentTime: patient.appointment_time || "No time set",
          medicalCondition: patient.medical_condition || "No condition specified",
          contactNumber: patient.contact_number || "No contact number",
          lastVisit: patient.last_visit ? new Date(patient.last_visit).toLocaleDateString() : "First visit",
          status: patient.status || "active",
        }))

        setPatients(formattedData)
      } catch (error) {
        console.error("Error fetching patients:", error)
        toast({
          title: "Error",
          description: "Failed to fetch patients. Please try again.",
          variant: "destructive",
        })

        // Set some sample data for demonstration
        setPatients(getSamplePatients())
      } finally {
        setLoading(false)
      }
    }

    fetchData()

    // Set up real-time subscription
    const supabase = createClientSupabaseClient()
    const subscription = supabase
      .channel("patients-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "patients",
          filter: "is_present=eq.true",
        },
        (payload) => {
          fetchData()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(subscription)
    }
  }, [toast])

  // Sample data for demonstration when database is not available
  const getSamplePatients = () => {
    return [
      {
        id: 1,
        name: "Aravind G",
        appointmentTime: "10:30 AM",
        medicalCondition: "Hypertension, Diabetes",
        contactNumber: "+91 9876543210",
        lastVisit: "15 Mar 2025",
        status: "active",
      },
      {
        id: 2,
        name: "Rafikhan L",
        appointmentTime: "2:00 PM",
        medicalCondition: "Post-surgery follow-up",
        contactNumber: "+91 9876543211",
        lastVisit: "2 Apr 2025",
        status: "active",
      },
    ]
  }

  const handleViewDetails = (patient: any) => {
    setSelectedPatient(patient)

    // Generate random vital signs for demonstration
    setVitalSigns({
      heartRate: Math.floor(Math.random() * (100 - 60) + 60),
      bloodPressure: `${Math.floor(Math.random() * (140 - 110) + 110)}/${Math.floor(Math.random() * (90 - 70) + 70)}`,
      oxygenSaturation: Math.floor(Math.random() * (100 - 95) + 95),
      temperature: Number.parseFloat((Math.random() * (37.5 - 36.5) + 36.5).toFixed(1)),
    })

    setDetailsOpen(true)
  }

  const handleMarkComplete = async (patientId: number) => {
    try {
      const supabase = createClientSupabaseClient()

      // Update the patient's presence status
      const { error } = await supabase.from("patients").update({ is_present: false }).eq("id", patientId)

      if (error) {
        throw error
      }

      toast({
        title: "Patient Visit Completed",
        description: "The patient has been marked as not present.",
        variant: "default",
      })

      // Update the local state
      setPatients(patients.filter((p) => p.id !== patientId))
      setDetailsOpen(false)
    } catch (error) {
      console.error("Error marking patient visit as complete:", error)
      toast({
        title: "Error",
        description: "Failed to update patient status. Please try again.",
        variant: "destructive",
      })

      // Update the local state for demo purposes
      setPatients(patients.filter((p) => p.id !== patientId))
      setDetailsOpen(false)
    }
  }

  return (
    <>
      <Card className="bg-white/5 border-white/10 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <User className="h-5 w-5 text-cyan-500" />
            <span>Patients Currently Present</span>
          </h2>
          <div className="flex items-center gap-2">
            <div className="bg-white/10 text-white/70 px-3 py-1 rounded-full text-xs font-medium">
              {patients.length} Patients
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-cyan-500" />
          </div>
        ) : (
          <>
            {patients.length > 0 ? (
              <div className="space-y-4">
                {patients.map((patient) => (
                  <div key={patient.id} className="bg-white/10 rounded-lg p-4 border border-white/10">
                    <div className="flex items-start justify-between">
                      <div className="flex gap-3">
                        <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                          <User className="h-5 w-5 text-pink-500" />
                        </div>
                        <div>
                          <h3 className="font-medium">{patient.name}</h3>
                          <p className="text-sm text-white/70">{patient.medicalCondition}</p>
                          <div className="flex items-center gap-3 mt-1">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3 text-white/60" />
                              <span className="text-xs text-white/60">{patient.appointmentTime}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3 text-white/60" />
                              <span className="text-xs text-white/60">Last visit: {patient.lastVisit}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="h-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                        onClick={() => handleViewDetails(patient)}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-white/60 bg-white/5 rounded-lg border border-white/10">
                <User className="h-12 w-12 mx-auto mb-3 text-white/30" />
                <p>No patients currently present</p>
                <p className="text-sm mt-1">Patients will appear here when they check in</p>
              </div>
            )}
          </>
        )}
      </Card>

      {/* Patient Details Dialog */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="bg-slate-900 border-white/10 text-white">
          <DialogHeader>
            <DialogTitle>Patient Details</DialogTitle>
          </DialogHeader>

          {selectedPatient && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3 bg-white/5 p-3 rounded-lg">
                <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                  <User className="h-5 w-5 text-pink-500" />
                </div>
                <div>
                  <h3 className="font-medium">{selectedPatient.name}</h3>
                  <p className="text-sm text-white/70">{selectedPatient.medicalCondition}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 p-3 rounded-lg">
                  <div className="text-xs text-white/60 mb-1">Contact Number</div>
                  <div className="font-medium">{selectedPatient.contactNumber}</div>
                </div>
                <div className="bg-white/5 p-3 rounded-lg">
                  <div className="text-xs text-white/60 mb-1">Last Visit</div>
                  <div className="font-medium">{selectedPatient.lastVisit}</div>
                </div>
              </div>

              <div className="bg-white/5 p-4 rounded-lg">
                <h4 className="text-sm font-medium mb-3">Current Vital Signs</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <Heart className="h-4 w-4 text-red-400" />
                    <div>
                      <div className="text-xs text-white/60">Heart Rate</div>
                      <div className="font-medium">{vitalSigns.heartRate} bpm</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Activity className="h-4 w-4 text-green-400" />
                    <div>
                      <div className="text-xs text-white/60">Blood Pressure</div>
                      <div className="font-medium">{vitalSigns.bloodPressure} mmHg</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Activity className="h-4 w-4 text-blue-400" />
                    <div>
                      <div className="text-xs text-white/60">Oxygen Saturation</div>
                      <div className="font-medium">{vitalSigns.oxygenSaturation}%</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Activity className="h-4 w-4 text-yellow-400" />
                    <div>
                      <div className="text-xs text-white/60">Temperature</div>
                      <div className="font-medium">{vitalSigns.temperature}°C</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDetailsOpen(false)}
              className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            >
              Close
            </Button>
            <Button
              className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
              onClick={() => selectedPatient && handleMarkComplete(selectedPatient.id)}
            >
              Mark Visit Complete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
