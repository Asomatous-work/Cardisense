"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Settings, ArrowLeft, Loader2 } from "lucide-react"

interface MobileMenuButtonProps {
  isMobileMenuOpen: boolean
  toggleMobileMenu: () => void
}

export function MobileMenuButton({ isMobileMenuOpen, toggleMobileMenu }: MobileMenuButtonProps) {
  const [spinning, setSpinning] = useState(false)
  const router = useRouter()

  const handleClick = () => {
    setSpinning(true)
    setTimeout(() => {
      setSpinning(false)
      toggleMobileMenu()
    }, 500)
  }

  const handleBack = () => {
    router.back()
  }

  return (
    <div className="flex items-center gap-2">
      {isMobileMenuOpen ? (
        <>
          <Button variant="ghost" size="icon" onClick={handleBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <Settings className="h-5 w-5" />
          </Button>
        </>
      ) : (
        <Button
          onClick={handleClick}
          className="flex items-center justify-center w-10 h-10 rounded-full bg-slate-800 border border-white/10 shadow-lg"
          aria-label="Open menu"
          disabled={spinning}
        >
          {spinning ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <img src="/icons/icon-72x72.png" alt="CARDISENSE" className="w-8 h-8" />
          )}
        </Button>
      )}
    </div>
  )
}
