"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Printer, Share2, User, Heart, Activity, AlertCircle } from "lucide-react"

interface TestResult {
  name: string
  value: string
  unit: string
  normalRange: string
  status: "normal" | "high" | "low" | "critical"
}

interface MedicalReportProps {
  patientName: string
  patientId: string
  reportName: string
  reportDate: string
  doctorName: string
  hospitalName: string
  resultData: {
    [category: string]: TestResult[]
  }
}

export function MedicalReport({
  patientName,
  patientId,
  reportName,
  reportDate,
  doctorName,
  hospitalName,
  resultData,
}: MedicalReportProps) {
  const [activeTab, setActiveTab] = useState<string>(Object.keys(resultData)[0])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "normal":
        return "text-green-500"
      case "high":
        return "text-amber-500"
      case "low":
        return "text-blue-500"
      case "critical":
        return "text-red-500"
      default:
        return "text-white"
    }
  }

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader className="bg-gradient-to-r from-slate-800 to-slate-900 border-b border-white/10">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-2xl font-bold text-white mb-1">{reportName}</CardTitle>
            <p className="text-white/70">Report Date: {reportDate}</p>
          </div>
          <div className="flex space-x-2">
            <Button size="sm" variant="outline" className="border-pink-500/40 text-pink-400 hover:bg-pink-500/10">
              <Download className="h-4 w-4 mr-1" /> PDF
            </Button>
            <Button size="sm" variant="outline" className="border-pink-500/40 text-pink-400 hover:bg-pink-500/10">
              <Printer className="h-4 w-4 mr-1" /> Print
            </Button>
            <Button size="sm" variant="outline" className="border-pink-500/40 text-pink-400 hover:bg-pink-500/10">
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-6">
        {/* Patient and Hospital Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="bg-white/10 rounded-lg p-4 border border-white/10">
            <h3 className="text-md font-semibold flex items-center gap-2 mb-4">
              <User className="h-5 w-5 text-pink-500" />
              <span>Patient Information</span>
            </h3>
            <div className="grid grid-cols-2 gap-y-2">
              <div className="text-white/70">Name:</div>
              <div className="font-medium">{patientName}</div>

              <div className="text-white/70">Patient ID:</div>
              <div className="font-medium">{patientId}</div>

              <div className="text-white/70">Gender:</div>
              <div className="font-medium">Male</div>

              <div className="text-white/70">Age:</div>
              <div className="font-medium">32 years</div>
            </div>
          </div>

          <div className="bg-white/10 rounded-lg p-4 border border-white/10">
            <h3 className="text-md font-semibold flex items-center gap-2 mb-4">
              <Heart className="h-5 w-5 text-pink-500" />
              <span>Test Information</span>
            </h3>
            <div className="grid grid-cols-2 gap-y-2">
              <div className="text-white/70">Doctor:</div>
              <div className="font-medium">Dr. {doctorName}</div>

              <div className="text-white/70">Hospital:</div>
              <div className="font-medium">{hospitalName}</div>

              <div className="text-white/70">Collected on:</div>
              <div className="font-medium">{reportDate.split(" ")[0]}</div>

              <div className="text-white/70">Report Status:</div>
              <div className="font-medium text-green-500">Final</div>
            </div>
          </div>
        </div>

        {/* Test Results */}
        <div className="bg-white/10 rounded-lg border border-white/10 overflow-hidden">
          <div className="p-4 border-b border-white/10">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Activity className="h-5 w-5 text-pink-500" />
              <span>Test Results</span>
            </h3>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="border-b border-white/10">
              <TabsList className="bg-transparent h-auto p-0">
                {Object.keys(resultData).map((category) => (
                  <TabsTrigger
                    key={category}
                    value={category}
                    className="rounded-none data-[state=active]:bg-white/10 data-[state=active]:shadow-none px-4 py-2 border-b-2 border-transparent data-[state=active]:border-pink-500"
                  >
                    {category}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            {Object.entries(resultData).map(([category, tests]) => (
              <TabsContent key={category} value={category} className="pt-0 pb-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-white/10">
                        <th className="text-left py-3 px-4 text-white/70 font-medium">Test</th>
                        <th className="text-left py-3 px-4 text-white/70 font-medium">Result</th>
                        <th className="text-left py-3 px-4 text-white/70 font-medium">Unit</th>
                        <th className="text-left py-3 px-4 text-white/70 font-medium">Normal Range</th>
                        <th className="text-left py-3 px-4 text-white/70 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tests.map((test, index) => (
                        <tr key={index} className="border-b border-white/5 hover:bg-white/5">
                          <td className="py-3 px-4 font-medium">{test.name}</td>
                          <td className={`py-3 px-4 ${getStatusColor(test.status)}`}>{test.value}</td>
                          <td className="py-3 px-4 text-white/70">{test.unit}</td>
                          <td className="py-3 px-4 text-white/70">{test.normalRange}</td>
                          <td className="py-3 px-4">
                            <div
                              className={`inline-flex items-center gap-1 px-2 py-1 rounded-full ${
                                test.status === "normal"
                                  ? "bg-green-500/20 text-green-500"
                                  : test.status === "high"
                                    ? "bg-amber-500/20 text-amber-500"
                                    : test.status === "low"
                                      ? "bg-blue-500/20 text-blue-500"
                                      : "bg-red-500/20 text-red-500"
                              } text-xs font-medium`}
                            >
                              {test.status === "normal" ? null : <AlertCircle className="h-3 w-3" />}
                              <span className="capitalize">{test.status}</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        {/* Interpretation and Notes */}
        <div className="mt-6 bg-white/10 rounded-lg p-4 border border-white/10">
          <h3 className="text-md font-semibold mb-3">Interpretation</h3>
          <p className="text-white/80 mb-4">
            Based on the test results, your overall health indicators are within normal range with a few minor
            deviations. No critical values were detected. Follow-up recommended in 6 months.
          </p>

          <h3 className="text-md font-semibold mb-3">Notes</h3>
          <p className="text-white/80">
            Please continue with your current medication. Maintain a healthy diet with reduced sodium intake. Regular
            exercise is recommended. If you experience any concerning symptoms, please contact your healthcare provider.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
