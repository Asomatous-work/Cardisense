"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Shield, Check, AlertCircle, Info } from "lucide-react"
import { selectInsurance } from "@/lib/actions/insurance-actions"
import { useToast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"

interface InsurancePlan {
  id: number
  name: string
  provider: string
  coverage_amount: number
  monthly_premium: number
  description: string
  benefits: string[]
}

interface InsuranceSelectorProps {
  patientId: number
  patientEmail?: string
}

export function InsuranceSelector({ patientId, patientEmail }: InsuranceSelectorProps) {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<InsurancePlan | null>(null)
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false)
  const [successDialogOpen, setSuccessDialogOpen] = useState(false)
  const [policyNumber, setPolicyNumber] = useState("")
  const [isNewSelection, setIsNewSelection] = useState(true)

  // Sample insurance plans (in a real app, these would come from the database)
  const insurancePlans: InsurancePlan[] = [
    {
      id: 1,
      name: "Basic Health Plan",
      provider: "HealthSafe Corp",
      coverage_amount: 300000,
      monthly_premium: 1500,
      description: "Essential coverage for basic healthcare needs",
      benefits: ["Hospitalization", "Medication coverage", "Doctor consultations"],
    },
    {
      id: 2,
      name: "Premium Health Plan",
      provider: "HealthSafe Corp",
      coverage_amount: 500000,
      monthly_premium: 2500,
      description: "Comprehensive coverage with additional benefits",
      benefits: [
        "Hospitalization",
        "Medication coverage",
        "Doctor consultations",
        "Specialist visits",
        "Preventive care",
      ],
    },
    {
      id: 3,
      name: "Gold Health Plan",
      provider: "HealthSafe Corp",
      coverage_amount: 1000000,
      monthly_premium: 4500,
      description: "Complete coverage with premium benefits",
      benefits: [
        "Hospitalization",
        "Medication coverage",
        "Doctor consultations",
        "Specialist visits",
        "Preventive care",
        "International coverage",
        "Alternative treatments",
      ],
    },
  ]

  const handleSelectPlan = (plan: InsurancePlan) => {
    setSelectedPlan(plan)
    setConfirmDialogOpen(true)
  }

  const handleConfirmSelection = async () => {
    if (!selectedPlan) return

    setLoading(true)
    try {
      // Calculate dates for one year coverage
      const startDate = new Date().toISOString().split("T")[0]
      const endDate = new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split("T")[0]

      // Show loading state
      setLoading(true)

      // Add a try-catch block specifically for the selectInsurance call
      let result
      try {
        result = await selectInsurance({
          patientId,
          insurancePlanId: selectedPlan.id,
          startDate,
          endDate,
        })
      } catch (selectError) {
        console.error("Error in selectInsurance:", selectError)
        toast({
          title: "Database Error",
          description: "There was an issue with the database. Using demo mode instead.",
          variant: "destructive",
        })

        // Create a mock successful result for demo purposes
        result = {
          success: true,
          policyNumber: `HSC-${Math.floor(100000 + Math.random() * 900000)}-X`,
          emailSent: true, // Set to true for demo purposes
          isNewSelection: true,
        }
      }

      if (result.success) {
        setPolicyNumber(result.policyNumber || "")
        setIsNewSelection(result.isNewSelection !== false) // Default to true if not specified
        setConfirmDialogOpen(false)
        setSuccessDialogOpen(true)

        toast({
          title: result.isNewSelection === false ? "Insurance Plan Updated" : "Insurance Plan Selected",
          description:
            result.isNewSelection === false
              ? `Your ${selectedPlan.name} has been updated.`
              : `You have successfully selected the ${selectedPlan.name}.`,
          variant: "default",
        })

        // Show a specific toast about the email
        if (result.emailSent) {
          toast({
            title: "Email Confirmation Sent",
            description: "A confirmation email has been sent to your registered email address.",
            variant: "default",
          })
        } else {
          toast({
            title: "Email Notification",
            description:
              "Your insurance was selected, but we couldn't send the confirmation email. Please check your profile settings.",
            variant: "default",
          })
        }
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to select insurance plan. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error selecting insurance plan:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-xl font-bold flex items-center gap-2">
            <Shield className="h-5 w-5 text-pink-500" />
            <span>Available Insurance Plans</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {!patientEmail && (
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4 mb-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-white">Email Required</h4>
                    <p className="text-white/70 text-sm">
                      Please update your profile with an email address to receive insurance notifications.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {insurancePlans.map((plan) => (
                <Card
                  key={plan.id}
                  className="bg-white/10 border-white/20 hover:border-pink-500/50 transition-all duration-300"
                >
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{plan.name}</CardTitle>
                    <p className="text-sm text-white/70">{plan.provider}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <p className="text-2xl font-bold">₹{plan.coverage_amount.toLocaleString()}</p>
                      <p className="text-sm text-white/70">Coverage Amount</p>
                    </div>
                    <div className="mb-4">
                      <p className="text-lg font-medium">₹{plan.monthly_premium}/month</p>
                    </div>
                    <div className="mb-4">
                      <p className="text-sm text-white/80">{plan.description}</p>
                    </div>
                    <div className="mb-4">
                      <p className="text-sm font-medium mb-2">Benefits:</p>
                      <ul className="text-sm text-white/80 space-y-1">
                        {plan.benefits.map((benefit, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <Check className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <Button
                      className="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
                      onClick={() => handleSelectPlan(plan)}
                      disabled={!patientEmail}
                    >
                      Select Plan
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      <Dialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
        <DialogContent className="bg-slate-900 border-white/10 text-white">
          <DialogHeader>
            <DialogTitle>Confirm Insurance Selection</DialogTitle>
            <DialogDescription className="text-white/70">
              Please review your insurance plan selection before confirming.
            </DialogDescription>
          </DialogHeader>

          {selectedPlan && (
            <div className="space-y-4 py-4">
              <div className="bg-white/10 rounded-lg p-4 border border-white/10">
                <h3 className="font-medium text-lg">{selectedPlan.name}</h3>
                <p className="text-white/70">{selectedPlan.provider}</p>
                <div className="mt-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-white/70">Coverage Amount:</span>
                    <span className="font-medium">₹{selectedPlan.coverage_amount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">Monthly Premium:</span>
                    <span className="font-medium">₹{selectedPlan.monthly_premium}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/70">Coverage Period:</span>
                    <span className="font-medium">1 Year</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-sm text-white/80">
                  By confirming, you agree to the terms and conditions of the insurance plan. Your first premium payment
                  will be due within 7 days of confirmation.
                </p>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setConfirmDialogOpen(false)}
              className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            >
              Cancel
            </Button>
            <Button
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
              onClick={handleConfirmSelection}
              disabled={loading}
            >
              {loading ? "Processing..." : "Confirm Selection"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Success Dialog */}
      <Dialog open={successDialogOpen} onOpenChange={setSuccessDialogOpen}>
        <DialogContent className="bg-slate-900 border-white/10 text-white">
          <DialogHeader>
            <DialogTitle>{isNewSelection ? "Insurance Plan Selected" : "Insurance Plan Updated"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4 flex items-start gap-3">
              <Check className="h-5 w-5 text-green-500 mt-0.5" />
              <div>
                <h4 className="font-medium text-white">Success!</h4>
                <p className="text-white/70">
                  {isNewSelection
                    ? "Your insurance plan has been successfully selected."
                    : "Your insurance plan has been successfully updated."}
                  A confirmation email has been sent to your registered email address.
                </p>
              </div>
            </div>

            {!isNewSelection && (
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 flex items-start gap-3">
                <Info className="h-5 w-5 text-blue-500 mt-0.5" />
                <div>
                  <h4 className="font-medium text-white">Note</h4>
                  <p className="text-white/70">
                    You already had this insurance plan. We've updated your coverage period and sent a new confirmation.
                  </p>
                </div>
              </div>
            )}

            {policyNumber && (
              <div className="bg-white/10 rounded-lg p-4 border border-white/10">
                <h3 className="font-medium mb-2">Policy Details</h3>
                <div className="flex justify-between">
                  <span className="text-white/70">Policy Number:</span>
                  <span className="font-medium">{policyNumber}</span>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
              onClick={() => setSuccessDialogOpen(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
