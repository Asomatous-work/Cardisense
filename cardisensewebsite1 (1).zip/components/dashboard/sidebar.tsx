"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Heart, FileText, Calendar, MessageCircle, Shield, Trophy, Home, User, Settings, LogOut, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { useDeviceType } from "@/hooks/use-device-type"

const navItems = [
  {
    title: "Overview",
    href: "/dashboard",
    icon: Home,
  },
  {
    title: "NFC Medical Card",
    href: "/dashboard/nfc-card",
    icon: Heart,
  },
  {
    title: "Medical Reports",
    href: "/dashboard/reports",
    icon: FileText,
  },
  {
    title: "Prescriptions",
    href: "/dashboard/prescriptions",
    icon: Calendar,
  },
  {
    title: "Medical Chatbot",
    href: "/dashboard/chatbot",
    icon: MessageCircle,
  },
  {
    title: "Insurance & Appointments",
    href: "/dashboard/insurance",
    icon: Shield,
  },
  {
    title: "Rewards",
    href: "/dashboard/rewards",
    icon: Trophy,
  },
]

export function Sidebar({ patientName }: { patientName: string }) {
  const pathname = usePathname()
  const { isMobile, isTablet } = useDeviceType()
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const autoHideTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const touchStartXRef = useRef<number | null>(null)

  // Auto-collapse sidebar on mobile and tablet
  useEffect(() => {
    if (isMobile || isTablet) {
      setIsCollapsed(true)
    } else {
      setIsCollapsed(false)
    }
  }, [isMobile, isTablet])

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false)
  }, [pathname])

  // Auto-hide the sidebar after a delay
  useEffect(() => {
    if (isMobileMenuOpen && (isMobile || isTablet)) {
      // Start the auto-hide timer
      if (autoHideTimeoutRef.current) {
        clearTimeout(autoHideTimeoutRef.current)
      }

      autoHideTimeoutRef.current = setTimeout(() => {
        setIsMobileMenuOpen(false)
      }, 5000) // Hide after 5 seconds of inactivity
    }

    return () => {
      if (autoHideTimeoutRef.current) {
        clearTimeout(autoHideTimeoutRef.current)
      }
    }
  }, [isMobileMenuOpen, isMobile, isTablet])

  // Set up touch event handlers for swipe gesture
  useEffect(() => {
    if (!isMobile && !isTablet) return

    const handleTouchStart = (e: TouchEvent) => {
      touchStartXRef.current = e.touches[0].clientX
    }

    const handleTouchMove = (e: TouchEvent) => {
      if (touchStartXRef.current === null) return

      const touchX = e.touches[0].clientX
      const diff = touchX - touchStartXRef.current

      // If swiping from left edge to right (to open menu)
      if (touchStartXRef.current < 30 && diff > 70) {
        setIsMobileMenuOpen(true)
        // Reset auto-hide timer when opening via swipe
        resetAutoHideTimer()
      }

      // If swiping from right to left (to close menu)
      if (isMobileMenuOpen && diff < -70) {
        setIsMobileMenuOpen(false)
      }
    }

    const handleTouchEnd = () => {
      touchStartXRef.current = null
    }

    document.addEventListener("touchstart", handleTouchStart, { passive: true })
    document.addEventListener("touchmove", handleTouchMove, { passive: true })
    document.addEventListener("touchend", handleTouchEnd)

    return () => {
      document.removeEventListener("touchstart", handleTouchStart)
      document.removeEventListener("touchmove", handleTouchMove)
      document.removeEventListener("touchend", handleTouchEnd)
    }
  }, [isMobile, isTablet, isMobileMenuOpen])

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
    // Reset auto-hide timer when toggling menu
    if (!isMobileMenuOpen) {
      resetAutoHideTimer()
    }
  }

  // Reset the auto-hide timer when user interacts with the sidebar
  const resetAutoHideTimer = () => {
    if (autoHideTimeoutRef.current) {
      clearTimeout(autoHideTimeoutRef.current)
    }

    if (isMobile || isTablet) {
      autoHideTimeoutRef.current = setTimeout(() => {
        setIsMobileMenuOpen(false)
      }, 5000) // Reset to 5 seconds
    }
  }

  return (
    <>
      {/* App Icon - Only visible on mobile when menu is closed */}
      {(isMobile || isTablet) && !isMobileMenuOpen && (
        <button
          onClick={toggleMobileMenu}
          className="fixed top-4 left-4 z-30 flex items-center justify-center w-10 h-10 rounded-full bg-slate-800 border border-white/10 shadow-lg"
          aria-label="Open menu"
        >
          <img src="/icons/icon-72x72.png" alt="CARDISENSE" className="w-8 h-8" />
        </button>
      )}

      {/* Sidebar */}
      <div
        className={cn(
          "fixed left-0 top-0 z-20 flex h-full flex-col border-r border-white/10 bg-slate-900 transition-all duration-300",
          isCollapsed ? "w-16" : "w-64",
          isMobile || isTablet ? (isMobileMenuOpen ? "translate-x-0" : "-translate-x-full") : "",
        )}
        onTouchStart={resetAutoHideTimer}
        onMouseMove={resetAutoHideTimer}
        onClick={resetAutoHideTimer}
      >
        <div className="flex h-16 items-center justify-between border-b border-white/10 px-4">
          <div className={cn("flex items-center gap-2", isCollapsed && !isMobileMenuOpen && "justify-center w-full")}>
            <div className="flex h-8 w-8 items-center justify-center">
              <img src="/icons/icon-72x72.png" alt="CARDISENSE" className="w-8 h-8" />
            </div>
            {(!isCollapsed || isMobileMenuOpen) && (
              <span className="text-lg font-bold bg-gradient-to-r from-pink-500 to-purple-600 text-transparent bg-clip-text">
                CARDISENSE
              </span>
            )}
          </div>

          {/* Close button for mobile */}
          {(isMobile || isTablet) && isMobileMenuOpen ? (
            <button
              onClick={toggleMobileMenu}
              className="rounded-full p-1 text-white/60 hover:bg-white/10 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
          ) : (
            // Collapse button for desktop
            !isMobile &&
            !isTablet && (
              <button
                onClick={() => setIsCollapsed(!isCollapsed)}
                className="rounded-full p-1 text-white/60 hover:bg-white/10 hover:text-white"
              >
                {isCollapsed ? (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m9 18 6-6-6-6" />
                  </svg>
                ) : (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m15 18-6-6 6-6" />
                  </svg>
                )}
              </button>
            )
          )}
        </div>

        <div className="flex flex-col gap-1 p-3 overflow-y-auto">
          {(!isCollapsed || isMobileMenuOpen) && (
            <div className="mb-4 flex items-center gap-3 rounded-lg bg-white/5 p-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-r from-pink-500/20 to-purple-500/20">
                <User className="h-5 w-5 text-pink-500" />
              </div>
              <div className="overflow-hidden">
                <p className="truncate text-sm font-medium text-white">{patientName}</p>
                <p className="truncate text-xs text-white/60">Patient</p>
              </div>
            </div>
          )}

          <div className="space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-white/70 transition-colors hover:bg-white/10 hover:text-white",
                  pathname === item.href && "bg-white/10 text-white",
                  isCollapsed && !isMobileMenuOpen && "justify-center",
                )}
                onClick={resetAutoHideTimer}
              >
                <item.icon className="h-5 w-5" />
                {(!isCollapsed || isMobileMenuOpen) && <span className="text-sm">{item.title}</span>}
              </Link>
            ))}
          </div>
        </div>

        <div className="mt-auto border-t border-white/10 p-3">
          <Link
            href="/dashboard/settings"
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-white/70 transition-colors hover:bg-white/10 hover:text-white",
              pathname === "/dashboard/settings" && "bg-white/10 text-white",
              isCollapsed && !isMobileMenuOpen && "justify-center",
            )}
            onClick={resetAutoHideTimer}
          >
            <Settings className="h-5 w-5" />
            {(!isCollapsed || isMobileMenuOpen) && <span className="text-sm">Settings</span>}
          </Link>
          <Link
            href="/"
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-white/70 transition-colors hover:bg-white/10 hover:text-white",
              isCollapsed && !isMobileMenuOpen && "justify-center",
            )}
            onClick={resetAutoHideTimer}
          >
            <LogOut className="h-5 w-5" />
            {(!isCollapsed || isMobileMenuOpen) && <span className="text-sm">Logout</span>}
          </Link>
        </div>
      </div>

      {/* Overlay for mobile menu */}
      {(isMobile || isTablet) && isMobileMenuOpen && (
        <div className="fixed inset-0 bg-black/50 z-10" onClick={() => setIsMobileMenuOpen(false)} aria-hidden="true" />
      )}
    </>
  )
}
