"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import { Loader2, CreditCard, IndianRupee } from "lucide-react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

interface Patient {
  id: number
  name: string
  patient_id: string
  email?: string
  phone?: string
}

interface PaymentRequest {
  id: string
  patientId: number
  patientName: string
  amount: number
  type: "appointment" | "consultation" | "other"
  status: "pending" | "completed" | "failed"
  date: string
}

export function PaymentManagement() {
  const { toast } = useToast()
  const [patients, setPatients] = useState<Patient[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedPatient, setSelectedPatient] = useState<string>("")
  const [paymentType, setPaymentType] = useState<"appointment" | "consultation" | "other">("appointment")
  const [amount, setAmount] = useState<number>(1000)
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>([])
  const [requestLoading, setRequestLoading] = useState(false)

  useEffect(() => {
    const fetchPatients = async () => {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()
        const { data, error } = await supabase
          .from("patients")
          .select("id, name, patient_id, email, phone")
          .order("name")

        if (error) {
          throw error
        }

        setPatients(data || [])
      } catch (error) {
        console.error("Error fetching patients:", error)
        toast({
          title: "Error",
          description: "Failed to fetch patients. Please try again.",
          variant: "destructive",
        })
        // Set some sample data for demonstration
        setPatients([
          { id: 1, name: "Suresh Patel", patient_id: "PAT001", email: "suresh@example.com", phone: "9876543210" },
          { id: 2, name: "Priya Sharma", patient_id: "PAT002", email: "priya@example.com", phone: "9876543211" },
          { id: 3, name: "Rahul Verma", patient_id: "PAT003", email: "rahul@example.com", phone: "9876543212" },
        ])
      } finally {
        setLoading(false)
      }
    }

    const fetchPaymentRequests = async () => {
      try {
        const supabase = createClientSupabaseClient()
        const { data, error } = await supabase
          .from("payment_requests")
          .select(`
            id,
            patient_id,
            amount,
            type,
            status,
            created_at,
            patients (name)
          `)
          .order("created_at", { ascending: false })

        if (error) {
          throw error
        }

        const formattedData = (data || []).map((request) => ({
          id: request.id,
          patientId: request.patient_id,
          patientName: request.patients?.name || "Unknown Patient",
          amount: request.amount,
          type: request.type,
          status: request.status,
          date: new Date(request.created_at).toLocaleDateString(),
        }))

        setPaymentRequests(formattedData)
      } catch (error) {
        console.error("Error fetching payment requests:", error)
        // Set some sample data for demonstration
        setPaymentRequests([
          {
            id: "1",
            patientId: 1,
            patientName: "Suresh Patel",
            amount: 1000,
            type: "appointment",
            status: "pending",
            date: new Date().toLocaleDateString(),
          },
          {
            id: "2",
            patientId: 2,
            patientName: "Priya Sharma",
            amount: 500,
            type: "consultation",
            status: "completed",
            date: new Date(Date.now() - 86400000).toLocaleDateString(),
          },
        ])
      }
    }

    fetchPatients()
    fetchPaymentRequests()

    // Set up real-time subscription for payment requests
    const supabase = createClientSupabaseClient()
    const paymentSubscription = supabase
      .channel("payment-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "payment_requests",
        },
        () => {
          fetchPaymentRequests()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(paymentSubscription)
    }
  }, [toast])

  // Update amount based on payment type
  useEffect(() => {
    if (paymentType === "appointment") {
      setAmount(1000)
    } else if (paymentType === "consultation") {
      setAmount(500)
    } else {
      setAmount(0)
    }
  }, [paymentType])

  const handleRequestPayment = async () => {
    if (!selectedPatient || amount <= 0) {
      toast({
        title: "Invalid Request",
        description: "Please select a patient and enter a valid amount.",
        variant: "destructive",
      })
      return
    }

    setRequestLoading(true)
    try {
      const patientId = Number.parseInt(selectedPatient)
      const patient = patients.find((p) => p.id === patientId)

      if (!patient) {
        throw new Error("Selected patient not found")
      }

      const supabase = createClientSupabaseClient()
      const { error } = await supabase.from("payment_requests").insert({
        patient_id: patientId,
        amount,
        type: paymentType,
        status: "pending",
        created_at: new Date().toISOString(),
      })

      if (error) {
        throw error
      }

      toast({
        title: "Payment Request Sent",
        description: `Payment request of ₹${amount} sent to ${patient.name}`,
        variant: "default",
      })

      // Reset form
      setSelectedPatient("")
      setPaymentType("appointment")
      setAmount(1000)
    } catch (error) {
      console.error("Error requesting payment:", error)
      toast({
        title: "Error",
        description: "Failed to send payment request. Please try again.",
        variant: "destructive",
      })
    } finally {
      setRequestLoading(false)
    }
  }

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <CreditCard className="h-5 w-5 text-cyan-500" />
          <span>Payment Management</span>
        </CardTitle>
        <CardDescription>Request and track payments from patients</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="request">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="request">Request Payment</TabsTrigger>
            <TabsTrigger value="history">Payment History</TabsTrigger>
          </TabsList>

          <TabsContent value="request">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="patient">Select Patient</Label>
                <Select value={selectedPatient} onValueChange={setSelectedPatient}>
                  <SelectTrigger id="patient" disabled={loading}>
                    <SelectValue placeholder={loading ? "Loading patients..." : "Select a patient"} />
                  </SelectTrigger>
                  <SelectContent>
                    {patients.map((patient) => (
                      <SelectItem key={patient.id} value={patient.id.toString()}>
                        {patient.name} ({patient.patient_id})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Payment Type</Label>
                <RadioGroup value={paymentType} onValueChange={(value) => setPaymentType(value as any)}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="appointment" id="appointment" />
                    <Label htmlFor="appointment">Appointment (₹1,000)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="consultation" id="consultation" />
                    <Label htmlFor="consultation">Consultation (Editable)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="other" id="other" />
                    <Label htmlFor="other">Other (Editable)</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Amount (₹)</Label>
                <div className="relative">
                  <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/60" />
                  <Input
                    id="amount"
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="pl-10"
                    disabled={paymentType === "appointment"}
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="history">
            <div className="space-y-4">
              {paymentRequests.length > 0 ? (
                paymentRequests.map((request) => (
                  <div key={request.id} className="bg-white/10 rounded-lg p-4 border border-white/20">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium">{request.patientName}</h3>
                          <span
                            className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                              request.status === "completed"
                                ? "bg-green-500/20 text-green-400"
                                : request.status === "failed"
                                  ? "bg-red-500/20 text-red-400"
                                  : "bg-yellow-500/20 text-yellow-400"
                            }`}
                          >
                            {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                          </span>
                        </div>
                        <p className="text-sm text-white/70">
                          {request.type.charAt(0).toUpperCase() + request.type.slice(1)}
                        </p>
                        <p className="text-sm font-medium mt-1">₹{request.amount.toLocaleString("en-IN")}</p>
                        <p className="text-xs text-white/60 mt-1">{request.date}</p>
                      </div>
                      <div>
                        {request.status === "pending" && (
                          <Button size="sm" variant="outline" className="h-8 border-white/20 hover:bg-white/10">
                            Remind
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-white/60">
                  <CreditCard className="h-12 w-12 mx-auto mb-3 text-white/30" />
                  <p>No payment requests found</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-end">
        <Button
          onClick={handleRequestPayment}
          disabled={!selectedPatient || amount <= 0 || requestLoading}
          className="bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400"
        >
          {requestLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            <>Request Payment</>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
