import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getPaymentStats } from "@/lib/actions/payment-actions"
import { DollarSign, ArrowRight } from "lucide-react"

export async function PaymentWidget() {
  const stats = await getPaymentStats()

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-1">
          <CardTitle className="text-base">Payment Overview</CardTitle>
          <CardDescription>Manage patient payments</CardDescription>
        </div>
        <DollarSign className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Outstanding</p>
            <p className="text-xl font-bold">₹{stats.totalOutstanding.toLocaleString()}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Overdue</p>
            <p className="text-xl font-bold text-destructive">₹{stats.overdueAmount.toLocaleString()}</p>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <p className="text-sm text-muted-foreground">{stats.pendingCount} pending payments</p>
          <Link href="/doctor-dashboard/payments" className="flex items-center text-sm font-medium text-primary">
            View All
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
