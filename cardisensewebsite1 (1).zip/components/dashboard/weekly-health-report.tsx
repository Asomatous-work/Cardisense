"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import {
  Heart,
  Activity,
  Calendar,
  TrendingUp,
  Trophy,
  DollarSign,
  ArrowUp,
  ArrowDown,
  ChevronRight,
} from "lucide-react"
import { useDeviceType } from "@/hooks/use-device-type"

export function WeeklyHealthReport() {
  const { isMobile } = useDeviceType()
  const [activeTab, setActiveTab] = useState("health")

  // Sample data - in a real app, this would come from an API
  const healthData = {
    heartRate: {
      average: 72,
      trend: "stable",
      min: 65,
      max: 85,
      data: [68, 72, 75, 71, 69, 73, 72],
    },
    bloodPressure: {
      average: "120/80",
      trend: "down",
      min: "115/75",
      max: "125/85",
      data: ["118/78", "122/82", "120/80", "119/79", "117/77", "116/76", "115/75"],
    },
    bloodSugar: {
      average: 98,
      trend: "up",
      min: 92,
      max: 105,
      data: [95, 97, 98, 99, 101, 103, 105],
    },
    steps: {
      average: 7500,
      trend: "up",
      min: 5200,
      max: 9800,
      data: [5200, 6300, 7100, 7800, 8500, 9200, 9800],
    },
  }

  const activityData = {
    pointsEarned: 120,
    surveysCompleted: 2,
    appointmentsAttended: 1,
    medicationAdherence: "92%",
  }

  const financialData = {
    totalSpent: 3500,
    insuranceCovered: 2800,
    outOfPocket: 700,
    pendingClaims: 1,
  }

  const renderTrendIcon = (trend: string) => {
    if (trend === "up") {
      return <ArrowUp className="h-4 w-4 text-pink-500" />
    } else if (trend === "down") {
      return <ArrowDown className="h-4 w-4 text-green-500" />
    }
    return null
  }

  const renderHealthMetrics = () => {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-pink-500" />
                  <h3 className="font-medium">Heart Rate</h3>
                </div>
                {renderTrendIcon(healthData.heartRate.trend)}
              </div>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold">{healthData.heartRate.average}</span>
                <span className="text-sm text-white/60 mb-1">bpm</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-white/60">
                <span>Min: {healthData.heartRate.min}</span>
                <span>Max: {healthData.heartRate.max}</span>
              </div>
              <div className="mt-3 flex justify-between">
                {healthData.heartRate.data.map((value, index) => (
                  <div key={index} className="flex flex-col items-center">
                    <div
                      className="bg-pink-500/20 w-1.5 rounded-full"
                      style={{ height: `${(value / 100) * 40}px` }}
                    ></div>
                    <span className="text-[10px] text-white/40 mt-1">{["M", "T", "W", "T", "F", "S", "S"][index]}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-pink-500" />
                  <h3 className="font-medium">Blood Pressure</h3>
                </div>
                {renderTrendIcon(healthData.bloodPressure.trend)}
              </div>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold">{healthData.bloodPressure.average}</span>
                <span className="text-sm text-white/60 mb-1">mmHg</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-white/60">
                <span>Min: {healthData.bloodPressure.min}</span>
                <span>Max: {healthData.bloodPressure.max}</span>
              </div>
              <div className="mt-3 flex justify-between">
                {healthData.bloodPressure.data.map((value, index) => {
                  const systolic = Number.parseInt(value.split("/")[0])
                  return (
                    <div key={index} className="flex flex-col items-center">
                      <div
                        className="bg-pink-500/20 w-1.5 rounded-full"
                        style={{ height: `${(systolic / 150) * 40}px` }}
                      ></div>
                      <span className="text-[10px] text-white/40 mt-1">
                        {["M", "T", "W", "T", "F", "S", "S"][index]}
                      </span>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-pink-500" />
                  <h3 className="font-medium">Blood Sugar</h3>
                </div>
                {renderTrendIcon(healthData.bloodSugar.trend)}
              </div>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold">{healthData.bloodSugar.average}</span>
                <span className="text-sm text-white/60 mb-1">mg/dL</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-white/60">
                <span>Min: {healthData.bloodSugar.min}</span>
                <span>Max: {healthData.bloodSugar.max}</span>
              </div>
              <div className="mt-3 flex justify-between">
                {healthData.bloodSugar.data.map((value, index) => (
                  <div key={index} className="flex flex-col items-center">
                    <div
                      className="bg-pink-500/20 w-1.5 rounded-full"
                      style={{ height: `${(value / 150) * 40}px` }}
                    ></div>
                    <span className="text-[10px] text-white/40 mt-1">{["M", "T", "W", "T", "F", "S", "S"][index]}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-pink-500" />
                  <h3 className="font-medium">Daily Steps</h3>
                </div>
                {renderTrendIcon(healthData.steps.trend)}
              </div>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold">{healthData.steps.average}</span>
                <span className="text-sm text-white/60 mb-1">steps</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-white/60">
                <span>Min: {healthData.steps.min}</span>
                <span>Max: {healthData.steps.max}</span>
              </div>
              <div className="mt-3 flex justify-between">
                {healthData.steps.data.map((value, index) => (
                  <div key={index} className="flex flex-col items-center">
                    <div
                      className="bg-pink-500/20 w-1.5 rounded-full"
                      style={{ height: `${(value / 10000) * 40}px` }}
                    ></div>
                    <span className="text-[10px] text-white/40 mt-1">{["M", "T", "W", "T", "F", "S", "S"][index]}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const renderActivityMetrics = () => {
    return (
      <div className="space-y-4">
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center">
                <Trophy className="h-5 w-5 text-pink-500" />
              </div>
              <div>
                <h3 className="font-medium">Points Earned This Week</h3>
                <p className="text-2xl font-bold">{activityData.pointsEarned}</p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-white/70">Surveys Completed</span>
                <span className="font-medium">{activityData.surveysCompleted}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/70">Appointments Attended</span>
                <span className="font-medium">{activityData.appointmentsAttended}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/70">Medication Adherence</span>
                <span className="font-medium">{activityData.medicationAdherence}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Button
          className="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
          variant="default"
        >
          View All Activity
        </Button>
      </div>
    )
  }

  const renderFinancialMetrics = () => {
    return (
      <div className="space-y-4">
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center">
                <DollarSign className="h-5 w-5 text-pink-500" />
              </div>
              <div>
                <h3 className="font-medium">Healthcare Expenses</h3>
                <p className="text-2xl font-bold">₹{financialData.totalSpent}</p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-white/70">Insurance Covered</span>
                <span className="font-medium">₹{financialData.insuranceCovered}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/70">Out of Pocket</span>
                <span className="font-medium">₹{financialData.outOfPocket}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/70">Pending Claims</span>
                <span className="font-medium">{financialData.pendingClaims}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Button
          className="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
          variant="default"
        >
          View Insurance Details
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <Card className="bg-white/5 border-white/10">
        <CardHeader className="pb-2">
          <CardTitle className="text-xl">Weekly Health Report</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="health" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="health">Health</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
              <TabsTrigger value="financial">Financial</TabsTrigger>
            </TabsList>

            <TabsContent value="health" className="mt-0">
              {renderHealthMetrics()}
            </TabsContent>

            <TabsContent value="activity" className="mt-0">
              {renderActivityMetrics()}
            </TabsContent>

            <TabsContent value="financial" className="mt-0">
              {renderFinancialMetrics()}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          variant="outline"
          size="sm"
          className="text-xs border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
        >
          View Full Report <ChevronRight className="h-3 w-3 ml-1" />
        </Button>
      </div>
    </div>
  )
}
