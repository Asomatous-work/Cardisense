import type React from "react"
import { UserNav } from "@/components/dashboard/user-nav"

interface DashboardHeaderProps {
  heading: string
  text?: string
  children?: React.ReactNode
}

export function DashboardHeader({ heading, text, children }: DashboardHeaderProps) {
  return (
    <div className="bg-slate-900 border-b border-white/10">
      <div className="container flex h-16 items-center justify-between py-4 max-w-7xl">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">{heading}</h1>
          {text && <p className="text-sm text-white/60">{text}</p>}
        </div>
        <div className="flex items-center gap-4">
          {children}
          <UserNav />
        </div>
      </div>
    </div>
  )
}
