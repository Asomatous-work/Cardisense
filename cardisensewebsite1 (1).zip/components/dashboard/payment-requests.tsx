"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { User, Search, DollarSign, Calendar, Clock, CheckCircle, XCircle, Loader2, Plus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function PaymentRequests() {
  const { toast } = useToast()
  const [payments, setPayments] = useState<any[]>([])
  const [patients, setPatients] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false)
  const [selectedPayment, setSelectedPayment] = useState<any | null>(null)
  const [creatingPayment, setCreatingPayment] = useState(false)

  // New payment request form state
  const [formData, setFormData] = useState({
    patientId: "",
    amount: "",
    description: "",
    dueDate: "",
    serviceType: "consultation",
  })

  // Fetch payments and patients from the database
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()

        // First, fetch all patients for the dropdown
        const { data: patientsData, error: patientsError } = await supabase
          .from("patients")
          .select("id, name, contact_number")
          .order("name")

        if (patientsError) {
          console.error("Error fetching patients:", patientsError)
          // Use sample data for patients if there's an error
          setPatients([
            { id: 1, name: "Aravind G", contact_number: "+91 9876543210" },
            { id: 2, name: "Rafikhan L", contact_number: "+91 9876543211" },
          ])
        } else {
          setPatients(patientsData || [])
        }

        // Check if payment_requests table exists
        const { data: tableExists } = await supabase
          .from("information_schema.tables")
          .select("table_name")
          .eq("table_name", "payment_requests")
          .single()

        // If payment_requests table doesn't exist, create sample data
        if (!tableExists) {
          console.log("Payment requests table doesn't exist, using sample data")
          setPayments([
            {
              id: 1,
              patientId: 1,
              patientName: "Aravind G",
              contactNumber: "+91 9876543210",
              amount: 1500,
              description: "Cardiology consultation",
              status: "pending",
              dueDate: "30 Apr 2025",
              createdAt: "15 Apr 2025",
              serviceType: "consultation",
            },
            {
              id: 2,
              patientId: 2,
              patientName: "Rafikhan L",
              contactNumber: "+91 9876543211",
              amount: 3000,
              description: "ECG and stress test",
              status: "paid",
              dueDate: "20 Apr 2025",
              createdAt: "10 Apr 2025",
              serviceType: "diagnostic",
            },
          ])
          setLoading(false)
          return
        }

        // Fetch payment requests with patient information
        const { data: paymentsData, error: paymentsError } = await supabase
          .from("payment_requests")
          .select(`
            *,
            patients (
              id,
              name,
              contact_number
            )
          `)
          .order("created_at", { ascending: false })

        if (paymentsError) {
          console.error("Error fetching payment requests:", paymentsError)
          // Use sample data for payments if there's an error
          setPayments([
            {
              id: 1,
              patientId: 1,
              patientName: "Aravind G",
              contactNumber: "+91 9876543210",
              amount: 1500,
              description: "Cardiology consultation",
              status: "pending",
              dueDate: "30 Apr 2025",
              createdAt: "15 Apr 2025",
              serviceType: "consultation",
            },
            {
              id: 2,
              patientId: 2,
              patientName: "Rafikhan L",
              contactNumber: "+91 9876543211",
              amount: 3000,
              description: "ECG and stress test",
              status: "paid",
              dueDate: "20 Apr 2025",
              createdAt: "10 Apr 2025",
              serviceType: "diagnostic",
            },
          ])
        } else {
          // Transform the data
          const formattedData = (paymentsData || []).map((payment) => ({
            id: payment.id,
            patientId: payment.patient_id,
            patientName: payment.patients?.name || "Unknown Patient",
            contactNumber: payment.patients?.contact_number || "No contact",
            amount: payment.amount,
            description: payment.description,
            status: payment.status,
            dueDate: payment.due_date ? new Date(payment.due_date).toLocaleDateString() : "No due date",
            createdAt: payment.created_at ? new Date(payment.created_at).toLocaleDateString() : "Unknown date",
            serviceType: payment.service_type || "consultation",
          }))

          setPayments(formattedData)
        }
      } catch (error) {
        console.error("Error fetching payment data:", error)
        toast({
          title: "Error",
          description: "Failed to fetch payment data. Using sample data instead.",
          variant: "destructive",
        })

        // Set some sample data for demonstration
        setPayments([
          {
            id: 1,
            patientId: 1,
            patientName: "Aravind G",
            contactNumber: "+91 9876543210",
            amount: 1500,
            description: "Cardiology consultation",
            status: "pending",
            dueDate: "30 Apr 2025",
            createdAt: "15 Apr 2025",
            serviceType: "consultation",
          },
          {
            id: 2,
            patientId: 2,
            patientName: "Rafikhan L",
            contactNumber: "+91 9876543211",
            amount: 3000,
            description: "ECG and stress test",
            status: "paid",
            dueDate: "20 Apr 2025",
            createdAt: "10 Apr 2025",
            serviceType: "diagnostic",
          },
        ])
      } finally {
        setLoading(false)
      }
    }

    fetchData()

    // Set up real-time subscription for payment updates
    const supabase = createClientSupabaseClient()

    try {
      const subscription = supabase
        .channel("payment-changes")
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: "payment_requests",
          },
          () => {
            fetchData()
          },
        )
        .subscribe()

      return () => {
        supabase.removeChannel(subscription)
      }
    } catch (error) {
      console.error("Error setting up real-time subscription:", error)
    }
  }, [toast])

  const filteredPayments = payments.filter(
    (payment) =>
      payment.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.status.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleCreatePaymentRequest = async () => {
    // Validate form
    if (!formData.patientId || !formData.amount || !formData.description || !formData.dueDate) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    setCreatingPayment(true)

    try {
      const supabase = createClientSupabaseClient()

      // Insert the new payment request
      const { data, error } = await supabase
        .from("payment_requests")
        .insert({
          patient_id: Number.parseInt(formData.patientId),
          amount: Number.parseFloat(formData.amount),
          description: formData.description,
          status: "pending",
          due_date: formData.dueDate,
          created_at: new Date().toISOString(),
          service_type: formData.serviceType,
        })
        .select()

      if (error) {
        console.error("Error creating payment request:", error)

        // For demo purposes, still show success and update UI
        const patient = patients.find((p) => p.id.toString() === formData.patientId.toString())

        // Create a new payment request in local state
        const newPayment = {
          id: payments.length + 1,
          patientId: Number.parseInt(formData.patientId),
          patientName: patient?.name || "Unknown Patient",
          contactNumber: patient?.contact_number || "No contact",
          amount: Number.parseFloat(formData.amount),
          description: formData.description,
          status: "pending",
          dueDate: new Date(formData.dueDate).toLocaleDateString(),
          createdAt: new Date().toLocaleDateString(),
          serviceType: formData.serviceType,
        }

        setPayments([newPayment, ...payments])
      }

      toast({
        title: "Payment Request Created",
        description: "The payment request has been created successfully.",
        variant: "default",
      })

      setCreateDialogOpen(false)
      resetForm()
    } catch (error) {
      console.error("Error creating payment request:", error)
      toast({
        title: "Error",
        description: "Failed to create payment request. Please try again.",
        variant: "destructive",
      })
    } finally {
      setCreatingPayment(false)
    }
  }

  const resetForm = () => {
    setFormData({
      patientId: "",
      amount: "",
      description: "",
      dueDate: "",
      serviceType: "consultation",
    })
  }

  const handleViewDetails = (payment: any) => {
    setSelectedPayment(payment)
    setDetailsDialogOpen(true)
  }

  const handleUpdateStatus = async (paymentId: number, newStatus: string) => {
    try {
      const supabase = createClientSupabaseClient()

      // Update the payment status in the database
      const { error } = await supabase.from("payment_requests").update({ status: newStatus }).eq("id", paymentId)

      if (error) {
        console.error("Error updating payment status:", error)

        // Update local state even if there's an error with the database
        const updatedPayments = payments.map((payment) =>
          payment.id === paymentId ? { ...payment, status: newStatus } : payment,
        )
        setPayments(updatedPayments)

        // Update the selected payment if it's open
        if (selectedPayment && selectedPayment.id === paymentId) {
          setSelectedPayment({ ...selectedPayment, status: newStatus })
        }
      }

      toast({
        title: "Payment Status Updated",
        description: `Payment status has been updated to ${newStatus}.`,
        variant: "default",
      })
    } catch (error) {
      console.error("Error updating payment status:", error)
      toast({
        title: "Error",
        description: "Failed to update payment status. Please try again.",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return (
          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-green-500/20 text-green-400 text-xs font-medium">
            <CheckCircle className="h-3 w-3" />
            <span>Paid</span>
          </div>
        )
      case "overdue":
        return (
          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-red-500/20 text-red-400 text-xs font-medium">
            <XCircle className="h-3 w-3" />
            <span>Overdue</span>
          </div>
        )
      default:
        return (
          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-yellow-500/20 text-yellow-400 text-xs font-medium">
            <Clock className="h-3 w-3" />
            <span>Pending</span>
          </div>
        )
    }
  }

  return (
    <>
      <Card className="bg-white/5 border-white/10 p-4 md:p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-cyan-500" />
            <span>Payment Requests</span>
          </h2>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
            <div className="relative flex-1 sm:flex-initial">
              <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40" />
              <input
                type="text"
                placeholder="Search payments..."
                className="bg-white/10 border border-white/20 rounded-md pl-9 pr-4 py-1 text-sm text-white w-full sm:w-48"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button
              className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
              onClick={() => setCreateDialogOpen(true)}
            >
              <Plus className="h-4 w-4 mr-1" />
              New Request
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-cyan-500" />
          </div>
        ) : (
          <>
            {filteredPayments.length > 0 ? (
              <div className="space-y-4">
                {filteredPayments.map((payment) => (
                  <div key={payment.id} className="bg-white/10 rounded-lg p-4 border border-white/10">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                      <div className="flex gap-3">
                        <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                          <User className="h-5 w-5 text-pink-500" />
                        </div>
                        <div>
                          <h3 className="font-medium">{payment.patientName}</h3>
                          <p className="text-sm text-white/70">{payment.description}</p>
                          <div className="flex items-center gap-3 mt-1">
                            <div className="flex items-center gap-1">
                              <DollarSign className="h-3 w-3 text-white/60" />
                              <span className="text-xs text-white/60">₹{payment.amount.toLocaleString()}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3 text-white/60" />
                              <span className="text-xs text-white/60">Due: {payment.dueDate}</span>
                            </div>
                            <div>{getStatusBadge(payment.status)}</div>
                          </div>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="h-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 mt-2 sm:mt-0"
                        onClick={() => handleViewDetails(payment)}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-white/60 bg-white/5 rounded-lg border border-white/10">
                <DollarSign className="h-12 w-12 mx-auto mb-3 text-white/30" />
                <p>No payment requests found</p>
                <p className="text-sm mt-1">Create a new payment request or adjust your search</p>
              </div>
            )}
          </>
        )}
      </Card>

      {/* Create Payment Request Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="bg-slate-900 border-white/10 text-white max-w-md w-full">
          <DialogHeader>
            <DialogTitle>Create Payment Request</DialogTitle>
            <DialogDescription className="text-white/60">
              Send a payment request to a patient for services rendered.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="patient">Patient</Label>
              <Select
                value={formData.patientId}
                onValueChange={(value) => setFormData({ ...formData, patientId: value })}
              >
                <SelectTrigger className="bg-white/10 border-white/20 text-white">
                  <SelectValue placeholder="Select a patient" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-white/10 text-white">
                  {patients.map((patient) => (
                    <SelectItem key={patient.id} value={patient.id.toString()}>
                      {patient.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount (₹)</Label>
              <Input
                id="amount"
                type="number"
                placeholder="Enter amount"
                className="bg-white/10 border-white/20 text-white"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="serviceType">Service Type</Label>
              <Select
                value={formData.serviceType}
                onValueChange={(value) => setFormData({ ...formData, serviceType: value })}
              >
                <SelectTrigger className="bg-white/10 border-white/20 text-white">
                  <SelectValue placeholder="Select service type" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-white/10 text-white">
                  <SelectItem value="consultation">Consultation</SelectItem>
                  <SelectItem value="diagnostic">Diagnostic Test</SelectItem>
                  <SelectItem value="procedure">Procedure</SelectItem>
                  <SelectItem value="emergency">Emergency Care</SelectItem>
                  <SelectItem value="medication">Medication</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Enter service description"
                className="bg-white/10 border-white/20 text-white"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="date"
                className="bg-white/10 border-white/20 text-white"
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setCreateDialogOpen(false)}
              className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            >
              Cancel
            </Button>
            <Button
              className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
              onClick={handleCreatePaymentRequest}
              disabled={creatingPayment}
            >
              {creatingPayment ? (
                <>
                  <Loader2 className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" />
                  Creating...
                </>
              ) : (
                "Create Request"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment Details Dialog */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent className="bg-slate-900 border-white/10 text-white max-w-md w-full">
          <DialogHeader>
            <DialogTitle>Payment Details</DialogTitle>
          </DialogHeader>

          {selectedPayment && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3 bg-white/5 p-3 rounded-lg">
                <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                  <User className="h-5 w-5 text-pink-500" />
                </div>
                <div>
                  <h3 className="font-medium">{selectedPayment.patientName}</h3>
                  <p className="text-sm text-white/70">{selectedPayment.contactNumber}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 p-3 rounded-lg">
                  <div className="text-xs text-white/60 mb-1">Amount</div>
                  <div className="font-medium text-lg">₹{selectedPayment.amount.toLocaleString()}</div>
                </div>
                <div className="bg-white/5 p-3 rounded-lg">
                  <div className="text-xs text-white/60 mb-1">Status</div>
                  <div>{getStatusBadge(selectedPayment.status)}</div>
                </div>
              </div>

              <div className="bg-white/5 p-3 rounded-lg">
                <div className="text-xs text-white/60 mb-1">Service Type</div>
                <div className="font-medium capitalize">{selectedPayment.serviceType}</div>
              </div>

              <div className="bg-white/5 p-3 rounded-lg">
                <div className="text-xs text-white/60 mb-1">Description</div>
                <div className="font-medium">{selectedPayment.description}</div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 p-3 rounded-lg">
                  <div className="text-xs text-white/60 mb-1">Due Date</div>
                  <div className="font-medium">{selectedPayment.dueDate}</div>
                </div>
                <div className="bg-white/5 p-3 rounded-lg">
                  <div className="text-xs text-white/60 mb-1">Created Date</div>
                  <div className="font-medium">{selectedPayment.createdAt}</div>
                </div>
              </div>

              {selectedPayment.status === "pending" && (
                <div className="flex gap-4 mt-4">
                  <Button
                    className="flex-1 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-500 hover:to-green-600"
                    onClick={() => handleUpdateStatus(selectedPayment.id, "paid")}
                  >
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Mark as Paid
                  </Button>
                  <Button
                    className="flex-1 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600"
                    onClick={() => handleUpdateStatus(selectedPayment.id, "overdue")}
                  >
                    <XCircle className="h-4 w-4 mr-1" />
                    Mark as Overdue
                  </Button>
                </div>
              )}

              {selectedPayment.status === "overdue" && (
                <Button
                  className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-500 hover:to-green-600"
                  onClick={() => handleUpdateStatus(selectedPayment.id, "paid")}
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Mark as Paid
                </Button>
              )}

              {selectedPayment.status === "paid" && (
                <Button
                  className="w-full bg-gradient-to-r from-yellow-600 to-yellow-700 hover:from-yellow-500 hover:to-yellow-600"
                  onClick={() => handleUpdateStatus(selectedPayment.id, "pending")}
                >
                  <Clock className="h-4 w-4 mr-1" />
                  Mark as Pending
                </Button>
              )}
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDetailsDialogOpen(false)}
              className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
