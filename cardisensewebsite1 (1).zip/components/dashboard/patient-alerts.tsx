"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, Clock, Users, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Calendar } from "@/components/ui/calendar"

interface Alert {
  id: number
  patient: string
  type: string
  date: string
  time: string
  status: string
  notes: string
  isUrgent: boolean
}

export function PatientAlerts() {
  const { toast } = useToast()
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()

        // Fetch urgent alerts from the database
        const { data: alertsData, error: alertsError } = await supabase
          .from("alerts")
          .select(`
            id,
            message,
            created_at,
            is_urgent,
            patients (id, name)
          `)
          .eq("is_urgent", true)
          .order("created_at", { ascending: false })

        if (alertsError) {
          console.error("Error fetching urgent alerts:", alertsError)
          toast({
            title: "Error",
            description: "Failed to fetch urgent alerts. Using demo data instead.",
            variant: "destructive",
          })
          setAlerts(getSampleAlerts())
          return
        }

        // Transform the data to match our component's expected format
        const formattedData = (alertsData || []).map((alert) => ({
          id: alert.id,
          patient: alert.patients?.name || "Unknown Patient",
          type: "alert",
          date: alert.created_at ? new Date(alert.created_at).toLocaleDateString() : "No date",
          time: alert.created_at ? new Date(alert.created_at).toLocaleTimeString() : "No time",
          status: "urgent",
          notes: alert.message,
          isUrgent: alert.is_urgent,
        }))

        setAlerts(formattedData)
      } catch (error) {
        console.error("Error fetching alerts:", error)
        toast({
          title: "Error",
          description: "An unexpected error occurred. Using demo data instead.",
          variant: "destructive",
        })
        setAlerts(getSampleAlerts())
      } finally {
        setLoading(false)
      }
    }

    fetchData()

    // Set up real-time subscription for alerts
    const supabase = createClientSupabaseClient()
    const alertsSubscription = supabase
      .channel("alerts-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "alerts",
        },
        (payload) => {
          fetchData()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(alertsSubscription)
    }
  }, [toast])

  const getSampleAlerts = (): Alert[] => {
    return [
      {
        id: 1,
        patient: "Suresh Patel",
        type: "Emergency Consultation",
        date: "Apr 14, 2025",
        time: "4:15 PM",
        status: "urgent",
        notes: "Experiencing severe chest pain and shortness of breath",
        isUrgent: true,
      },
    ]
  }

  return (
    <Card className="bg-white/5 border-white/10 p-6">
      <h2 className="text-xl font-bold flex items-center gap-2 mb-4">
        <AlertCircle className="h-5 w-5 text-red-500" />
        <span>Urgent Patient Alerts</span>
      </h2>

      {loading ? (
        <div className="flex justify-center items-center py-8">
          <Loader2 className="h-10 w-10 animate-spin text-cyan-500" />
        </div>
      ) : (
        <div className="space-y-4">
          {alerts.length > 0 ? (
            alerts.map((alert) => (
              <div key={alert.id} className="bg-white/10 rounded-lg p-4 border border-red-500/30">
                <div className="flex items-start justify-between">
                  <div className="flex gap-3">
                    <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                      <Users className="h-5 w-5 text-pink-500" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{alert.patient}</h3>
                        <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-xs font-medium">
                          Urgent
                        </span>
                      </div>
                      <p className="text-sm text-white/70">{alert.type}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3 text-white/60" />
                          <span className="text-xs text-white/60">{alert.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3 text-white/60" />
                          <span className="text-xs text-white/60">{alert.time}</span>
                        </div>
                      </div>
                      <p className="text-xs text-white/60 mt-2">{alert.notes}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="h-8 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400"
                    >
                      Respond
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-white/60">
              <AlertCircle className="h-12 w-12 mx-auto mb-3 text-white/30" />
              <p>No urgent alerts</p>
            </div>
          )}
        </div>
      )}
    </Card>
  )
}
