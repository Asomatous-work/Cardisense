"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, Calendar, Shield, Trophy, MessageCircle, Heart } from "lucide-react"
import SenseChat from "@/components/sense-chat"

interface FeatureSimulationProps {
  initialFeature?: string
  patientName: string
}

export function FeatureSimulation({ initialFeature, patientName }: FeatureSimulationProps) {
  const [selectedFeature, setSelectedFeature] = useState(initialFeature || "")
  const [chatInput, setChatInput] = useState("")
  const [chatLog, setChatLog] = useState<Array<{ from: "user" | "bot"; message: string }>>([])

  const features = [
    {
      name: "NFC Medical Card",
      icon: Heart,
    },
    {
      name: "Medical Reports",
      icon: FileText,
    },
    {
      name: "Smart Prescription Dashboard",
      icon: Calendar,
    },
    {
      name: "Insurance & Appointments",
      icon: Shield,
    },
    {
      name: "Rewards",
      icon: Trophy,
    },
    {
      name: "Sense+ Chatbot",
      icon: MessageCircle,
    },
  ]

  useEffect(() => {
    if (initialFeature) {
      // Map homepage feature names to component feature names if needed
      const featureMap: Record<string, string> = {
        "Medical Report Access": "Medical Reports",
        "Insurance & Appointment Tracker": "Insurance & Appointments",
        "Gamification & Rewards System": "Rewards",
        "Smart Prescription Dashboard": "Smart Prescription Dashboard",
      }

      setSelectedFeature(featureMap[initialFeature] || initialFeature)
    }
  }, [initialFeature])

  const handleChat = () => {
    if (chatInput.trim() !== "") {
      setChatLog([
        ...chatLog,
        { from: "user", message: chatInput },
        { from: "bot", message: "Thanks for your query! I'll get back with advice shortly." },
      ])
      setChatInput("")
    }
  }

  const renderFeature = () => {
    switch (selectedFeature) {
      case "NFC Medical Card":
        return (
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">NFC Medical Card</h2>
              <div className="bg-gradient-to-br from-pink-500/20 to-purple-500/20 border border-white/10 rounded-xl p-6 backdrop-blur-sm">
                <div className="flex items-center gap-4 mb-6">
                  <div className="h-12 w-12 rounded-full bg-pink-500/20 flex items-center justify-center">
                    <Heart className="h-6 w-6 text-pink-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-white">{patientName}</h3>
                    <p className="text-sm text-white/60">CARDISENSE ID: CS-{Math.floor(Math.random() * 10000)}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-white/60">Blood Type</p>
                      <p className="font-medium">O+</p>
                    </div>
                    <div>
                      <p className="text-sm text-white/60">Emergency Contact</p>
                      <p className="font-medium">+91 9876543210</p>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-white/60">Allergies</p>
                    <p className="font-medium">Penicillin, Peanuts</p>
                  </div>

                  <div>
                    <p className="text-sm text-white/60">Chronic Conditions</p>
                    <p className="font-medium">Hypertension</p>
                  </div>
                </div>

                <div className="mt-6 flex justify-between items-center">
                  <div className="text-xs text-white/60">Tap card on NFC reader for full medical history</div>
                  <div className="h-12 w-12 rounded-full bg-white/10 flex items-center justify-center">
                    <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center">
                      <div className="h-4 w-4 rounded-full bg-white/30"></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-medium mb-2">How It Works</h3>
                <p className="text-white/80 text-sm">
                  Your NFC Medical Card provides emergency responders and healthcare providers with instant access to
                  your vital medical information when tapped on any NFC-enabled smartphone. No app required.
                </p>
                <Button className="mt-4 bg-gradient-to-r from-pink-600 to-purple-600">Order Physical Card</Button>
              </div>
            </CardContent>
          </Card>
        )

      case "Medical Reports":
        return (
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">Your Latest Reports</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                {[
                  { name: "Complete Blood Count", date: "Apr 10, 2025", doctor: "Dr. KIRUPA D" },
                  { name: "Lipid Profile", date: "Apr 10, 2025", doctor: "Dr. KIRUPA D" },
                  { name: "ECG Report", date: "Mar 22, 2025", doctor: "Dr. JEYASURYA S" },
                  { name: "Cardiac Stress Test", date: "Mar 15, 2025", doctor: "Dr. KIRUPA D" },
                ].map((report, index) => (
                  <div key={index} className="bg-white/10 p-4 rounded-lg border border-white/10">
                    <div className="flex items-start gap-3">
                      <div className="bg-pink-500/20 rounded-lg p-2">
                        <FileText className="h-5 w-5 text-pink-500" />
                      </div>
                      <div>
                        <h3 className="font-medium text-white">{report.name}</h3>
                        <p className="text-sm text-white/70">{report.date}</p>
                        <p className="text-sm text-white/70">{report.doctor}</p>
                        <div className="flex gap-2 mt-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 text-xs border-pink-500/50 text-pink-400 hover:bg-pink-500/10"
                          >
                            View Details
                          </Button>
                          <Button
                            size="sm"
                            className="h-8 text-xs bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
                          >
                            Download
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-white/10 rounded-lg p-4 border border-white/10 mb-4">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-lg font-medium">Recent Test Results</h3>
                  <span className="text-sm text-white/60">April 10, 2025</span>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-white/70">Blood Pressure</span>
                        <span className="text-green-500 font-medium">120/80 mmHg</span>
                      </div>
                      <div className="w-full bg-white/10 h-2 rounded-full">
                        <div className="bg-green-500 h-full rounded-full" style={{ width: "65%" }}></div>
                      </div>
                      <div className="flex justify-between text-xs text-white/60 mt-1">
                        <span>90/60</span>
                        <span>120/80</span>
                        <span>140/90</span>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-white/70">Blood Sugar (Fasting)</span>
                        <span className="text-amber-500 font-medium">110 mg/dL</span>
                      </div>
                      <div className="w-full bg-white/10 h-2 rounded-full">
                        <div className="bg-amber-500 h-full rounded-full" style={{ width: "75%" }}></div>
                      </div>
                      <div className="flex justify-between text-xs text-white/60 mt-1">
                        <span>70</span>
                        <span>99</span>
                        <span>126</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-white/70">Total Cholesterol</span>
                        <span className="text-amber-500 font-medium">205 mg/dL</span>
                      </div>
                      <div className="w-full bg-white/10 h-2 rounded-full">
                        <div className="bg-amber-500 h-full rounded-full" style={{ width: "78%" }}></div>
                      </div>
                      <div className="flex justify-between text-xs text-white/60 mt-1">
                        <span>0</span>
                        <span>200</span>
                        <span>240</span>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-white/70">HDL Cholesterol</span>
                        <span className="text-green-500 font-medium">42 mg/dL</span>
                      </div>
                      <div className="w-full bg-white/10 h-2 rounded-full">
                        <div className="bg-green-500 h-full rounded-full" style={{ width: "60%" }}></div>
                      </div>
                      <div className="flex justify-between text-xs text-white/60 mt-1">
                        <span>0</span>
                        <span>40</span>
                        <span>60</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white/10 rounded-lg p-4 border border-white/10">
                <h3 className="text-lg font-medium mb-3">Doctor's Notes</h3>
                <p className="text-white/80 text-sm mb-2">
                  Patient's vital signs are generally within normal range. Slight elevation in blood sugar and
                  cholesterol levels. Recommend dietary adjustments and routine follow-up in 3 months.
                </p>
                <p className="text-white/80 text-sm">
                  - Reduce sugar and carbohydrate intake
                  <br />- Increase physical activity to 30 minutes daily
                  <br />- Continue medication as prescribed
                </p>
              </div>

              <div className="flex justify-between mt-4">
                <Button variant="outline" className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white">
                  Previous Reports
                </Button>
                <Button className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500">
                  Schedule Next Checkup
                </Button>
              </div>
            </CardContent>
          </Card>
        )

      case "Smart Prescription Dashboard":
        return (
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">Appointments</h2>

              <div className="space-y-4 mb-6">
                <h3 className="text-lg font-medium">Upcoming Appointments</h3>
                <div className="space-y-3">
                  <div className="bg-white/10 p-4 rounded-lg border border-pink-500/30">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-white">Cardiology Checkup</h4>
                        <p className="text-sm text-white/70">Dr. KIRUPA D • April 18, 2025 • 10:30 AM</p>
                        <div className="flex items-center gap-1 mt-1">
                          <span className="inline-block w-2 h-2 rounded-full bg-green-500"></span>
                          <span className="text-xs text-green-500">Confirmed</span>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-pink-500/50 text-pink-400 hover:bg-pink-500/10"
                      >
                        Reschedule
                      </Button>
                    </div>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg border border-white/10">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-white">Annual Physical</h4>
                        <p className="text-sm text-white/70">Dr. JEYASURYA S • May 10, 2025 • 2:00 PM</p>
                        <div className="flex items-center gap-1 mt-1">
                          <span className="inline-block w-2 h-2 rounded-full bg-amber-500"></span>
                          <span className="text-xs text-amber-500">Waiting Confirmation</span>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-pink-500/50 text-pink-400 hover:bg-pink-500/10"
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-medium mb-3">Schedule a New Appointment</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white/10 rounded-lg p-3 border border-white/10">
                    <h5 className="font-medium text-white mb-2">Step 1</h5>
                    <p className="text-sm text-white/70">Select a department</p>
                    <div className="mt-3">
                      <select className="w-full bg-white/10 border border-white/20 rounded-md p-2 text-white">
                        <option>Cardiology</option>
                        <option>Internal Medicine</option>
                        <option>Neurology</option>
                        <option>General Checkup</option>
                      </select>
                    </div>
                  </div>

                  <div className="bg-white/10 rounded-lg p-3 border border-white/10">
                    <h5 className="font-medium text-white mb-2">Step 2</h5>
                    <p className="text-sm text-white/70">Choose a date</p>
                    <div className="mt-3 grid grid-cols-7 gap-1">
                      {[...Array(7)].map((_, i) => (
                        <div
                          key={i}
                          className={`text-center p-1 rounded ${i === 2 ? "bg-pink-500/20 border border-pink-500/50" : "hover:bg-white/10"}`}
                        >
                          <div className="text-xs text-white/70">{["M", "T", "W", "T", "F", "S", "S"][i]}</div>
                          <div className={`text-sm ${i === 2 ? "text-pink-400" : "text-white"}`}>{i + 15}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white/10 rounded-lg p-3 border border-white/10">
                    <h5 className="font-medium text-white mb-2">Step 3</h5>
                    <p className="text-sm text-white/70">Select a time</p>
                    <div className="mt-3 grid grid-cols-2 gap-1">
                      {["9:00 AM", "10:30 AM", "1:00 PM", "2:30 PM"].map((time, i) => (
                        <div
                          key={i}
                          className={`text-center p-1 rounded text-sm ${i === 1 ? "bg-pink-500/20 border border-pink-500/50 text-pink-400" : "bg-white/5 hover:bg-white/10 text-white"}`}
                        >
                          {time}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <Button className="w-full mt-4 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500">
                  Confirm Appointment
                </Button>
              </div>
            </CardContent>
          </Card>
        )

      case "Insurance & Appointments":
        return (
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">Insurance Details</h2>

              <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-white/10 rounded-xl p-6 mb-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className="h-12 w-12 rounded-full bg-pink-500/20 flex items-center justify-center">
                    <Shield className="h-6 w-6 text-pink-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-white">HealthSafe Corp</h3>
                    <p className="text-sm text-white/60">Premium Health Plan</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-white/60">Policy ID</p>
                      <p className="font-medium">HSC-234123-X</p>
                    </div>
                    <div>
                      <p className="text-sm text-white/60">Coverage</p>
                      <p className="font-medium">₹3,00,000</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-white/60">Valid From</p>
                      <p className="font-medium">Jan 01, 2025</p>
                    </div>
                    <div>
                      <p className="text-sm text-white/60">Valid Until</p>
                      <p className="font-medium">Dec 31, 2025</p>
                    </div>
                  </div>
                </div>
              </div>

              <h3 className="text-lg font-medium mb-3">Recent Claims</h3>
              <div className="space-y-3">
                <div className="bg-white/10 p-4 rounded-lg border border-white/10">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">Hospital Admission</h4>
                      <p className="text-sm text-white/70">Mar 10, 2025</p>
                      <p className="text-sm text-white/70">Amount: ₹48,000</p>
                    </div>
                    <div className="text-right">
                      <div className="inline-block px-2 py-1 rounded-full bg-amber-500/20 text-amber-500 text-xs font-medium">
                        In Review
                      </div>
                      <p className="text-sm text-white/60 mt-1">Claim ID: C-9876</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/10 p-4 rounded-lg border border-white/10">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">ECG & Tests</h4>
                      <p className="text-sm text-white/70">Feb 15, 2025</p>
                      <p className="text-sm text-white/70">Amount: ₹12,500</p>
                    </div>
                    <div className="text-right">
                      <div className="inline-block px-2 py-1 rounded-full bg-green-500/20 text-green-500 text-xs font-medium">
                        Approved
                      </div>
                      <p className="text-sm text-white/60 mt-1">Claim ID: C-8765</p>
                    </div>
                  </div>
                </div>
              </div>

              <Button className="mt-4 ml-auto block bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500">
                File New Claim
              </Button>
            </CardContent>
          </Card>
        )

      case "Rewards":
        return (
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Health Rewards</h2>
                <div className="bg-white/10 px-3 py-1 rounded-full flex items-center gap-2">
                  <Trophy className="h-4 w-4 text-amber-400" />
                  <span className="font-medium text-amber-400">120 Points</span>
                </div>
              </div>

              <div className="bg-gradient-to-br from-amber-500/20 to-pink-500/20 border border-white/10 rounded-xl p-6 mb-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="h-16 w-16 rounded-full bg-amber-500/20 flex items-center justify-center">
                    <Trophy className="h-8 w-8 text-amber-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-white">Silver Member</h3>
                    <div className="w-full bg-white/10 h-2 rounded-full mt-1">
                      <div
                        className="bg-gradient-to-r from-amber-400 to-pink-500 h-full rounded-full"
                        style={{ width: "65%" }}
                      ></div>
                    </div>
                    <p className="text-sm text-white/60 mt-1">80 more points to Gold!</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="bg-white/10 p-4 rounded-lg border border-white/10">
                  <h3 className="font-medium flex items-center gap-2">
                    <span className="h-6 w-6 rounded-full bg-amber-500/20 flex items-center justify-center">
                      <Trophy className="h-4 w-4 text-amber-400" />
                    </span>
                    Your Stats
                  </h3>
                  <ul className="mt-3 space-y-2">
                    <li className="flex justify-between">
                      <span className="text-white/70">Surveys Completed:</span>
                      <span className="font-medium">4</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-white/70">Appointments Kept:</span>
                      <span className="font-medium">7</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-white/70">Medication Adherence:</span>
                      <span className="font-medium">92%</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-white/70">Health Goals Met:</span>
                      <span className="font-medium">3/5</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-white/10 p-4 rounded-lg border border-white/10">
                  <h3 className="font-medium flex items-center gap-2">
                    <span className="h-6 w-6 rounded-full bg-pink-500/20 flex items-center justify-center">
                      <Trophy className="h-4 w-4 text-pink-500" />
                    </span>
                    Available Rewards
                  </h3>
                  <ul className="mt-3 space-y-2">
                    <li className="flex justify-between items-center">
                      <span className="text-white/70">₹200 OFF next checkup</span>
                      <Button size="sm" className="h-7 text-xs bg-gradient-to-r from-pink-600 to-purple-600">
                        Redeem
                      </Button>
                    </li>
                    <li className="flex justify-between items-center">
                      <span className="text-white/70">Free blood test</span>
                      <Button size="sm" className="h-7 text-xs bg-gradient-to-r from-pink-600 to-purple-600">
                        Redeem
                      </Button>
                    </li>
                    <li className="flex justify-between items-center">
                      <span className="text-white/70">Health food coupon</span>
                      <Button size="sm" disabled className="h-7 text-xs">
                        150 pts needed
                      </Button>
                    </li>
                    <li className="flex justify-between items-center">
                      <span className="text-white/70">Fitness tracker discount</span>
                      <Button size="sm" disabled className="h-7 text-xs">
                        250 pts needed
                      </Button>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="bg-white/10 p-4 rounded-lg border border-white/10">
                <h3 className="font-medium mb-3">Earn More Points</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Complete Health Survey</p>
                      <p className="text-sm text-white/70">Answer questions about your lifestyle</p>
                    </div>
                    <Button size="sm" className="h-7 text-xs bg-gradient-to-r from-pink-600 to-purple-600">
                      +50 pts
                    </Button>
                  </div>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Track Medication</p>
                      <p className="text-sm text-white/70">Log your medication for 7 days</p>
                    </div>
                    <Button size="sm" className="h-7 text-xs bg-gradient-to-r from-pink-600 to-purple-600">
                      +30 pts
                    </Button>
                  </div>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Invite a Friend</p>
                      <p className="text-sm text-white/70">Refer someone to CARDISENSE</p>
                    </div>
                    <Button size="sm" className="h-7 text-xs bg-gradient-to-r from-pink-600 to-purple-600">
                      +75 pts
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )

      case "Sense+ Chatbot":
        return (
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">Sense+ Medical Assistant</h2>
              <SenseChat />
            </CardContent>
          </Card>
        )

      default:
        return (
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-6 text-center">
              <div className="py-12">
                <div className="mx-auto w-16 h-16 rounded-full bg-pink-500/20 flex items-center justify-center mb-4">
                  <Heart className="h-8 w-8 text-pink-500" />
                </div>
                <h3 className="text-xl font-medium mb-2">Select a Feature</h3>
                <p className="text-white/60 mb-6">Choose one of the CARDISENSE features to preview</p>
                <div className="flex flex-wrap justify-center gap-2">
                  {features.map((feature) => (
                    <Button
                      key={feature.name}
                      variant="outline"
                      className="border-pink-500/50 text-pink-400 hover:bg-pink-500/10"
                      onClick={() => setSelectedFeature(feature.name)}
                    >
                      {feature.name}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">CARDISENSE Features</h2>
        <div className="flex flex-wrap gap-2">
          {features.map((feature) => (
            <Button
              key={feature.name}
              size="sm"
              variant={selectedFeature === feature.name ? "default" : "outline"}
              className={
                selectedFeature === feature.name
                  ? "bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
                  : "border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
              }
              onClick={() => setSelectedFeature(feature.name)}
            >
              <feature.icon className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">{feature.name}</span>
            </Button>
          ))}
        </div>
      </div>

      {renderFeature()}
    </div>
  )
}
