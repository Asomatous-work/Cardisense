"use client"

import { useState, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import { Loader2, CreditCard, Eye, IndianRupee } from "lucide-react"

interface Patient {
  id: number
  name: string
  patient_id: string
  email?: string
}

interface PaymentRecord {
  id: number
  patientId: number
  patientName: string
  service: string
  date: string
  amount: number
  status: "paid" | "pending" | "failed"
}

export function PatientPaymentsTable() {
  const { toast } = useToast()
  const [patients, setPatients] = useState<Patient[]>([])
  const [paymentRecords, setPaymentRecords] = useState<PaymentRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [requestDialogOpen, setRequestDialogOpen] = useState(false)
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null)
  const [paymentAmount, setPaymentAmount] = useState<number>(1000)
  const [serviceType, setServiceType] = useState<string>("Cardiology Checkup")
  const [requestLoading, setRequestLoading] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()

        // Fetch patients
        const { data: patientsData, error: patientsError } = await supabase
          .from("patients")
          .select("id, name, patient_id, email")
          .order("name")

        if (patientsError) throw patientsError

        // Create a map of patient IDs to names for easier lookup
        const patientMap = new Map()
        patientsData?.forEach((patient) => {
          patientMap.set(patient.id, patient.name)
        })

        // Fetch appointments without trying to join with patients
        const { data: appointmentsData, error: appointmentsError } = await supabase
          .from("appointments")
          .select(`
            id, 
            appointment_date,
            type,
            payment_status,
            patient_id
          `)
          .order("appointment_date", { ascending: false })

        if (appointmentsError) throw appointmentsError

        // Fetch payment requests
        const { data: paymentRequestsData, error: paymentRequestsError } = await supabase
          .from("payment_requests")
          .select(`
            id,
            patient_id,
            amount,
            service_type,
            description,
            status,
            created_at,
            due_date
          `)
          .order("created_at", { ascending: false })

        if (paymentRequestsError) throw paymentRequestsError

        // Set patients data
        setPatients(patientsData || [])

        // Format appointment records
        const formattedAppointments = (appointmentsData || []).map((appointment) => {
          const patientName = patientMap.get(appointment.patient_id) || "Unknown Patient"

          return {
            id: appointment.id,
            patientId: appointment.patient_id,
            patientName: patientName,
            service: appointment.type || "Appointment",
            date: appointment.appointment_date
              ? new Date(appointment.appointment_date).toLocaleDateString("en-IN", {
                  year: "numeric",
                  month: "short",
                  day: "numeric",
                })
              : "No date",
            amount: appointment.type === "Emergency" ? 2500 : appointment.type === "Follow-up" ? 800 : 1500,
            status: (appointment.payment_status === "paid" ? "paid" : "pending") as "paid" | "pending" | "failed",
          }
        })

        // Format payment request records
        const formattedPaymentRequests = (paymentRequestsData || []).map((request) => {
          const patientName = patientMap.get(request.patient_id) || "Unknown Patient"

          return {
            id: request.id,
            patientId: request.patient_id,
            patientName: patientName,
            service: request.description || request.service_type,
            date: request.created_at
              ? new Date(request.created_at).toLocaleDateString("en-IN", {
                  year: "numeric",
                  month: "short",
                  day: "numeric",
                })
              : "No date",
            amount: Number(request.amount),
            status: request.status as "paid" | "pending" | "failed",
          }
        })

        // Combine both datasets
        setPaymentRecords([...formattedAppointments, ...formattedPaymentRequests])
      } catch (error) {
        console.error("Error fetching data:", error)
        toast({
          title: "Error",
          description: "Failed to fetch payment data. Using sample data instead.",
          variant: "destructive",
        })

        // Set sample data
        setPaymentRecords([
          {
            id: 1,
            patientId: 1,
            patientName: "Rajesh Kumar",
            service: "Cardiology Checkup",
            date: "Apr 12, 2025",
            amount: 1500,
            status: "paid",
          },
          {
            id: 2,
            patientId: 2,
            patientName: "Priya Sharma",
            service: "Follow-up Consultation",
            date: "Apr 10, 2025",
            amount: 800,
            status: "pending",
          },
          {
            id: 3,
            patientId: 3,
            patientName: "Suresh Patel",
            service: "Emergency Consultation",
            date: "Apr 8, 2025",
            amount: 2500,
            status: "pending",
          },
        ])
      } finally {
        setLoading(false)
      }
    }

    fetchData()

    // Set up real-time subscription for payment changes
    const supabase = createClientSupabaseClient()
    const paymentSubscription = supabase
      .channel("payment-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "payment_requests",
        },
        () => {
          fetchData()
        },
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "appointments",
        },
        () => {
          fetchData()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(paymentSubscription)
    }
  }, [toast])

  const handleRequestPayment = async () => {
    if (!selectedPatient) return

    setRequestLoading(true)
    try {
      const supabase = createClientSupabaseClient()
      const { error } = await supabase.from("payment_requests").insert({
        patient_id: selectedPatient.id,
        amount: paymentAmount,
        service_type: serviceType.toLowerCase().split(" ")[0], // First word as service_type
        description: serviceType, // Full service name as description
        status: "pending",
        created_at: new Date().toISOString(),
        due_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // Due date 7 days from now
      })

      if (error) throw error

      toast({
        title: "Payment Request Sent",
        description: `Payment request of ₹${paymentAmount} sent to ${selectedPatient.name}`,
      })

      setRequestDialogOpen(false)
    } catch (error) {
      console.error("Error requesting payment:", error)
      toast({
        title: "Error",
        description: "Failed to send payment request. Please try again.",
        variant: "destructive",
      })
    } finally {
      setRequestLoading(false)
    }
  }

  const openRequestDialog = (patient: Patient) => {
    setSelectedPatient(patient)
    setRequestDialogOpen(true)
  }

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <CreditCard className="h-5 w-5 text-cyan-500" />
          <span>Patient Payments</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-10 w-10 animate-spin text-cyan-500" />
          </div>
        ) : (
          <div className="rounded-md border border-white/10 overflow-hidden">
            <Table>
              <TableHeader className="bg-white/5">
                <TableRow>
                  <TableHead>Patient</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paymentRecords.length > 0 ? (
                  paymentRecords.map((record) => (
                    <TableRow key={`${record.id}-${record.service}`} className="border-white/5">
                      <TableCell className="font-medium">{record.patientName}</TableCell>
                      <TableCell>{record.service}</TableCell>
                      <TableCell>{record.date}</TableCell>
                      <TableCell>₹{record.amount.toLocaleString("en-IN")}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            record.status === "paid"
                              ? "success"
                              : record.status === "pending"
                                ? "warning"
                                : "destructive"
                          }
                        >
                          {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {record.status === "pending" ? (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 border-white/20 hover:bg-white/10"
                            onClick={() => {
                              const patient = patients.find((p) => p.id === record.patientId)
                              if (patient) openRequestDialog(patient)
                            }}
                          >
                            Request
                          </Button>
                        ) : (
                          <Button size="sm" variant="ghost" className="h-8">
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">View</span>
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      No payment records found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Payment Request Dialog */}
        <Dialog open={requestDialogOpen} onOpenChange={setRequestDialogOpen}>
          <DialogContent className="sm:max-w-[425px] bg-gray-900 text-white border-white/10">
            <DialogHeader>
              <DialogTitle>Request Payment</DialogTitle>
              <DialogDescription>Send a payment request to {selectedPatient?.name}</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="service" className="text-right">
                  Service
                </Label>
                <Select value={serviceType} onValueChange={setServiceType}>
                  <SelectTrigger id="service" className="col-span-3">
                    <SelectValue placeholder="Select service type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Cardiology Checkup">Cardiology Checkup</SelectItem>
                    <SelectItem value="Follow-up Consultation">Follow-up Consultation</SelectItem>
                    <SelectItem value="Emergency Consultation">Emergency Consultation</SelectItem>
                    <SelectItem value="Medication">Medication</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="amount" className="text-right">
                  Amount
                </Label>
                <div className="col-span-3 relative">
                  <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/60" />
                  <Input
                    id="amount"
                    type="number"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(Number(e.target.value))}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button
                type="submit"
                onClick={handleRequestPayment}
                disabled={requestLoading}
                className="bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400"
              >
                {requestLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>Send Request</>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}
