"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { User, Calendar, Clock, AlertCircle, Loader2 } from "lucide-react"
import { createClientSupabaseClient } from "@/lib/supabase/client"

export function DashboardStats() {
  const [stats, setStats] = useState({
    presentPatients: 0,
    pendingAppointments: 0,
    urgentCases: 0,
    completedToday: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()

        // Get present patients count
        const { count: presentCount, error: presentError } = await supabase
          .from("patients")
          .select("*", { count: "exact", head: true })
          .eq("is_present", true)

        if (presentError) throw presentError

        // Get pending appointments count
        const { count: pendingCount, error: pendingError } = await supabase
          .from("appointments")
          .select("*", { count: "exact", head: true })
          .in("status", ["pending", "urgent"])

        if (pendingError) throw pendingError

        // Get urgent cases count
        const { count: urgentCount, error: urgentError } = await supabase
          .from("appointments")
          .select("*", { count: "exact", head: true })
          .eq("is_urgent", true)

        if (urgentError) throw urgentError

        // Get completed today count
        const today = new Date().toISOString().split("T")[0]
        const { count: completedCount, error: completedError } = await supabase
          .from("appointments")
          .select("*", { count: "exact", head: true })
          .eq("status", "completed")
          .eq("appointment_date", today)

        if (completedError) throw completedError

        setStats({
          presentPatients: presentCount || 0,
          pendingAppointments: pendingCount || 0,
          urgentCases: urgentCount || 0,
          completedToday: completedCount || 0,
        })
      } catch (error) {
        console.error("Error fetching stats:", error)

        // Set some sample data for demonstration
        setStats({
          presentPatients: 3,
          pendingAppointments: 5,
          urgentCases: 1,
          completedToday: 2,
        })
      } finally {
        setLoading(false)
      }
    }

    fetchStats()

    // Set up real-time subscription for stats updates
    const supabase = createClientSupabaseClient()

    const patientsSubscription = supabase
      .channel("patients-stats")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "patients",
        },
        () => {
          fetchStats()
        },
      )
      .subscribe()

    const appointmentsSubscription = supabase
      .channel("appointments-stats")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "appointments",
        },
        () => {
          fetchStats()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(patientsSubscription)
      supabase.removeChannel(appointmentsSubscription)
    }
  }, [])

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="bg-white/5 border-white/10 p-6">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-full bg-pink-500/20 flex items-center justify-center">
            <User className="h-6 w-6 text-pink-500" />
          </div>
          <div>
            <p className="text-sm text-white/70">Patients Present</p>
            {loading ? (
              <div className="h-7 flex items-center">
                <Loader2 className="h-5 w-5 animate-spin text-white/50" />
              </div>
            ) : (
              <h3 className="text-2xl font-bold">{stats.presentPatients}</h3>
            )}
          </div>
        </div>
      </Card>

      <Card className="bg-white/5 border-white/10 p-6">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-full bg-cyan-500/20 flex items-center justify-center">
            <Calendar className="h-6 w-6 text-cyan-500" />
          </div>
          <div>
            <p className="text-sm text-white/70">Pending Appointments</p>
            {loading ? (
              <div className="h-7 flex items-center">
                <Loader2 className="h-5 w-5 animate-spin text-white/50" />
              </div>
            ) : (
              <h3 className="text-2xl font-bold">{stats.pendingAppointments}</h3>
            )}
          </div>
        </div>
      </Card>

      <Card className="bg-white/5 border-white/10 p-6">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-full bg-red-500/20 flex items-center justify-center">
            <AlertCircle className="h-6 w-6 text-red-500" />
          </div>
          <div>
            <p className="text-sm text-white/70">Urgent Cases</p>
            {loading ? (
              <div className="h-7 flex items-center">
                <Loader2 className="h-5 w-5 animate-spin text-white/50" />
              </div>
            ) : (
              <h3 className="text-2xl font-bold">{stats.urgentCases}</h3>
            )}
          </div>
        </div>
      </Card>

      <Card className="bg-white/5 border-white/10 p-6">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-full bg-green-500/20 flex items-center justify-center">
            <Clock className="h-6 w-6 text-green-500" />
          </div>
          <div>
            <p className="text-sm text-white/70">Completed Today</p>
            {loading ? (
              <div className="h-7 flex items-center">
                <Loader2 className="h-5 w-5 animate-spin text-white/50" />
              </div>
            ) : (
              <h3 className="text-2xl font-bold">{stats.completedToday}</h3>
            )}
          </div>
        </div>
      </Card>
    </div>
  )
}
