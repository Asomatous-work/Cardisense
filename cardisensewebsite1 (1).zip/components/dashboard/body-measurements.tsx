"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { ArrowUp, ArrowDown } from "lucide-react"
import { useDeviceType } from "@/hooks/use-device-type"

export function BodyMeasurements() {
  const { isMobile } = useDeviceType()
  const [height, setHeight] = useState(170)
  const [weight, setWeight] = useState(72)
  const [chest, setChest] = useState(44.5)
  const [waist, setWaist] = useState(34)
  const [hip, setHip] = useState(42.5)

  const bmi = (weight / ((height / 100) * (height / 100))).toFixed(1)

  const getBmiCategory = (bmi: number) => {
    if (bmi < 18.5) return { category: "Underweight", color: "text-blue-400" }
    if (bmi < 25) return { category: "Healthy", color: "text-green-500" }
    if (bmi < 30) return { category: "Overweight", color: "text-amber-500" }
    return { category: "Obese", color: "text-red-500" }
  }

  const bmiInfo = getBmiCategory(Number.parseFloat(bmi))

  const getRecommendations = () => {
    if (Number.parseFloat(bmi) < 18.5) {
      return {
        workouts: ["Strength training", "Push-ups", "Squats"],
        yoga: ["Warrior pose", "Bow pose", "Bridge pose"],
      }
    } else if (Number.parseFloat(bmi) < 25) {
      return {
        workouts: ["HIIT", "Running", "Swimming"],
        yoga: ["Sun salutation", "Triangle pose", "Downward dog"],
      }
    } else if (Number.parseFloat(bmi) < 30) {
      return {
        workouts: ["Cardio", "Cycling", "Brisk walking"],
        yoga: ["Chair pose", "Cobra pose", "Warrior II"],
      }
    } else {
      return {
        workouts: ["Walking", "Water aerobics", "Stationary cycling"],
        yoga: ["Mountain pose", "Child's pose", "Cat-cow stretch"],
      }
    }
  }

  const recommendations = getRecommendations()

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card className="bg-white/5 border-white/10 p-4 sm:p-6">
        <h3 className="text-xl font-medium mb-6">Body Measurements</h3>
        <div className="space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm text-white/80">Height</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value))}
                  className="w-16 bg-white/10 border border-white/20 rounded p-1 text-center text-white"
                />
                <span className="text-xs text-white/60">cm</span>
              </div>
            </div>
            <Slider
              value={[height]}
              min={140}
              max={200}
              step={1}
              onValueChange={(value) => setHeight(value[0])}
              className="cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm text-white/80">Weight</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={weight}
                  onChange={(e) => setWeight(Number(e.target.value))}
                  className="w-16 bg-white/10 border border-white/20 rounded p-1 text-center text-white"
                />
                <span className="text-xs text-white/60">kg</span>
              </div>
            </div>
            <Slider
              value={[weight]}
              min={40}
              max={150}
              step={1}
              onValueChange={(value) => setWeight(value[0])}
              className="cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm text-white/80">Chest</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={chest}
                  onChange={(e) => setChest(Number(e.target.value))}
                  className="w-16 bg-white/10 border border-white/20 rounded p-1 text-center text-white"
                />
                <span className="text-xs text-white/60">in</span>
              </div>
            </div>
            <Slider
              value={[chest]}
              min={30}
              max={60}
              step={0.5}
              onValueChange={(value) => setChest(value[0])}
              className="cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm text-white/80">Waist</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={waist}
                  onChange={(e) => setWaist(Number(e.target.value))}
                  className="w-16 bg-white/10 border border-white/20 rounded p-1 text-center text-white"
                />
                <span className="text-xs text-white/60">in</span>
              </div>
            </div>
            <Slider
              value={[waist]}
              min={20}
              max={50}
              step={0.5}
              onValueChange={(value) => setWaist(value[0])}
              className="cursor-pointer"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm text-white/80">Hip</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={hip}
                  onChange={(e) => setHip(Number(e.target.value))}
                  className="w-16 bg-white/10 border border-white/20 rounded p-1 text-center text-white"
                />
                <span className="text-xs text-white/60">in</span>
              </div>
            </div>
            <Slider
              value={[hip]}
              min={30}
              max={60}
              step={0.5}
              onValueChange={(value) => setHip(value[0])}
              className="cursor-pointer"
            />
          </div>
        </div>
      </Card>

      <Card className="bg-white/5 border-white/10 p-4 sm:p-6 flex flex-col">
        <h3 className="text-xl font-medium mb-6">Health Summary</h3>

        <div className="mb-6">
          <h4 className="text-sm text-white/80 mb-2">Body Mass Index (BMI)</h4>
          <div className="flex items-end gap-2">
            <span className="text-4xl font-bold">{bmi}</span>
            <span className={`${bmiInfo.color} text-lg font-medium`}>{bmiInfo.category}</span>
          </div>

          <div className="mt-2 w-full bg-white/10 h-2 rounded-full overflow-hidden">
            <div className="flex h-full">
              <div className="bg-blue-400 h-full" style={{ width: "18.5%" }}></div>
              <div className="bg-green-500 h-full" style={{ width: "6.5%" }}></div>
              <div className="bg-amber-500 h-full" style={{ width: "5%" }}></div>
              <div className="bg-red-500 h-full" style={{ width: "70%" }}></div>
            </div>
          </div>

          <div className="flex justify-between text-xs text-white/60 mt-1">
            <span>15</span>
            <span>18.5</span>
            <span>25</span>
            <span>30</span>
            <span>40</span>
          </div>
        </div>

        <div className="space-y-4 mb-6">
          <div className="flex flex-col">
            <span className="text-sm text-white/80">Chest</span>
            <div className="flex items-center justify-between">
              <span className="text-xl font-medium">{chest} in</span>
              <span className="text-pink-400">
                <ArrowUp className="h-4 w-4" />
              </span>
            </div>
          </div>

          <div className="flex flex-col">
            <span className="text-sm text-white/80">Waist</span>
            <div className="flex items-center justify-between">
              <span className="text-xl font-medium">{waist} in</span>
              <span className="text-green-500">
                <ArrowDown className="h-4 w-4" />
              </span>
            </div>
          </div>

          <div className="flex flex-col">
            <span className="text-sm text-white/80">Hip</span>
            <div className="flex items-center justify-between">
              <span className="text-xl font-medium">{hip} in</span>
              <span className="text-green-500">
                <ArrowDown className="h-4 w-4" />
              </span>
            </div>
          </div>
        </div>

        <div className="mt-auto">
          <h4 className="text-sm text-white/80 mb-2">Recommended Activities</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white/10 rounded-lg p-3">
              <h5 className="font-medium text-pink-400 mb-2">Workouts</h5>
              <ul className="list-disc list-inside text-sm space-y-1">
                {recommendations.workouts.map((workout, index) => (
                  <li key={index} className="text-white/80">
                    {workout}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white/10 rounded-lg p-3">
              <h5 className="font-medium text-purple-400 mb-2">Yoga</h5>
              <ul className="list-disc list-inside text-sm space-y-1">
                {recommendations.yoga.map((yoga, index) => (
                  <li key={index} className="text-white/80">
                    {yoga}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}
