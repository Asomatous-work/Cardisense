"use client"

import { useState, useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  User,
  Search,
  Video,
  Phone,
  Mic,
  MicOff,
  VideoOff,
  MessageSquare,
  MoreVertical,
  Loader2,
  X,
  Send,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export function TelemedicineConsole() {
  const { toast } = useToast()
  const [patients, setPatients] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<any | null>(null)
  const [inCall, setInCall] = useState(false)
  const [micEnabled, setMicEnabled] = useState(true)
  const [videoEnabled, setVideoEnabled] = useState(true)
  const [chatOpen, setChatOpen] = useState(false)
  const [messageText, setMessageText] = useState("")
  const [messages, setMessages] = useState<any[]>([])
  const [callDuration, setCallDuration] = useState(0)
  const [callTimer, setCallTimer] = useState<NodeJS.Timeout | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Fetch patients from the database
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()

        // Fetch all patients
        const { data, error } = await supabase.from("patients").select("*").order("name")

        if (error) {
          throw error
        }

        // Transform the data
        const formattedData = (data || []).map((patient) => ({
          id: patient.id,
          name: patient.name,
          medicalCondition: patient.medical_condition || "No condition specified",
          contactNumber: patient.contact_number || "No contact number",
          lastVisit: patient.last_visit ? new Date(patient.last_visit).toLocaleDateString() : "First visit",
          status: patient.status || "active",
          online: Math.random() > 0.5, // Random online status for demo
        }))

        setPatients(formattedData)
      } catch (error) {
        console.error("Error fetching patients:", error)
        toast({
          title: "Error",
          description: "Failed to fetch patients. Please try again.",
          variant: "destructive",
        })

        // Set some sample data for demonstration
        setPatients(getSamplePatients())
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  // Scroll to bottom of messages when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (callTimer) {
        clearInterval(callTimer)
      }
    }
  }, [callTimer])

  // Sample data for demonstration when database is not available
  const getSamplePatients = () => {
    return [
      {
        id: 1,
        name: "Aravind G",
        medicalCondition: "Hypertension, Diabetes",
        contactNumber: "+91 9876543210",
        lastVisit: "15 Mar 2025",
        status: "active",
        online: true,
      },
      {
        id: 2,
        name: "Rafikhan L",
        medicalCondition: "Post-surgery follow-up",
        contactNumber: "+91 9876543211",
        lastVisit: "2 Apr 2025",
        status: "active",
        online: false,
      },
      {
        id: 3,
        name: "Sethu Raja P",
        medicalCondition: "Chest pain evaluation",
        contactNumber: "+91 9876543212",
        lastVisit: "First visit",
        status: "pending",
        online: true,
      },
    ]
  }

  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      patient.medicalCondition.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleStartCall = (patient: any) => {
    setSelectedPatient(patient)
    setInCall(true)
    setCallDuration(0)

    // Start the call timer
    const timer = setInterval(() => {
      setCallDuration((prev) => prev + 1)
    }, 1000)

    setCallTimer(timer)

    toast({
      title: "Call Started",
      description: `You are now in a call with ${patient.name}`,
      variant: "default",
    })
  }

  const handleEndCall = () => {
    if (callTimer) {
      clearInterval(callTimer)
      setCallTimer(null)
    }

    setInCall(false)

    toast({
      title: "Call Ended",
      description: `Call with ${selectedPatient?.name} has ended`,
      variant: "default",
    })
  }

  const formatCallDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleToggleMic = () => {
    setMicEnabled(!micEnabled)
  }

  const handleToggleVideo = () => {
    setVideoEnabled(!videoEnabled)
  }

  const handleToggleChat = () => {
    setChatOpen(!chatOpen)
  }

  const handleSendMessage = () => {
    if (!messageText.trim()) {
      return
    }

    const newMessage = {
      id: messages.length + 1,
      sender: "doctor",
      text: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages([...messages, newMessage])
    setMessageText("")

    // Simulate a response after a delay
    if (Math.random() > 0.5) {
      setTimeout(
        () => {
          const responseMessage = {
            id: messages.length + 2,
            sender: "patient",
            text: "I can hear you clearly now, thank you doctor.",
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          }

          setMessages((prevMessages) => [...prevMessages, responseMessage])
        },
        2000 + Math.random() * 3000,
      )
    }
  }

  return (
    <Card className="bg-white/5 border-white/10 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Video className="h-5 w-5 text-cyan-500" />
          <span>Telemedicine Console</span>
        </h2>
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40" />
          <input
            type="text"
            placeholder="Search patients..."
            className="bg-white/10 border border-white/20 rounded-md pl-9 pr-4 py-1 text-sm text-white w-48"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {inCall ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[600px]">
          {/* Video Call Area */}
          <div
            className={`bg-slate-800 rounded-lg border border-white/10 overflow-hidden relative ${chatOpen ? "md:col-span-2" : "md:col-span-3"}`}
          >
            {/* Patient Video (Placeholder) */}
            <div className="w-full h-full flex items-center justify-center">
              {videoEnabled ? (
                <div className="text-center">
                  <div className="h-24 w-24 rounded-full bg-pink-500/20 flex items-center justify-center mx-auto mb-4">
                    <User className="h-12 w-12 text-pink-500" />
                  </div>
                  <h3 className="font-medium text-lg">{selectedPatient?.name}</h3>
                  <p className="text-white/60">{selectedPatient?.medicalCondition}</p>
                </div>
              ) : (
                <div className="text-center">
                  <VideoOff className="h-16 w-16 text-white/30 mx-auto mb-4" />
                  <p className="text-white/60">Video is turned off</p>
                </div>
              )}
            </div>

            {/* Doctor Video (Small Overlay) */}
            <div className="absolute bottom-4 right-4 w-48 h-36 bg-slate-700 rounded-lg border border-white/10 flex items-center justify-center">
              {videoEnabled ? (
                <div className="text-center">
                  <div className="h-12 w-12 rounded-full bg-cyan-500/20 flex items-center justify-center mx-auto mb-2">
                    <User className="h-6 w-6 text-cyan-500" />
                  </div>
                  <p className="text-xs text-white/60">Dr. KIRUPA D</p>
                </div>
              ) : (
                <VideoOff className="h-8 w-8 text-white/30" />
              )}
            </div>

            {/* Call Controls */}
            <div className="absolute bottom-0 left-0 right-0 bg-black/50 p-4 flex items-center justify-center gap-4">
              <Button
                size="icon"
                variant={micEnabled ? "default" : "destructive"}
                className={`h-10 w-10 rounded-full ${micEnabled ? "bg-white/20 hover:bg-white/30" : ""}`}
                onClick={handleToggleMic}
              >
                {micEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
              </Button>
              <Button
                size="icon"
                variant={videoEnabled ? "default" : "destructive"}
                className={`h-10 w-10 rounded-full ${videoEnabled ? "bg-white/20 hover:bg-white/30" : ""}`}
                onClick={handleToggleVideo}
              >
                {videoEnabled ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
              </Button>
              <Button size="icon" variant="destructive" className="h-12 w-12 rounded-full" onClick={handleEndCall}>
                <Phone className="h-6 w-6 rotate-135" />
              </Button>
              <Button
                size="icon"
                variant={chatOpen ? "default" : "outline"}
                className={`h-10 w-10 rounded-full ${chatOpen ? "bg-white/20 hover:bg-white/30" : "border-white/20"}`}
                onClick={handleToggleChat}
              >
                <MessageSquare className="h-5 w-5" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="icon" variant="outline" className="h-10 w-10 rounded-full border-white/20">
                    <MoreVertical className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>Share screen</DropdownMenuItem>
                  <DropdownMenuItem>Record call</DropdownMenuItem>
                  <DropdownMenuItem>Call settings</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <div className="absolute top-4 left-4 bg-black/50 px-3 py-1 rounded-full text-sm">
                {formatCallDuration(callDuration)}
              </div>
            </div>
          </div>

          {/* Chat Area */}
          {chatOpen && (
            <div className="bg-white/5 rounded-lg border border-white/10 overflow-hidden">
              <div className="p-3 border-b border-white/10 flex items-center justify-between">
                <h3 className="font-medium">In-Call Chat</h3>
                <Button size="icon" variant="ghost" className="h-7 w-7 rounded-full" onClick={handleToggleChat}>
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex flex-col h-[calc(600px-6rem)]">
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.length > 0 ? (
                    messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.sender === "doctor" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[80%] rounded-lg p-3 ${
                            message.sender === "doctor" ? "bg-cyan-500/20 text-white" : "bg-white/10 text-white"
                          }`}
                        >
                          <p className="text-sm">{message.text}</p>
                          <p className="text-xs text-white/60 mt-1 text-right">{message.timestamp}</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-white/60">
                      <MessageSquare className="h-8 w-8 mx-auto mb-2 text-white/30" />
                      <p className="text-sm">No messages yet</p>
                      <p className="text-xs mt-1">Send a message to start chatting</p>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                <div className="p-3 border-t border-white/10">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder="Type a message..."
                      className="flex-1 bg-white/10 border border-white/20 rounded-full px-4 py-2 text-sm text-white"
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault()
                          handleSendMessage()
                        }
                      }}
                    />
                    <Button
                      size="icon"
                      className="h-8 w-8 rounded-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                      onClick={handleSendMessage}
                      disabled={!messageText.trim()}
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            <div className="col-span-full flex justify-center items-center py-12">
              <Loader2 className="h-12 w-12 animate-spin text-cyan-500" />
            </div>
          ) : (
            <>
              {filteredPatients.length > 0 ? (
                filteredPatients.map((patient) => (
                  <div key={patient.id} className="bg-white/10 rounded-lg p-4 border border-white/10">
                    <div className="flex items-start justify-between">
                      <div className="flex gap-3">
                        <div className="relative">
                          <div className="h-12 w-12 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                            <User className="h-6 w-6 text-pink-500" />
                          </div>
                          <div
                            className={`absolute bottom-0 right-0 h-3 w-3 rounded-full ${patient.online ? "bg-green-500" : "bg-gray-500"}`}
                          ></div>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">{patient.name}</h3>
                            <span
                              className={`px-2 py-0.5 rounded-full text-xs font-medium ${patient.online ? "bg-green-500/20 text-green-400" : "bg-gray-500/20 text-gray-400"}`}
                            >
                              {patient.online ? "Online" : "Offline"}
                            </span>
                          </div>
                          <p className="text-sm text-white/70">{patient.medicalCondition}</p>
                          <p className="text-xs text-white/60 mt-1">{patient.contactNumber}</p>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button
                          size="sm"
                          className="h-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                          onClick={() => handleStartCall(patient)}
                          disabled={!patient.online}
                        >
                          <Video className="h-4 w-4 mr-1" />
                          Video Call
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                          disabled={!patient.online}
                        >
                          <Phone className="h-4 w-4 mr-1" />
                          Audio Call
                        </Button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-full text-center py-12 text-white/60 bg-white/5 rounded-lg border border-white/10">
                  <Video className="h-12 w-12 mx-auto mb-3 text-white/30" />
                  <p>No patients found</p>
                  <p className="text-sm mt-1">Try adjusting your search</p>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </Card>
  )
}
