"use client"

import { useState, useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { User, Search, MessageSquare, Send, Paperclip, ImageIcon, File, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { createClientSupabaseClient } from "@/lib/supabase/client"

export function PatientMessaging() {
  const { toast } = useToast()
  const [patients, setPatients] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<any | null>(null)
  const [messageText, setMessageText] = useState("")
  const [messages, setMessages] = useState<any[]>([])
  const [sendingMessage, setSendingMessage] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Fetch patients from the database
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()

        // Fetch all patients
        const { data, error } = await supabase.from("patients").select("*").order("name")

        if (error) {
          throw error
        }

        // Transform the data
        const formattedData = (data || []).map((patient) => ({
          id: patient.id,
          name: patient.name,
          medicalCondition: patient.medical_condition || "No condition specified",
          contactNumber: patient.contact_number || "No contact number",
          lastVisit: patient.last_visit ? new Date(patient.last_visit).toLocaleDateString() : "First visit",
          status: patient.status || "active",
          unreadMessages: Math.floor(Math.random() * 3), // Random number for demo
        }))

        setPatients(formattedData)
      } catch (error) {
        console.error("Error fetching patients:", error)
        toast({
          title: "Error",
          description: "Failed to fetch patients. Please try again.",
          variant: "destructive",
        })

        // Set some sample data for demonstration
        setPatients(getSamplePatients())
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [toast])

  // Scroll to bottom of messages when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Sample data for demonstration when database is not available
  const getSamplePatients = () => {
    return [
      {
        id: 1,
        name: "Aravind G",
        medicalCondition: "Hypertension, Diabetes",
        contactNumber: "+91 9876543210",
        lastVisit: "15 Mar 2025",
        status: "active",
        unreadMessages: 2,
      },
      {
        id: 2,
        name: "Rafikhan L",
        medicalCondition: "Post-surgery follow-up",
        contactNumber: "+91 9876543211",
        lastVisit: "2 Apr 2025",
        status: "active",
        unreadMessages: 0,
      },
      {
        id: 3,
        name: "Sethu Raja P",
        medicalCondition: "Chest pain evaluation",
        contactNumber: "+91 9876543212",
        lastVisit: "First visit",
        status: "pending",
        unreadMessages: 1,
      },
    ]
  }

  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      patient.medicalCondition.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleSelectPatient = (patient: any) => {
    setSelectedPatient(patient)

    // Generate sample messages for demonstration
    const sampleMessages = []

    // Add some sample messages based on the patient's condition
    if (patient.medicalCondition.includes("Hypertension")) {
      sampleMessages.push(
        {
          id: 1,
          sender: "patient",
          text: "Hello doctor, I've been monitoring my blood pressure as you suggested.",
          timestamp: "10:30 AM",
        },
        {
          id: 2,
          sender: "doctor",
          text: "That's great! What readings have you been getting?",
          timestamp: "10:32 AM",
        },
        {
          id: 3,
          sender: "patient",
          text: "It's been around 130/85 in the mornings and 140/90 in the evenings.",
          timestamp: "10:35 AM",
        },
        {
          id: 4,
          sender: "doctor",
          text: "Those evening readings are a bit high. Are you taking your medication regularly?",
          timestamp: "10:37 AM",
        },
        {
          id: 5,
          sender: "patient",
          text: "Yes, I haven't missed any doses. Should I be concerned?",
          timestamp: "10:40 AM",
        },
      )
    } else if (patient.medicalCondition.includes("surgery")) {
      sampleMessages.push(
        {
          id: 1,
          sender: "patient",
          text: "Doctor, I'm experiencing some discomfort around my incision site.",
          timestamp: "2:15 PM",
        },
        {
          id: 2,
          sender: "doctor",
          text: "Is there any redness, swelling, or discharge from the site?",
          timestamp: "2:20 PM",
        },
        {
          id: 3,
          sender: "patient",
          text: "No discharge, but there is some redness and it feels warm to touch.",
          timestamp: "2:22 PM",
        },
        {
          id: 4,
          sender: "doctor",
          text: "That could indicate a mild infection. Can you send a photo of the area?",
          timestamp: "2:25 PM",
        },
      )
    } else {
      sampleMessages.push(
        {
          id: 1,
          sender: "patient",
          text: "Hello doctor, I've been experiencing chest pain recently.",
          timestamp: "4:05 PM",
        },
        {
          id: 2,
          sender: "doctor",
          text: "I'm sorry to hear that. Can you describe the pain? Is it sharp, dull, or pressure-like?",
          timestamp: "4:10 PM",
        },
        {
          id: 3,
          sender: "patient",
          text: "It's more like a pressure in the center of my chest. Sometimes it radiates to my left arm.",
          timestamp: "4:12 PM",
        },
        {
          id: 4,
          sender: "doctor",
          text: "That's concerning. How long does the pain last? And does anything trigger it?",
          timestamp: "4:15 PM",
        },
        {
          id: 5,
          sender: "patient",
          text: "It usually lasts about 5-10 minutes. It happens when I exert myself, like climbing stairs.",
          timestamp: "4:18 PM",
        },
        {
          id: 6,
          sender: "doctor",
          text: "Given these symptoms, I'd like you to come in for an evaluation as soon as possible. This could be angina. Please call the office to schedule an urgent appointment.",
          timestamp: "4:20 PM",
        },
      )
    }

    setMessages(sampleMessages)

    // Update the patient's unread messages count
    const updatedPatients = patients.map((p) => (p.id === patient.id ? { ...p, unreadMessages: 0 } : p))
    setPatients(updatedPatients)
  }

  const handleSendMessage = async () => {
    if (!messageText.trim() || !selectedPatient) {
      return
    }

    setSendingMessage(true)

    try {
      // In a real application, you would save this to the database
      // For now, we'll just update the local state

      const newMessage = {
        id: messages.length + 1,
        sender: "doctor",
        text: messageText,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }

      setMessages([...messages, newMessage])
      setMessageText("")

      // Simulate a response after a delay
      if (Math.random() > 0.5) {
        setTimeout(
          () => {
            const responseMessage = {
              id: messages.length + 2,
              sender: "patient",
              text: getRandomResponse(),
              timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            }

            setMessages((prevMessages) => [...prevMessages, responseMessage])
          },
          5000 + Math.random() * 5000,
        )
      }
    } catch (error) {
      console.error("Error sending message:", error)
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSendingMessage(false)
    }
  }

  const getRandomResponse = () => {
    const responses = [
      "Thank you, doctor. I'll follow your advice.",
      "I understand. When should I come for a follow-up?",
      "Is there anything else I should be doing?",
      "I'll try that and let you know how it goes.",
      "Should I continue with my current medication?",
      "I appreciate your help, doctor.",
    ]

    return responses[Math.floor(Math.random() * responses.length)]
  }

  return (
    <Card className="bg-white/5 border-white/10 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-cyan-500" />
          <span>Patient Messaging</span>
        </h2>
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40" />
          <input
            type="text"
            placeholder="Search patients..."
            className="bg-white/10 border border-white/20 rounded-md pl-9 pr-4 py-1 text-sm text-white w-48"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[600px]">
        {/* Patient List */}
        <div className="bg-white/5 rounded-lg border border-white/10 overflow-hidden">
          <div className="p-3 border-b border-white/10">
            <h3 className="font-medium">Patients</h3>
          </div>

          {loading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-cyan-500" />
            </div>
          ) : (
            <div className="overflow-y-auto h-[calc(600px-3rem)]">
              {filteredPatients.length > 0 ? (
                <div className="divide-y divide-white/10">
                  {filteredPatients.map((patient) => (
                    <div
                      key={patient.id}
                      className={`p-3 hover:bg-white/10 cursor-pointer transition-colors ${
                        selectedPatient?.id === patient.id ? "bg-white/10" : ""
                      }`}
                      onClick={() => handleSelectPatient(patient)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                          <User className="h-5 w-5 text-pink-500" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium truncate">{patient.name}</h4>
                            {patient.unreadMessages > 0 && (
                              <span className="bg-cyan-500 text-white text-xs font-medium rounded-full h-5 w-5 flex items-center justify-center">
                                {patient.unreadMessages}
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-white/70 truncate">{patient.medicalCondition}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-white/60">
                  <MessageSquare className="h-8 w-8 mx-auto mb-3 text-white/30" />
                  <p>No patients found</p>
                  <p className="text-sm mt-1">Try adjusting your search</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Chat Area */}
        <div className="bg-white/5 rounded-lg border border-white/10 overflow-hidden md:col-span-2">
          {selectedPatient ? (
            <>
              <div className="p-3 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                    <User className="h-4 w-4 text-pink-500" />
                  </div>
                  <div>
                    <h3 className="font-medium">{selectedPatient.name}</h3>
                    <p className="text-xs text-white/70">{selectedPatient.contactNumber}</p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col h-[calc(600px-9rem)]">
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sender === "doctor" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-lg p-3 ${
                          message.sender === "doctor" ? "bg-cyan-500/20 text-white" : "bg-white/10 text-white"
                        }`}
                      >
                        <p className="text-sm">{message.text}</p>
                        <p className="text-xs text-white/60 mt-1 text-right">{message.timestamp}</p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>

                <div className="p-3 border-t border-white/10">
                  <div className="flex items-center gap-2">
                    <Button
                      size="icon"
                      variant="outline"
                      className="h-8 w-8 rounded-full border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                    >
                      <Paperclip className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="outline"
                      className="h-8 w-8 rounded-full border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                    >
                      <ImageIcon className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="outline"
                      className="h-8 w-8 rounded-full border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                    >
                      <File className="h-4 w-4" />
                    </Button>
                    <input
                      type="text"
                      placeholder="Type a message..."
                      className="flex-1 bg-white/10 border border-white/20 rounded-full px-4 py-2 text-sm text-white"
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault()
                          handleSendMessage()
                        }
                      }}
                    />
                    <Button
                      size="icon"
                      className="h-8 w-8 rounded-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                      onClick={handleSendMessage}
                      disabled={sendingMessage || !messageText.trim()}
                    >
                      {sendingMessage ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center py-12 text-white/60">
              <MessageSquare className="h-12 w-12 mx-auto mb-3 text-white/30" />
              <p>Select a patient to start messaging</p>
              <p className="text-sm mt-1">Your conversations will appear here</p>
            </div>
          )}
        </div>
      </div>
    </Card>
  )
}
