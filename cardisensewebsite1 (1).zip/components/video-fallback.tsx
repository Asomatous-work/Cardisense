"use client"

import { useState, useEffect } from "react"
import { Loader2 } from "lucide-react"

interface VideoFallbackProps {
  src: string
  fallbackImage?: string
}

export function VideoFallback({ src, fallbackImage }: VideoFallbackProps) {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  useEffect(() => {
    // Check if the video is accessible
    const checkVideo = async () => {
      try {
        const response = await fetch(src, { method: "HEAD" })
        if (!response.ok) {
          throw new Error(`Failed to load video: ${response.status}`)
        }
        setLoading(false)
      } catch (err) {
        console.error("Error checking video:", err)
        setError(true)
        setLoading(false)
      }
    }

    checkVideo()
  }, [src])

  if (loading) {
    return (
      <div className="flex items-center justify-center bg-slate-800/50 rounded-xl w-full aspect-video">
        <Loader2 className="h-12 w-12 animate-spin text-pink-500" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center bg-slate-800/50 rounded-xl w-full aspect-video p-4">
        <img
          src={fallbackImage || "/placeholder.svg?height=400&width=800"}
          alt="Video thumbnail"
          className="max-h-[80%] rounded-lg object-contain mb-4"
        />
        <p className="text-white/70 text-center">
          The video could not be loaded. Please check your connection and try again.
        </p>
      </div>
    )
  }

  return (
    <video className="w-full h-auto rounded-xl" playsInline autoPlay muted loop controls={false}>
      <source src={src} type="video/mp4" />
      Your browser does not support the video tag.
    </video>
  )
}
