"use client"

import { useRef, useEffect, useState } from "react"

interface VideoPlayerProps {
  src: string
  poster?: string
}

export function VideoPlayer({ src, poster }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)

  useEffect(() => {
    const videoElement = videoRef.current
    if (!videoElement) return

    // Set up event listeners
    const handleCanPlay = () => {
      // Try to play the video when it's ready
      videoElement
        .play()
        .then(() => setIsPlaying(true))
        .catch((error) => {
          console.error("Autoplay failed:", error)
          setIsPlaying(false)
        })
    }

    const handleEnded = () => {
      // Replay when video ends
      if (videoElement) {
        videoElement.currentTime = 0
        videoElement.play().catch((error) => console.error("Replay failed:", error))
      }
    }

    // Set autoplay attribute
    videoElement.autoplay = true
    videoElement.loop = true
    videoElement.muted = true // Muted videos are more likely to autoplay

    videoElement.addEventListener("canplaythrough", handleCanPlay)
    videoElement.addEventListener("ended", handleEnded)

    // Try to play immediately
    videoElement.play().catch((error) => console.error("Initial autoplay failed:", error))

    // Clean up
    return () => {
      if (videoElement) {
        videoElement.removeEventListener("canplaythrough", handleCanPlay)
        videoElement.removeEventListener("ended", handleEnded)
      }
    }
  }, [])

  const handlePlayPause = () => {
    if (!videoRef.current) return

    if (isPlaying) {
      videoRef.current.pause()
      setIsPlaying(false)
    } else {
      videoRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((error) => console.error("Play failed:", error))
    }
  }

  return (
    <div className="relative w-full max-w-4xl mx-auto rounded-xl overflow-hidden">
      <video
        ref={videoRef}
        className="w-full h-auto rounded-xl cursor-pointer"
        playsInline
        muted
        loop
        preload="auto"
        poster={poster}
        onClick={handlePlayPause}
      >
        <source src={src} type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {!isPlaying && (
        <div
          className="absolute inset-0 flex items-center justify-center bg-black/30 cursor-pointer"
          onClick={handlePlayPause}
        >
          <div className="w-16 h-16 rounded-full bg-pink-500/80 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" className="w-8 h-8">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </div>
      )}
    </div>
  )
}
