"use client"

import { useState, useEffect } from "react"
import { InstallButton } from "@/components/install-button"
import { useDeviceType } from "@/hooks/use-device-type"
import { isDevelopment } from "@/lib/utils/env-fallbacks"

export function SiteHeader() {
  const { deviceType } = useDeviceType()
  const [showInstallButton, setShowInstallButton] = useState(false)

  useEffect(() => {
    // Check if the app is running in standalone mode (installed)
    const isRunningStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as any).standalone ||
      document.referrer.includes("android-app://") ||
      window.navigator.userAgent.includes("wv") || // Android WebView
      window.navigator.userAgent.includes("CARDISENSE") // Custom APK user agent

    // Only show the install button if the app is not installed
    setShowInstallButton(!isRunningStandalone)

    // Only log in development mode
    if (isDevelopment) {
      console.log("SiteHeader - App installation status:", {
        deviceType,
        isRunningStandalone,
        mediaQuery: window.matchMedia("(display-mode: standalone)").matches,
        navigatorStandalone: (window.navigator as any).standalone,
        userAgent: window.navigator.userAgent,
      })
    }
  }, [deviceType])

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-slate-900/80 border-b border-white/10">
      <div className="container flex h-14 items-center justify-between px-4 sm:px-6">
        <div className="flex items-center space-x-2">
          <img src="/yoga_icon.png" alt="Cardisense Logo" className="h-8 w-8" />
          <span className="text-lg font-bold bg-gradient-to-r from-teal-500 to-emerald-600 text-transparent bg-clip-text">
            CARDISENSE
          </span>
        </div>
        {showInstallButton && <InstallButton />}
      </div>
    </header>
  )
}
