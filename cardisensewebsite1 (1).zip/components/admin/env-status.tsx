"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertCircle, CheckCircle, Copy, ExternalLink } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function EnvironmentStatus() {
  const [envStatus, setEnvStatus] = useState<{
    supabase: boolean
    email: boolean
    loading: boolean
  }>({
    supabase: false,
    email: false,
    loading: true,
  })
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    async function checkEnvStatus() {
      try {
        const response = await fetch("/api/env-status")
        const data = await response.json()
        setEnvStatus({
          supabase: data.supabase,
          email: data.email,
          loading: false,
        })
      } catch (error) {
        console.error("Error checking environment status:", error)
        setEnvStatus({
          supabase: false,
          email: false,
          loading: false,
        })
      }
    }

    checkEnvStatus()
  }, [])

  const envVarsTemplate = `# Supabase Configuration
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_supabase_anon_key
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# Email Configuration
EMAIL_PASSWORD=your_email_app_password

# Base URL (optional)
NEXT_PUBLIC_BASE_URL=https://your-deployment-url.vercel.app`

  const handleCopy = () => {
    navigator.clipboard.writeText(envVarsTemplate)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Environment Variables Status</span>
          {envStatus.loading ? (
            <Badge variant="outline" className="bg-slate-700 text-white">
              Checking...
            </Badge>
          ) : envStatus.supabase && envStatus.email ? (
            <Badge className="bg-green-500">All Set</Badge>
          ) : (
            <Badge variant="destructive">Missing Variables</Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {envStatus.loading ? (
          <div className="flex justify-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-pink-500"></div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center gap-2 p-3 rounded-md bg-white/5 border border-white/10">
                {envStatus.supabase ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-amber-500" />
                )}
                <div>
                  <h3 className="font-medium">Supabase Configuration</h3>
                  <p className="text-sm text-white/70">
                    {envStatus.supabase ? "Connected to Supabase" : "Missing Supabase environment variables"}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 p-3 rounded-md bg-white/5 border border-white/10">
                {envStatus.email ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-amber-500" />
                )}
                <div>
                  <h3 className="font-medium">Email Configuration</h3>
                  <p className="text-sm text-white/70">
                    {envStatus.email ? "Email service configured" : "Missing email environment variables"}
                  </p>
                </div>
              </div>
            </div>

            {(!envStatus.supabase || !envStatus.email) && (
              <Alert variant="destructive" className="bg-red-900/20 border-red-900/30">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Missing Environment Variables</AlertTitle>
                <AlertDescription>
                  Some required environment variables are missing. The application will run in demo mode with limited
                  functionality.
                </AlertDescription>
              </Alert>
            )}

            <div className="bg-slate-800 rounded-md p-4 border border-white/10">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">Required Environment Variables</h3>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-8 border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                  onClick={handleCopy}
                >
                  {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  <span className="ml-2">{copied ? "Copied!" : "Copy"}</span>
                </Button>
              </div>
              <pre className="text-xs overflow-x-auto p-2 bg-slate-900 rounded border border-white/10 text-white/70">
                {envVarsTemplate}
              </pre>
            </div>

            <div className="flex justify-between items-center">
              <p className="text-sm text-white/70">Add these variables to your Vercel project or local .env file.</p>
              <Button
                size="sm"
                variant="outline"
                className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                asChild
              >
                <a
                  href="https://vercel.com/docs/projects/environment-variables"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Vercel Docs
                </a>
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
