"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, Save, Check, AlertCircle, RefreshCw } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { getVideoUrl } from "@/lib/supabase/storage"

export function VideoManager() {
  const [videoUrl, setVideoUrl] = useState<string>("")
  const [customUrl, setCustomUrl] = useState<string>("")
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState(false)
  const [updateSuccess, setUpdateSuccess] = useState(false)
  const [updateError, setUpdateError] = useState<string | null>(null)

  useEffect(() => {
    fetchVideoUrl()
  }, [])

  const fetchVideoUrl = async () => {
    setLoading(true)
    try {
      const url = getVideoUrl("cardisense-intro.mp4")
      setVideoUrl(url)
      setCustomUrl(url)
    } catch (error) {
      console.error("Error fetching video URL:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleUpdateUrl = async () => {
    if (!customUrl) return

    setUpdating(true)
    setUpdateSuccess(false)
    setUpdateError(null)

    try {
      // Here you would typically update the URL in your database or config
      // For now, we'll just simulate a successful update
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setVideoUrl(customUrl)
      setUpdateSuccess(true)
    } catch (error) {
      console.error("Error updating video URL:", error)
      setUpdateError(error instanceof Error ? error.message : "An unknown error occurred")
    } finally {
      setUpdating(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto mt-6">
      <CardHeader>
        <CardTitle>Current Video</CardTitle>
        <CardDescription>View and update the current CARDISENSE intro video URL</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {loading ? (
            <div className="flex items-center justify-center py-4">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : (
            <>
              <div>
                <h3 className="text-sm font-medium mb-1">Current Video URL:</h3>
                <p className="text-xs break-all bg-muted p-2 rounded">{videoUrl}</p>
              </div>

              <div className="grid w-full max-w-sm items-center gap-1.5">
                <label htmlFor="customUrl" className="text-sm font-medium">
                  Custom Video URL:
                </label>
                <Input
                  id="customUrl"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  placeholder="Enter custom video URL"
                  disabled={updating}
                />
              </div>

              {updateError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{updateError}</AlertDescription>
                </Alert>
              )}

              {updateSuccess && (
                <Alert className="bg-green-500/10 text-green-500 border-green-500/20">
                  <Check className="h-4 w-4" />
                  <AlertTitle>Success</AlertTitle>
                  <AlertDescription>Video URL updated successfully!</AlertDescription>
                </Alert>
              )}
            </>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={fetchVideoUrl} disabled={loading || updating}>
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh
        </Button>
        <Button onClick={handleUpdateUrl} disabled={!customUrl || updating || loading}>
          {updating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Updating...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Update URL
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
