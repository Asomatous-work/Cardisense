"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Home, Star, ArrowLeft, DollarSign } from "lucide-react"

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const item = {
  hidden: { opacity: 0, y: 50 },
  show: { opacity: 1, y: 0, transition: { duration: 0.3 } },
}

export function MovableAppIcon() {
  const [isOpen, setIsOpen] = useState(false)

  const toggleMenu = () => {
    setIsOpen(!isOpen)
  }

  const handlePay = () => {
    const upiId = "7845512905@ptsbi"
    const amount = 200
    const name = "CARDISENSE"
    const transactionNote = "Monthly Subscription Fee"
    const upiLink = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(
      name,
    )}&am=${amount}&tn=${encodeURIComponent(transactionNote)}&cu=INR`

    window.location.href = upiLink
  }

  return (
    <div className="fixed top-4 left-4 z-50">
      <motion.button
        className="relative w-12 h-12 rounded-full bg-slate-800 border border-white/10 shadow-lg flex items-center justify-center cursor-pointer"
        onClick={toggleMenu}
        animate={{ rotate: isOpen ? 360 : 0 }}
        transition={{ duration: 0.5, ease: "easeInOut" }}
      >
        <img src="/icons/icon-72x72.png" alt="CARDISENSE" className="w-8 h-8" />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full bg-slate-800 border border-white/10 shadow-lg flex items-center justify-center"
            variants={container}
            initial="hidden"
            animate="show"
            exit="hidden"
          >
            <motion.div
              className="absolute top-4 left-4 rounded-full bg-white/5 p-2 hover:bg-white/10 cursor-pointer"
              variants={item}
              onClick={() => alert("Back button clicked")}
            >
              <ArrowLeft className="h-5 w-5 text-white" />
            </motion.div>
            <motion.div
              className="absolute top-4 right-4 rounded-full bg-white/5 p-2 hover:bg-white/10 cursor-pointer"
              variants={item}
              onClick={() => alert("Rating area clicked")}
            >
              <Star className="h-5 w-5 text-white" />
            </motion.div>
            <motion.div
              className="absolute bottom-4 left-4 rounded-full bg-white/5 p-2 hover:bg-white/10 cursor-pointer"
              variants={item}
              onClick={handlePay}
            >
              <DollarSign className="h-5 w-5 text-white" />
            </motion.div>
            <motion.div
              className="absolute bottom-4 right-4 rounded-full bg-white/5 p-2 hover:bg-white/10 cursor-pointer"
              variants={item}
              onClick={() => alert("Home button clicked")}
            >
              <Home className="h-5 w-5 text-white" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
