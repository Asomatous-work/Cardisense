"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { User, Stethoscope, Clock, CheckCircle2, AlertCircle, ExternalLink } from "lucide-react"
import type { Patient, Doctor } from "@/lib/supabase/server"
import { DeployUrlDialog } from "@/components/deploy-url-dialog"

export default function PortalData() {
  const router = useRouter()
  const [portalView, setPortalView] = useState<"patient" | "doctor">("patient")
  const [patients, setPatients] = useState<Patient[]>([])
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedUser, setSelectedUser] = useState<(Patient | Doctor) | null>(null)
  const [deployDialogOpen, setDeployDialogOpen] = useState(false)

  useEffect(() => {
    async function fetchData() {
      setLoading(true)
      setError(null)

      try {
        if (portalView === "patient") {
          const response = await fetch("/api/patients")
          if (!response.ok) throw new Error("Failed to fetch patients")
          const data = await response.json()
          setPatients(data)
        } else {
          const response = await fetch("/api/doctors")
          if (!response.ok) throw new Error("Failed to fetch doctors")
          const data = await response.json()
          setDoctors(data)
        }
      } catch (err) {
        console.error("Error fetching data:", err)
        // Don't set error state, as we'll be using mock data from the API
        if (portalView === "patient") {
          setPatients([])
        } else {
          setDoctors([])
        }
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [portalView])

  const handlePatientClick = (patient: Patient) => {
    // Navigate to the patient's dashboard
    router.push(`/dashboard/${encodeURIComponent(patient.name)}`)
  }

  const handleDoctorClick = (doctor: Doctor) => {
    // Navigate to the doctor's dashboard
    router.push(`/doctor-dashboard/${encodeURIComponent(doctor.name)}`)
  }

  const handleUserSelect = (user: Patient | Doctor) => {
    setSelectedUser(user)
  }

  const handleDeploy = () => {
    if (selectedUser) {
      setDeployDialogOpen(true)
    } else {
      alert("Please select a user first")
    }
  }

  return (
    <div className="flex flex-col items-center w-full">
      {/* Portal Switch */}
      <div className="bg-slate-800/80 backdrop-blur-md border border-white/10 rounded-full p-1 flex w-64 mb-6">
        <button
          className={`flex-1 py-2 px-4 rounded-full flex items-center justify-center gap-2 transition-all duration-300 ${
            portalView === "patient"
              ? "bg-gradient-to-r from-pink-600 to-purple-600 text-white"
              : "text-white/60 hover:text-white"
          }`}
          onClick={() => setPortalView("patient")}
        >
          <User className="h-4 w-4" />
          <span className="text-sm">Patient</span>
        </button>
        <button
          className={`flex-1 py-2 px-4 rounded-full flex items-center justify-center gap-2 transition-all duration-300 ${
            portalView === "doctor"
              ? "bg-gradient-to-r from-pink-600 to-purple-600 text-white"
              : "text-white/60 hover:text-white"
          }`}
          onClick={() => setPortalView("doctor")}
        >
          <Stethoscope className="h-4 w-4" />
          <span className="text-sm">Doctor</span>
        </button>
      </div>

      {/* Portal Content */}
      <div className="w-full max-w-4xl bg-slate-800/50 backdrop-blur-md border border-white/10 rounded-xl p-4 overflow-hidden">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium">{portalView === "patient" ? "Active Patients" : "Available Doctors"}</h3>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-white/60 text-sm">
              <Clock className="h-4 w-4" />
              <span>Demo Data</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white flex items-center gap-1"
              onClick={handleDeploy}
            >
              <ExternalLink className="h-3.5 w-3.5" />
              <span>Deploy</span>
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-pink-500"></div>
          </div>
        ) : error ? (
          <div className="text-center py-8 text-red-400">
            <AlertCircle className="h-8 w-8 mx-auto mb-2" />
            <p>{error}</p>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            {portalView === "patient" ? (
              <motion.div
                key="patients"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
              >
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {patients.length > 0 ? (
                    patients.map((patient) => (
                      <div
                        key={patient.id}
                        className={`bg-white/10 rounded-lg p-3 border ${
                          selectedUser?.id === patient.id ? "border-pink-500" : "border-white/10"
                        } flex items-start gap-3 cursor-pointer hover:border-pink-500/50 transition-colors`}
                        onClick={() => handleUserSelect(patient)}
                        onDoubleClick={() => handlePatientClick(patient)}
                      >
                        <div
                          className={`rounded-full p-2 ${patient.status === "active" ? "bg-green-500/20" : "bg-amber-500/20"}`}
                        >
                          <User
                            className={`h-5 w-5 ${patient.status === "active" ? "text-green-500" : "text-amber-500"}`}
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-white">{patient.name}</h4>
                          <p className="text-sm text-white/70">ID: {patient.patient_id}</p>
                          <div className="flex items-center gap-1 mt-1">
                            {patient.status === "active" ? (
                              <CheckCircle2 className="h-3 w-3 text-green-500" />
                            ) : (
                              <AlertCircle className="h-3 w-3 text-amber-500" />
                            )}
                            <span
                              className={`text-xs ${patient.status === "active" ? "text-green-500" : "text-amber-500"}`}
                            >
                              {patient.status === "active" ? "Active" : "Pending"}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="col-span-3 text-center py-8 text-white/60">
                      <User className="h-12 w-12 mx-auto mb-3 text-white/30" />
                      <p>No patients found</p>
                      <p className="text-sm mt-1">Demo mode active - using sample data</p>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="doctors"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
              >
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {doctors.length > 0 ? (
                    doctors.map((doctor) => (
                      <div
                        key={doctor.id}
                        className={`bg-white/10 rounded-lg p-3 border ${
                          selectedUser?.id === doctor.id ? "border-cyan-500" : "border-white/10"
                        } flex items-start gap-3 cursor-pointer hover:border-cyan-500/50 transition-colors`}
                        onClick={() => handleUserSelect(doctor)}
                        onDoubleClick={() => handleDoctorClick(doctor)}
                      >
                        <div className={`rounded-full p-2 ${doctor.available ? "bg-green-500/20" : "bg-slate-500/20"}`}>
                          <Stethoscope
                            className={`h-5 w-5 ${doctor.available ? "text-green-500" : "text-slate-500"}`}
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-white">Dr. {doctor.name}</h4>
                          <p className="text-sm text-white/70">{doctor.specialty}</p>
                          <div className="flex items-center gap-1 mt-1">
                            {doctor.available ? (
                              <CheckCircle2 className="h-3 w-3 text-green-500" />
                            ) : (
                              <Clock className="h-3 w-3 text-slate-500" />
                            )}
                            <span className={`text-xs ${doctor.available ? "text-green-500" : "text-slate-500"}`}>
                              {doctor.available ? "Available" : "In appointment"}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="col-span-3 text-center py-8 text-white/60">
                      <Stethoscope className="h-12 w-12 mx-auto mb-3 text-white/30" />
                      <p>No doctors found</p>
                      <p className="text-sm mt-1">Demo mode active - using sample data</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        )}

        <div className="mt-4 flex justify-between items-center">
          <p className="text-xs text-white/60">
            {selectedUser ? (
              <>
                Selected:{" "}
                <span className="text-white">
                  {portalView === "doctor" ? "Dr. " : ""}
                  {selectedUser.name}
                </span>
              </>
            ) : (
              "Click to select a user, double-click to view dashboard"
            )}
          </p>
          <Button
            variant="outline"
            size="sm"
            className="text-xs border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
          >
            View All {portalView === "patient" ? "Patients" : "Doctors"}
          </Button>
        </div>
      </div>

      {/* Deploy URL Dialog */}
      <DeployUrlDialog
        open={deployDialogOpen}
        onOpenChange={setDeployDialogOpen}
        selectedUser={selectedUser}
        userType={portalView}
      />
    </div>
  )
}
