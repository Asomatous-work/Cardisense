import { VideoUploader } from "@/components/admin/video-uploader"
import { VideoManager } from "@/components/admin/video-manager"

export default function AdminVideosPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-2xl font-bold mb-6">Video Management</h1>
      <div className="grid gap-8 md:grid-cols-2">
        <div>
          <h2 className="text-xl font-semibold mb-4">Upload New Video</h2>
          <VideoUploader />
        </div>
        <div>
          <h2 className="text-xl font-semibold mb-4">Manage Current Video</h2>
          <VideoManager />
        </div>
      </div>
    </div>
  )
}
