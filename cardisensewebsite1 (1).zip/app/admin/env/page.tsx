import { EnvironmentStatus } from "@/components/admin/env-status"

export default function EnvironmentPage() {
  return (
    <div className="container mx-auto py-10">
      <h1 className="text-2xl font-bold mb-6">Environment Configuration</h1>
      <div className="max-w-3xl mx-auto">
        <EnvironmentStatus />
      </div>
    </div>
  )
}
