import type React from "react"
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "CardisenseWebsite",
  description: "Your health companion",
  generator: "v0.dev",
  icons: {
    icon: "/yoga_icon.png",
    apple: "/yoga_icon.png",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-slate-900">
      <body className="bg-slate-900 min-h-screen">{children}</body>
    </html>
  )
}
