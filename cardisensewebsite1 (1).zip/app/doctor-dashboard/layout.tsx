import type React from "react"
import type { Metadata } from "next"
import FloatingNav from "@/components/floating-nav"

export const metadata: Metadata = {
  title: "CARDISENSE - Doctor Dashboard",
  description: "Manage your patients, appointments, and medical practice",
}

export default function DoctorDashboardLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: { doctorName?: string[] }
}) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      <main className="w-full overflow-y-auto p-3 sm:p-5 md:p-6">{children}</main>
      <FloatingNav type="doctor" />
    </div>
  )
}
