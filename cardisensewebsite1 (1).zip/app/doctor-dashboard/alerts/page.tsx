import { PatientAlerts } from "@/components/dashboard/patient-alerts"

export default function AlertsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Patient Alerts</h1>
      <p className="text-white/70 mb-6">Monitor and respond to urgent patient messages and health alerts</p>
      <PatientAlerts />
    </div>
  )
}
