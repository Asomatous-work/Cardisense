"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, Search, RefreshCw, Heart, Activity, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Input } from "@/components/ui/input"
import { createClientSupabaseClient } from "@/lib/supabase/client"

export default function PatientsPage() {
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [filter, setFilter] = useState("all")
  const [patients, setPatients] = useState<any[]>([])

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      const supabase = createClientSupabaseClient()

      // Fetch real data from Supabase
      const { data, error } = await supabase.from("patients").select("*")

      if (error) {
        console.error("Error fetching patients:", error)
        toast({
          title: "Error",
          description: "Failed to fetch patients. Please try again.",
          variant: "destructive",
        })
        setPatients([])
      } else {
        // Transform the data to match our expected format
        const formattedData = data.map((patient) => ({
          id: patient.id,
          name: patient.name || "Unknown",
          age: patient.age || 30,
          gender: patient.gender || "Not specified",
          contactNumber: patient.contact_number || "No contact",
          lastVisit: patient.last_visit ? new Date(patient.last_visit).toLocaleDateString() : "Never",
          nextAppointment: patient.next_appointment
            ? new Date(patient.next_appointment).toLocaleDateString()
            : "Not scheduled",
          status: patient.status || "active",
          medicalCondition: patient.medical_condition || "No condition specified",
          vitalSigns: {
            bloodPressure: patient.blood_pressure || "120/80",
            heartRate: patient.heart_rate || "75",
            temperature: patient.temperature || "98.6°F",
            oxygenSaturation: patient.oxygen_saturation || "98%",
          },
        }))
        setPatients(formattedData)
      }
    } catch (error) {
      console.error("Error in fetchData:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
      setPatients([])
    } finally {
      setLoading(false)
    }
  }

  const handleRefresh = () => {
    fetchData()
    toast({
      title: "Patient List Refreshed",
      description: "Patient data has been updated with the latest information.",
      variant: "default",
    })
  }

  // Filter patients based on search query and filter
  const filteredPatients = patients.filter((patient) => {
    const matchesSearch =
      patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (patient.medicalCondition && patient.medicalCondition.toLowerCase().includes(searchQuery.toLowerCase()))

    if (filter === "all") return matchesSearch
    if (filter === "active") return matchesSearch && patient.status === "active"
    if (filter === "new") return matchesSearch && patient.status === "new"
    if (filter === "critical") return matchesSearch && patient.status === "critical"

    return matchesSearch
  })

  return (
    <div className="space-y-6 p-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl md:text-3xl font-bold">Patients</h1>
        <Button
          variant="outline"
          size="icon"
          onClick={handleRefresh}
          className="h-10 w-10 rounded-full border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
          disabled={loading}
        >
          <RefreshCw className={`h-5 w-5 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>
      <p className="text-white/70 mb-4">Manage and monitor your patients</p>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-white/40" />
          <Input
            type="text"
            placeholder="Search patients..."
            className="pl-9 bg-white/10 border-white/20 text-white"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <select
          className="bg-white/10 border border-white/20 rounded-md px-3 py-2 text-white"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option value="all">All Patients</option>
          <option value="active">Active Patients</option>
          <option value="new">New Patients</option>
          <option value="critical">Critical Patients</option>
        </select>
      </div>

      {/* Patients List */}
      <Card className="bg-white/5 border-white/10 p-4 md:p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Users className="h-5 w-5 text-cyan-500" />
            <span>Patient List</span>
            {loading ? (
              <span className="bg-slate-500/50 text-white text-xs font-bold px-2 py-0.5 rounded-full ml-2">
                Updating...
              </span>
            ) : (
              <span className="bg-green-500/20 text-green-400 text-xs font-bold px-2 py-0.5 rounded-full ml-2">
                {filteredPatients.length} Patients
              </span>
            )}
          </h2>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-cyan-500" />
          </div>
        ) : filteredPatients.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredPatients.map((patient) => (
              <Card key={patient.id} className="bg-white/10 border-white/10 p-4 hover:bg-white/15 transition-colors">
                <div className="flex flex-col gap-4">
                  {/* Patient header */}
                  <div className="flex items-start gap-3">
                    <div
                      className={`h-12 w-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                        patient.status === "critical"
                          ? "bg-red-500/20"
                          : patient.status === "new"
                            ? "bg-blue-500/20"
                            : "bg-green-500/20"
                      }`}
                    >
                      <Users
                        className={`h-6 w-6 ${
                          patient.status === "critical"
                            ? "text-red-500"
                            : patient.status === "new"
                              ? "text-blue-500"
                              : "text-green-500"
                        }`}
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-medium text-lg">{patient.name}</h3>
                        <span
                          className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            patient.status === "critical"
                              ? "bg-red-500/20 text-red-400"
                              : patient.status === "new"
                                ? "bg-blue-500/20 text-blue-400"
                                : "bg-green-500/20 text-green-400"
                          }`}
                        >
                          {patient.status === "critical"
                            ? "Critical"
                            : patient.status === "new"
                              ? "New Patient"
                              : "Active"}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1">
                        <p className="text-sm text-white/70">
                          {patient.age} years, {patient.gender}
                        </p>
                        <p className="text-sm text-white/70">{patient.contactNumber}</p>
                      </div>
                    </div>
                  </div>

                  {/* Patient details */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm font-medium text-white/80 mb-2 flex items-center gap-1">
                        <Activity className="h-4 w-4 text-cyan-500" />
                        Medical Information
                      </h4>
                      <p className="text-sm text-white/70 mb-1">
                        <span className="text-white/50">Condition:</span> {patient.medicalCondition}
                      </p>
                      <p className="text-sm text-white/70 mb-1">
                        <span className="text-white/50">Last Visit:</span> {patient.lastVisit}
                      </p>
                      <p className="text-sm text-white/70">
                        <span className="text-white/50">Next Appointment:</span> {patient.nextAppointment}
                      </p>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-white/80 mb-2 flex items-center gap-1">
                        <Heart className="h-4 w-4 text-pink-500" />
                        Vital Signs
                      </h4>
                      <div className="grid grid-cols-2 gap-2">
                        <p className="text-sm text-white/70">
                          <span className="text-white/50">BP:</span> {patient.vitalSigns.bloodPressure}
                        </p>
                        <p className="text-sm text-white/70">
                          <span className="text-white/50">HR:</span> {patient.vitalSigns.heartRate} bpm
                        </p>
                        <p className="text-sm text-white/70">
                          <span className="text-white/50">Temp:</span> {patient.vitalSigns.temperature}
                        </p>
                        <p className="text-sm text-white/70">
                          <span className="text-white/50">O₂:</span> {patient.vitalSigns.oxygenSaturation}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="flex flex-wrap gap-2 mt-2">
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                    >
                      View Profile
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                    >
                      Schedule Appointment
                    </Button>
                    {patient.status === "critical" && (
                      <Button
                        size="sm"
                        className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400"
                      >
                        Urgent Care
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-white/60 bg-white/5 rounded-lg border border-white/10">
            <Users className="h-16 w-16 mx-auto mb-4 text-white/30" />
            <h3 className="text-xl font-medium mb-2">No Patients Found</h3>
            <p className="text-white/60 mb-6">
              {searchQuery
                ? "No patients match your search criteria"
                : "There are no patients in the selected category"}
            </p>
            <Button
              onClick={() => {
                setSearchQuery("")
                setFilter("all")
              }}
              className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
            >
              View All Patients
            </Button>
          </div>
        )}
      </Card>
    </div>
  )
}
