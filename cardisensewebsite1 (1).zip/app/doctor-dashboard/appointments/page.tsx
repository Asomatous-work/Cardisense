"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Calendar, Clock, Users, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Loader2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export default function DoctorAppointmentsPage() {
  const [appointments, setAppointments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [filter, setFilter] = useState("all")

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()

        // Fetch appointment requests from Supabase
        const { data: appointmentsData, error: appointmentsError } = await supabase
          .from("appointments")
          .select(`
           id, 
           type,
           appointment_date,
           appointment_time,
           notes,
           status,
           is_urgent,
           patient_id
         `)
          .order("appointment_date", { ascending: true })

        if (appointmentsError) {
          console.error("Error fetching appointments:", appointmentsError)
          toast({
            title: "Error",
            description: "Failed to fetch appointments. Using demo data instead.",
            variant: "destructive",
          })
          setAppointments(getSampleAppointments())
          return
        }

        // Fetch patient data
        const { data: patientsData, error: patientsError } = await supabase.from("patients").select("id, name")

        if (patientsError) {
          console.error("Error fetching patients:", patientsError)
          toast({
            title: "Error",
            description: "Failed to fetch patients. Using demo data instead.",
            variant: "destructive",
          })
          setAppointments(getSampleAppointments())
          return
        }

        // Create a map of patient data for easy lookup
        const patientsMap = new Map(patientsData.map((patient) => [patient.id, patient.name]))

        // Transform the data to match our component's expected format
        const formattedData = (appointmentsData || []).map((appointment) => ({
          id: appointment.id,
          patient: patientsMap.get(appointment.patient_id) || "Unknown Patient",
          type: appointment.type,
          date: appointment.appointment_date ? new Date(appointment.appointment_date).toLocaleDateString() : "No date",
          time: appointment.appointment_time,
          status: appointment.status,
          notes: appointment.notes,
          isUrgent: appointment.is_urgent,
        }))

        setAppointments(formattedData)
      } catch (error) {
        console.error("Error fetching appointments:", error)
        toast({
          title: "Error",
          description: "An unexpected error occurred. Using demo data instead.",
          variant: "destructive",
        })
        setAppointments(getSampleAppointments())
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const getSampleAppointments = () => {
    return [
      {
        id: 1,
        patient: "Rajesh Kumar",
        type: "Cardiology Checkup",
        date: "Apr 15, 2025",
        time: "10:30 AM",
        status: "pending",
        notes: "First-time patient, complaining of occasional chest pain",
        isUrgent: false,
      },
      {
        id: 2,
        patient: "Priya Sharma",
        type: "Follow-up Consultation",
        date: "Apr 16, 2025",
        time: "2:00 PM",
        status: "pending",
        notes: "Follow-up after medication change, needs to discuss side effects",
        isUrgent: false,
      },
      {
        id: 3,
        patient: "Suresh Patel",
        type: "Emergency Consultation",
        date: "Apr 14, 2025",
        time: "4:15 PM",
        status: "urgent",
        notes: "Experiencing severe chest pain and shortness of breath",
        isUrgent: true,
      },
    ]
  }

  const filteredAppointments = appointments.filter((appointment) => {
    const matchesSearch =
      appointment.patient.toLowerCase().includes(searchQuery.toLowerCase()) ||
      appointment.type.toLowerCase().includes(searchQuery.toLowerCase())

    if (filter === "all") return matchesSearch
    if (filter === "urgent") return matchesSearch && appointment.status === "urgent"
    if (filter === "pending") return matchesSearch && appointment.status === "pending"

    return matchesSearch
  })

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Appointment Management</h1>
      <p className="text-white/70 mb-6">Manage and respond to appointment requests from your patients</p>

      <Card className="bg-white/5 border-white/10 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Calendar className="h-5 w-5 text-cyan-500" />
            <span>Appointment Requests</span>
          </h2>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40" />
              <input
                type="text"
                placeholder="Search patients..."
                className="bg-white/10 border border-white/20 rounded-md pl-9 pr-4 py-1 text-sm text-white w-48"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <select
              className="bg-white/10 border border-white/20 rounded-md px-3 py-1 text-sm text-white"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option value="all">All Requests</option>
              <option value="urgent">Urgent Only</option>
              <option value="pending">Pending Only</option>
            </select>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-10 w-10 animate-spin text-cyan-500" />
          </div>
        ) : (
          <div className="space-y-4">
            {filteredAppointments.length > 0 ? (
              filteredAppointments.map((appointment) => (
                <div
                  key={appointment.id}
                  className={`bg-white/10 rounded-lg p-4 border ${
                    appointment.status === "urgent" ? "border-red-500/30" : "border-white/10"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex gap-3">
                      <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                        <Users className="h-5 w-5 text-pink-500" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium">{appointment.patient}</h3>
                          {appointment.status === "urgent" && (
                            <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-xs font-medium">
                              Urgent
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-white/70">{appointment.type}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3 text-white/60" />
                            <span className="text-xs text-white/60">{appointment.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3 text-white/60" />
                            <span className="text-xs text-white/60">{appointment.time}</span>
                          </div>
                        </div>
                        <p className="text-xs text-white/60 mt-2">{appointment.notes}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        className={`h-8 ${
                          appointment.status === "urgent"
                            ? "bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400"
                            : "bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                        }`}
                      >
                        Accept
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                      >
                        Decline
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-white/60">
                <Calendar className="h-12 w-12 mx-auto mb-3 text-white/30" />
                <p>No appointment requests found</p>
                <p className="text-sm mt-1">Try adjusting your search or filters</p>
              </div>
            )}
          </div>
        )}
      </Card>
    </div>
  )
}
