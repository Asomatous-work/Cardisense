"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Calendar, Bell, DollarSign, Users, Clock, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DoctorStats } from "@/components/dashboard/doctor-stats"

export default function DoctorDashboardPage({
  params,
}: {
  params: { doctorName?: string[] }
}) {
  const searchParams = useSearchParams()
  const accessToken = searchParams.get("access_token")
  const expires = searchParams.get("expires")

  const [isValidAccess, setIsValidAccess] = useState(false)

  const doctorName =
    params.doctorName && params.doctorName.length > 0 ? decodeURIComponent(params.doctorName[0]) : "KIRUPA D"
  // Note: This already has decodeURIComponent, but let's make sure it's working correctly

  useEffect(() => {
    // In a real app, you would validate the token with your backend
    // For this demo, we'll just check if it exists
    if (accessToken) {
      setIsValidAccess(true)
    } else {
      // For demo purposes, we'll still show the dashboard
      // In a real app, you might redirect to a login page
      setIsValidAccess(true)
    }
  }, [accessToken])

  if (!isValidAccess) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="bg-white/5 border-white/10 p-6 max-w-md">
          <div className="text-center">
            <AlertCircle className="h-12 w-12 mx-auto mb-4 text-red-500" />
            <h2 className="text-xl font-bold mb-2">Access Denied</h2>
            <p className="text-white/70 mb-4">Invalid or expired access token. Please request a new access link.</p>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dr. {doctorName}'s Dashboard</h1>
          <p className="text-white/60">
            {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
            {expires && <span className="ml-2 text-amber-400 text-sm">(Temporary access expires in {expires})</span>}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Bell className="h-6 w-6 text-white/70 hover:text-white cursor-pointer" />
            <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
              3
            </span>
          </div>
          <div className="h-10 w-10 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 flex items-center justify-center">
            <span className="text-sm font-bold text-white">
              {doctorName
                .split(" ")
                .map((name) => name[0])
                .join("")}
            </span>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <DoctorStats />

      {/* Recent Activity */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Appointment Requests */}
        <Card className="bg-white/5 border-white/10 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Calendar className="h-5 w-5 text-cyan-500" />
              <span>Recent Appointment Requests</span>
            </h2>
            <Button
              variant="outline"
              size="sm"
              className="text-xs border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            >
              View All
            </Button>
          </div>
          <div className="space-y-3">
            <div className="bg-white/10 rounded-lg p-4 border border-white/10">
              <div className="flex items-start justify-between">
                <div className="flex gap-3">
                  <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                    <Users className="h-5 w-5 text-pink-500" />
                  </div>
                  <div>
                    <h3 className="font-medium">Rajesh Kumar</h3>
                    <p className="text-sm text-white/70">Cardiology Checkup</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Clock className="h-3 w-3 text-white/60" />
                      <span className="text-xs text-white/60">Today, 2:30 PM</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="h-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                  >
                    Accept
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                  >
                    Decline
                  </Button>
                </div>
              </div>
            </div>
            <div className="bg-white/10 rounded-lg p-4 border border-white/10">
              <div className="flex items-start justify-between">
                <div className="flex gap-3">
                  <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                    <Users className="h-5 w-5 text-pink-500" />
                  </div>
                  <div>
                    <h3 className="font-medium">Priya Sharma</h3>
                    <p className="text-sm text-white/70">Follow-up Consultation</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Clock className="h-3 w-3 text-white/60" />
                      <span className="text-xs text-white/60">Tomorrow, 10:00 AM</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="h-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                  >
                    Accept
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                  >
                    Decline
                  </Button>
                </div>
              </div>
            </div>
          </div>
          <Button
            className="w-full mt-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
            size="sm"
          >
            Manage All Appointments
          </Button>
        </Card>

        {/* Patient Alerts */}
        <Card className="bg-white/5 border-white/10 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Bell className="h-5 w-5 text-cyan-500" />
              <span>Recent Patient Alerts</span>
            </h2>
            <Button
              variant="outline"
              size="sm"
              className="text-xs border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            >
              View All
            </Button>
          </div>
          <div className="space-y-3">
            <div className="bg-white/10 rounded-lg p-4 border border-red-500/30">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium">Suresh Patel</h3>
                    <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-xs font-medium">
                      Urgent
                    </span>
                  </div>
                  <p className="text-sm text-white/70">
                    "I'm experiencing severe chest pain and shortness of breath..."
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <Clock className="h-3 w-3 text-white/60" />
                    <span className="text-xs text-white/60">10 minutes ago</span>
                  </div>
                  <Button
                    size="sm"
                    className="mt-2 h-8 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400"
                  >
                    Respond Now
                  </Button>
                </div>
              </div>
            </div>
            <div className="bg-white/10 rounded-lg p-4 border border-amber-500/30">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-amber-500" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium">Ananya Desai</h3>
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-xs font-medium">
                      Moderate
                    </span>
                  </div>
                  <p className="text-sm text-white/70">
                    "My blood pressure reading is showing 150/95. Should I be concerned?"
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <Clock className="h-3 w-3 text-white/60" />
                    <span className="text-xs text-white/60">1 hour ago</span>
                  </div>
                  <Button
                    size="sm"
                    className="mt-2 h-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                  >
                    Respond
                  </Button>
                </div>
              </div>
            </div>
          </div>
          <Button
            className="w-full mt-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
            size="sm"
          >
            View All Alerts
          </Button>
        </Card>
      </div>

      {/* Payment Management Preview */}
      <Card className="bg-white/5 border-white/10 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-cyan-500" />
            <span>Payment Management</span>
          </h2>
          <div className="flex items-center gap-3">
            <select className="bg-white/10 border border-white/20 rounded-md px-3 py-1 text-sm text-white">
              <option>This Month</option>
              <option>Last Month</option>
              <option>Last 3 Months</option>
            </select>
            <Button
              variant="outline"
              size="sm"
              className="text-xs border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            >
              View All
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="bg-gradient-to-br from-cyan-900/50 to-blue-900/50 border-white/10 p-4">
            <h3 className="text-sm text-white/70 mb-1">Total Earnings</h3>
            <p className="text-2xl font-bold">₹45,250</p>
            <div className="flex items-center gap-1 mt-1 text-green-400 text-xs">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m18 15-6-6-6 6" />
              </svg>
              <span>12% from last month</span>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-900/50 to-blue-900/50 border-white/10 p-4">
            <h3 className="text-sm text-white/70 mb-1">Pending Payments</h3>
            <p className="text-2xl font-bold">₹12,800</p>
            <div className="flex items-center gap-1 mt-1 text-amber-400 text-xs">
              <span>5 payment requests</span>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-900/50 to-blue-900/50 border-white/10 p-4">
            <h3 className="text-sm text-white/70 mb-1">Completed Appointments</h3>
            <p className="text-2xl font-bold">32</p>
            <div className="flex items-center gap-1 mt-1 text-green-400 text-xs">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m18 15-6-6-6 6" />
              </svg>
              <span>8% from last month</span>
            </div>
          </Card>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-3 px-4 text-white/70 font-medium">Patient</th>
                <th className="text-left py-3 px-4 text-white/70 font-medium">Service</th>
                <th className="text-left py-3 px-4 text-white/70 font-medium">Date</th>
                <th className="text-left py-3 px-4 text-white/70 font-medium">Amount</th>
                <th className="text-left py-3 px-4 text-white/70 font-medium">Status</th>
                <th className="text-left py-3 px-4 text-white/70 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-white/5 hover:bg-white/5">
                <td className="py-3 px-4">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-pink-500/20 flex items-center justify-center">
                      <Users className="h-4 w-4 text-pink-500" />
                    </div>
                    <span>Rajesh Kumar</span>
                  </div>
                </td>
                <td className="py-3 px-4">Cardiology Checkup</td>
                <td className="py-3 px-4">Apr 12, 2025</td>
                <td className="py-3 px-4 font-medium">₹1,500</td>
                <td className="py-3 px-4">
                  <span className="px-2 py-1 rounded-full bg-green-500/20 text-green-400 text-xs font-medium">
                    Paid
                  </span>
                </td>
                <td className="py-3 px-4">
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 text-xs border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                  >
                    View
                  </Button>
                </td>
              </tr>
              <tr className="border-b border-white/5 hover:bg-white/5">
                <td className="py-3 px-4">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-pink-500/20 flex items-center justify-center">
                      <Users className="h-4 w-4 text-pink-500" />
                    </div>
                    <span>Priya Sharma</span>
                  </div>
                </td>
                <td className="py-3 px-4">Follow-up Consultation</td>
                <td className="py-3 px-4">Apr 10, 2025</td>
                <td className="py-3 px-4 font-medium">₹800</td>
                <td className="py-3 px-4">
                  <span className="px-2 py-1 rounded-full bg-amber-500/20 text-amber-400 text-xs font-medium">
                    Pending
                  </span>
                </td>
                <td className="py-3 px-4">
                  <Button
                    size="sm"
                    className="h-7 text-xs bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                  >
                    Request
                  </Button>
                </td>
              </tr>
              <tr className="hover:bg-white/5">
                <td className="py-3 px-4">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-pink-500/20 flex items-center justify-center">
                      <Users className="h-4 w-4 text-pink-500" />
                    </div>
                    <span>Suresh Patel</span>
                  </div>
                </td>
                <td className="py-3 px-4">Emergency Consultation</td>
                <td className="py-3 px-4">Apr 8, 2025</td>
                <td className="py-3 px-4 font-medium">₹2,500</td>
                <td className="py-3 px-4">
                  <span className="px-2 py-1 rounded-full bg-amber-500/20 text-amber-400 text-xs font-medium">
                    Pending
                  </span>
                </td>
                <td className="py-3 px-4">
                  <Button
                    size="sm"
                    className="h-7 text-xs bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                  >
                    Request
                  </Button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
