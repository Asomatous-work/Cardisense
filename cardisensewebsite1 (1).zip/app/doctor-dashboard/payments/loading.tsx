import { Skeleton } from "@/components/ui/skeleton"

export default function PaymentsLoading() {
  return (
    <div className="container mx-auto p-6 space-y-8">
      <Skeleton className="h-10 w-[250px]" />
      <Skeleton className="h-5 w-[450px]" />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {Array(4)
          .fill(0)
          .map((_, i) => (
            <Skeleton key={i} className="h-[125px] w-full" />
          ))}
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Skeleton className="h-10 w-[300px]" />
          <Skeleton className="h-10 w-[150px]" />
        </div>

        <Skeleton className="h-[400px] w-full" />
      </div>

      <Skeleton className="h-10 w-[200px]" />
    </div>
  )
}
