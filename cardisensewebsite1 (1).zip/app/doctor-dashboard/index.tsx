"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Calendar, Bell, Users, Clock, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DoctorStats } from "@/components/dashboard/doctor-stats"
import { useToast } from "@/hooks/use-toast"
import { usePathname } from "next/navigation"
import { createClientSupabaseClient } from "@/lib/supabase/client"

export default function DoctorDashboardPage({ params }: { params: { doctorName?: string[] } }) {
  const { toast } = useToast()
  const pathname = usePathname()
  const [loading, setLoading] = useState(true)
  const [activePatients, setActivePatients] = useState<any[]>([])
  const [pendingAppointments, setPendingAppointments] = useState<any[]>([])
  const [completedAppointments, setCompletedAppointments] = useState<any[]>([])

  // Extract doctor name from URL or use default
  const doctorName =
    params?.doctorName && params.doctorName.length > 0
      ? decodeURIComponent(params.doctorName[0])
      : pathname.includes("/doctor-dashboard/")
        ? pathname.split("/doctor-dashboard/")[1]?.split("/")[0] || "KIRUPA D"
        : "KIRUPA D"

  // Fetch real-time data from the server
  useEffect(() => {
    fetchData()

    // Set up real-time subscription
    const supabase = createClientSupabaseClient()

    // Subscribe to changes in patients table
    const patientsSubscription = supabase
      .channel("patients-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "patients",
        },
        () => {
          fetchData()
        },
      )
      .subscribe()

    // Subscribe to changes in appointments table
    const appointmentsSubscription = supabase
      .channel("appointments-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "appointments",
        },
        () => {
          fetchData()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(patientsSubscription)
      supabase.removeChannel(appointmentsSubscription)
    }
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      const supabase = createClientSupabaseClient()

      // Fetch active patients (those who are currently present)
      const { data: activeData, error: activeError } = await supabase
        .from("patients")
        .select("id, name, status, appointment_time, contact_number, last_visit, medical_condition")
        .eq("is_present", true)
        .order("appointment_time", { ascending: true })

      if (activeError) {
        console.error("Error fetching active patients:", activeError)
        setActivePatients([])
      } else {
        setActivePatients(activeData || [])
      }

      // Fetch pending appointment requests
      const { data: pendingData, error: pendingError } = await supabase
        .from("appointments")
        .select(`
          id, 
          type,
          appointment_date,
          appointment_time,
          notes,
          status,
          is_urgent,
          patients (id, name, contact_number)
        `)
        .in("status", ["pending", "urgent"])
        .order("is_urgent", { ascending: false })
        .order("appointment_date", { ascending: true })

      if (pendingError) {
        console.error("Error fetching pending appointments:", pendingError)
        setPendingAppointments([])
      } else {
        // Transform the data to match our component's expected format
        const formattedPendingData = (pendingData || []).map((appointment) => ({
          id: appointment.id,
          patient: appointment.patients?.name || "Unknown Patient",
          patientId: appointment.patients?.id,
          type: appointment.type,
          date: new Date(appointment.appointment_date).toLocaleDateString(),
          time: appointment.appointment_time,
          status: appointment.status,
          notes: appointment.notes,
          contactNumber: appointment.patients?.contact_number,
          isUrgent: appointment.is_urgent,
        }))

        setPendingAppointments(formattedPendingData)
      }

      // Fetch completed appointments
      const { data: completedData, error: completedError } = await supabase
        .from("appointments")
        .select(`
          id, 
          type,
          appointment_date,
          appointment_time,
          notes,
          status,
          payment_status,
          patients (id, name, contact_number)
        `)
        .eq("status", "completed")
        .order("appointment_date", { ascending: false })
        .limit(5)

      if (completedError) {
        console.error("Error fetching completed appointments:", completedError)
        setCompletedAppointments([])
      } else {
        // Transform the data to match our component's expected format
        const formattedCompletedData = (completedData || []).map((appointment) => ({
          id: appointment.id,
          patient: appointment.patients?.name || "Unknown Patient",
          patientId: appointment.patients?.id,
          type: appointment.type,
          date: new Date(appointment.appointment_date).toLocaleDateString(),
          time: appointment.appointment_time,
          status: "completed",
          notes: appointment.notes,
          contactNumber: appointment.patients?.contact_number,
          paymentStatus: appointment.payment_status,
        }))

        setCompletedAppointments(formattedCompletedData)
      }
    } catch (error) {
      console.error("Error fetching data:", error)
      toast({
        title: "Error",
        description: "Failed to fetch real-time patient data. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleRefresh = () => {
    fetchData()
    toast({
      title: "Dashboard Refreshed",
      description: "Patient data has been updated with the latest information.",
      variant: "default",
    })
  }

  const handleAccept = async (appointment: any) => {
    try {
      const supabase = createClientSupabaseClient()

      // Update the appointment status in the database
      const { error } = await supabase.from("appointments").update({ status: "confirmed" }).eq("id", appointment.id)

      if (error) {
        throw error
      }

      toast({
        title: "Appointment Accepted",
        description: `You have accepted the appointment with ${appointment.patient} on ${appointment.date} at ${appointment.time}.`,
        variant: "default",
      })

      // Refresh the data
      fetchData()
    } catch (error) {
      console.error("Error accepting appointment:", error)
      toast({
        title: "Error",
        description: "Failed to accept appointment. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleDecline = async (appointment: any) => {
    try {
      const supabase = createClientSupabaseClient()

      // Update the appointment status in the database
      const { error } = await supabase.from("appointments").update({ status: "declined" }).eq("id", appointment.id)

      if (error) {
        throw error
      }

      toast({
        title: "Appointment Declined",
        description: `You have declined the appointment with ${appointment.patient}.`,
        variant: "default",
      })

      // Refresh the data
      fetchData()
    } catch (error) {
      console.error("Error declining appointment:", error)
      toast({
        title: "Error",
        description: "Failed to decline appointment. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleRequestPayment = async (appointment: any) => {
    // Navigate to the payments page with the appointment ID
    window.location.href = `/doctor-dashboard/payments?appointmentId=${appointment.id}`
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold">Dr. {doctorName}'s Dashboard</h1>
          <p className="text-white/60">
            {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="icon"
            onClick={handleRefresh}
            className="h-10 w-10 rounded-full border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            disabled={loading}
          >
            <RefreshCw className={`h-5 w-5 ${loading ? "animate-spin" : ""}`} />
          </Button>
          <div className="relative">
            <Bell className="h-6 w-6 text-white/70 hover:text-white cursor-pointer" />
            <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
              {pendingAppointments.filter((a) => a.isUrgent).length}
            </span>
          </div>
          <div className="h-10 w-10 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 flex items-center justify-center">
            <span className="text-sm font-bold text-white">
              {doctorName
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </span>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <DoctorStats />

      {/* Real-time Patients Section */}
      <Card className="bg-white/5 border-white/10 p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 sm:mb-6">
          <h2 className="text-lg sm:text-xl font-bold flex items-center gap-2">
            <Users className="h-5 w-5 text-cyan-500" />
            <span>Real-time Patients</span>
            {loading ? (
              <span className="bg-slate-500/50 text-white text-xs font-bold px-2 py-0.5 rounded-full ml-2">
                Updating...
              </span>
            ) : (
              <span className="bg-green-500/20 text-green-400 text-xs font-bold px-2 py-0.5 rounded-full ml-2">
                Live
              </span>
            )}
          </h2>
          <Button
            variant="outline"
            size="sm"
            className="text-xs border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            onClick={handleRefresh}
            disabled={loading}
          >
            Refresh
          </Button>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-500"></div>
          </div>
        ) : (
          <div className="overflow-x-auto -mx-4 sm:-mx-6">
            <div className="inline-block min-w-full align-middle px-4 sm:px-6">
              <table className="min-w-full">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="text-left py-3 px-2 sm:px-4 text-white/70 font-medium">Patient</th>
                    <th className="text-left py-3 px-2 sm:px-4 text-white/70 font-medium">Status</th>
                    <th className="text-left py-3 px-2 sm:px-4 text-white/70 font-medium hidden sm:table-cell">
                      Appointment
                    </th>
                    <th className="text-left py-3 px-2 sm:px-4 text-white/70 font-medium hidden md:table-cell">
                      Contact
                    </th>
                    <th className="text-left py-3 px-2 sm:px-4 text-white/70 font-medium hidden lg:table-cell">
                      Medical History
                    </th>
                    <th className="text-left py-3 px-2 sm:px-4 text-white/70 font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {activePatients.length > 0 ? (
                    activePatients.map((patient) => (
                      <tr key={patient.id} className="border-b border-white/5 hover:bg-white/5">
                        <td className="py-3 px-2 sm:px-4">
                          <div className="flex items-center gap-2 sm:gap-3">
                            <div className="h-8 w-8 rounded-full bg-pink-500/20 flex items-center justify-center">
                              <Users className="h-4 w-4 text-pink-500" />
                            </div>
                            <span className="font-medium text-sm sm:text-base">{patient.name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-2 sm:px-4">
                          <span
                            className={`px-2 py-1 rounded-full text-xs font-medium ${
                              patient.status === "waiting"
                                ? "bg-amber-500/20 text-amber-400"
                                : patient.status === "in-consultation"
                                  ? "bg-green-500/20 text-green-400"
                                  : "bg-blue-500/20 text-blue-400"
                            }`}
                          >
                            {patient.status === "waiting"
                              ? "Waiting"
                              : patient.status === "in-consultation"
                                ? "In Consult"
                                : "Upcoming"}
                          </span>
                        </td>
                        <td className="py-3 px-2 sm:px-4 hidden sm:table-cell">{patient.appointment_time}</td>
                        <td className="py-3 px-2 sm:px-4 hidden md:table-cell">{patient.contact_number}</td>
                        <td className="py-3 px-2 sm:px-4 hidden lg:table-cell">
                          <div>
                            <p className="text-sm">Last visit: {patient.last_visit || "First Visit"}</p>
                            <p className="text-sm text-white/70">
                              {patient.medical_condition || "No conditions recorded"}
                            </p>
                          </div>
                        </td>
                        <td className="py-3 px-2 sm:px-4">
                          <Button
                            size="sm"
                            className={`h-7 text-xs ${
                              patient.status === "waiting"
                                ? "bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                                : patient.status === "in-consultation"
                                  ? "bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500"
                                  : "bg-gradient-to-r from-slate-600 to-slate-500 hover:from-slate-500 hover:to-slate-400"
                            }`}
                          >
                            {patient.status === "waiting"
                              ? "Start"
                              : patient.status === "in-consultation"
                                ? "Continue"
                                : "View"}
                          </Button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-white/60">
                        <Users className="h-12 w-12 mx-auto mb-3 text-white/30" />
                        <p>No patients currently present</p>
                        <p className="text-sm mt-1">Your active patients will appear here</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </Card>

      {/* Appointment Requests */}
      <Card className="bg-white/5 border-white/10 p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 sm:mb-6">
          <h2 className="text-lg sm:text-xl font-bold flex items-center gap-2">
            <Calendar className="h-5 w-5 text-cyan-500" />
            <span>Appointment Requests</span>
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full ml-2">
              {pendingAppointments.length} Pending
            </span>
          </h2>
          <Button
            variant="outline"
            size="sm"
            className="text-xs border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            onClick={() => (window.location.href = "/doctor-dashboard/appointments")}
          >
            View All
          </Button>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-500"></div>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-1 md:grid-cols-2">
            {pendingAppointments.length > 0 ? (
              pendingAppointments.map((appointment) => (
                <div
                  key={appointment.id}
                  className={`bg-white/10 rounded-lg p-4 border ${
                    appointment.isUrgent ? "border-red-500/30" : "border-white/10"
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                    <div className="flex gap-3">
                      <div className="h-10 w-10 rounded-full bg-pink-500/20 flex items-center justify-center flex-shrink-0">
                        <Users className="h-5 w-5 text-pink-500" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium">{appointment.patient}</h3>
                          {appointment.isUrgent && (
                            <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-xs font-medium">
                              Urgent
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-white/70">{appointment.type}</p>
                        <div className="flex flex-wrap items-center gap-3 mt-1">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3 text-white/60" />
                            <span className="text-xs text-white/60">{appointment.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3 text-white/60" />
                            <span className="text-xs text-white/60">{appointment.time}</span>
                          </div>
                          {appointment.contactNumber && (
                            <div className="flex items-center gap-1">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="12"
                                height="12"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="text-white/60"
                              >
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                              </svg>
                              <span className="text-xs text-white/60">{appointment.contactNumber}</span>
                            </div>
                          )}
                        </div>
                        {appointment.notes && <p className="text-xs text-white/60 mt-2">{appointment.notes}</p>}
                      </div>
                    </div>
                    <div className="flex gap-2 mt-3 sm:mt-0">
                      <Button
                        size="sm"
                        className={`h-8 ${
                          appointment.isUrgent
                            ? "bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400"
                            : "bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500"
                        }`}
                        onClick={() => handleAccept(appointment)}
                      >
                        Accept
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                        onClick={() => handleDecline(appointment)}
                      >
                        Decline
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-white/60 bg-white/5 rounded-lg border border-white/10 md:col-span-2">
                <Calendar className="h-12 w-12 mx-auto mb-3 text-white/30" />
                <p>No pending appointment requests</p>
                <p className="text-sm mt-1">All caught up!</p>
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Completed Appointments */}
      <Card className="bg-white/5 border-white/10 p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 sm:mb-6">
          <h2 className="text-lg sm:text-xl font-bold flex items-center gap-2">
            <Calendar className="h-5 w-5 text-green-500" />
            <span>Completed Appointments</span>
          </h2>
          <Button
            variant="outline"
            size="sm"
            className="text-xs border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
            onClick={() => (window.location.href = "/doctor-dashboard/appointments?tab=history")}
          >
            View All
          </Button>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500"></div>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-1 md:grid-cols-2">
            {completedAppointments.length > 0 ? (
              completedAppointments.map((appointment) => (
                <div key={appointment.id} className="bg-white/10 rounded-lg p-4 border border-white/10">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                    <div className="flex gap-3">
                      <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <Users className="h-5 w-5 text-green-500" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium">{appointment.patient}</h3>
                          <span className="px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-xs font-medium">
                            Completed
                          </span>
                        </div>
                        <p className="text-sm text-white/70">{appointment.type}</p>
                        <div className="flex flex-wrap items-center gap-3 mt-1">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3 text-white/60" />
                            <span className="text-xs text-white/60">{appointment.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3 text-white/60" />
                            <span className="text-xs text-white/60">{appointment.time}</span>
                          </div>
                        </div>
                        {appointment.notes && <p className="text-xs text-white/60 mt-2">{appointment.notes}</p>}
                      </div>
                    </div>
                    <div className="mt-3 sm:mt-0">
                      <Button
                        size="sm"
                        className={`h-8 ${
                          appointment.paymentStatus === "paid"
                            ? "bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500"
                            : "bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500"
                        }`}
                        onClick={() => handleRequestPayment(appointment)}
                      >
                        {appointment.paymentStatus === "paid" ? "View Payment" : "Request Payment"}
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-white/60 bg-white/5 rounded-lg border border-white/10 md:col-span-2">
                <Calendar className="h-12 w-12 mx-auto mb-3 text-white/30" />
                <p>No completed appointments</p>
                <p className="text-sm mt-1">Your completed appointments will appear here</p>
              </div>
            )}
          </div>
        )}
      </Card>
    </div>
  )
}
