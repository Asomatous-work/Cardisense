"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { FileText, Calendar, AlertCircle } from "lucide-react"
import { BodyMeasurements } from "@/components/dashboard/body-measurements"
import { FeatureSimulation } from "@/components/dashboard/feature-simulation"
import { WeeklyHealthReport } from "@/components/dashboard/weekly-health-report"
import { NotificationCenter } from "@/components/dashboard/notification-center"
import { useDeviceType } from "@/hooks/use-device-type"
import { Button } from "@/components/ui/button"

export default function DashboardOverviewPage() {
  const { isMobile, isTablet } = useDeviceType()
  const searchParams = useSearchParams()
  const accessToken = searchParams.get("access_token")
  const expires = searchParams.get("expires")
  const patientName = "Demo Patient" // Default name for overview

  const [isValidAccess, setIsValidAccess] = useState(false)

  useEffect(() => {
    // In a real app, you would validate the token with your backend
    // For this demo, we'll just check if it exists
    if (accessToken) {
      setIsValidAccess(true)
    } else {
      // For demo purposes, we'll still show the dashboard
      // In a real app, you might redirect to a login page
      setIsValidAccess(true)
    }
  }, [accessToken])

  if (!isValidAccess) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="bg-white/5 border-white/10 p-6 max-w-md">
          <div className="text-center">
            <AlertCircle className="h-12 w-12 mx-auto mb-4 text-red-500" />
            <h2 className="text-xl font-bold mb-2">Access Denied</h2>
            <p className="text-white/70 mb-4">Invalid or expired access token. Please request a new access link.</p>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Welcome, {patientName}</h1>
          <p className="text-white/60">
            {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
            {expires && <span className="ml-2 text-amber-400 text-sm">(Temporary access expires in {expires})</span>}
          </p>
        </div>
      </div>

      {/* Notification Center */}
      <NotificationCenter />

      {/* Dashboard Grid */}
      <div className={`grid ${isMobile ? "grid-cols-1" : "grid-cols-1 md:grid-cols-3"} gap-6`}>
        {/* Health Stats Cards - Only show on mobile or first column on larger screens */}
        <div className={`${!isMobile ? "col-span-2" : ""}`}>
          <WeeklyHealthReport />
        </div>

        {/* Quick Stats - Only show on larger screens or below health report on mobile */}
        <div className={`${!isMobile ? "col-span-1" : ""} space-y-6`}>
          <Card className="bg-white/5 border-white/10 p-4 sm:p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="rounded-full bg-pink-500/20 p-2">
                <FileText className="h-5 w-5 text-pink-500" />
              </div>
              <h3 className="text-lg font-medium">Blood Sugar</h3>
            </div>
            <div className="space-y-2">
              <div className="flex items-end justify-between">
                <p className="text-3xl font-bold">98</p>
                <p className="text-sm text-white/60">mg/dL</p>
              </div>
              <div className="h-1 w-full rounded-full bg-white/10">
                <div className="h-1 w-3/4 rounded-full bg-gradient-to-r from-green-500 to-green-400"></div>
              </div>
              <p className="text-sm text-green-500">Normal</p>
            </div>
          </Card>

          <Card className="bg-white/5 border-white/10 p-4 sm:p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="rounded-full bg-pink-500/20 p-2">
                <Calendar className="h-5 w-5 text-pink-500" />
              </div>
              <h3 className="text-lg font-medium">Next Appointment</h3>
            </div>
            <div className="space-y-2">
              <p className="text-xl font-medium">April 18, 2025</p>
              <p className="text-sm text-white/70">Dr. KIRUPA D • 10:30 AM</p>
              <p className="text-sm text-white/70">Cardiology Checkup</p>
              <Button
                className="w-full mt-2 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
                size="sm"
              >
                View Details
              </Button>
            </div>
          </Card>
        </div>
      </div>

      {/* Body Measurements Section */}
      <section>
        <h2 className="text-2xl font-bold mb-4">Body Measurements</h2>
        <BodyMeasurements />
      </section>

      {/* Feature Simulations */}
      <section>
        <FeatureSimulation patientName={patientName} />
      </section>
    </div>
  )
}
