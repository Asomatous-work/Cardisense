import SenseChat from "@/components/sense-chat"

export default function ChatbotPage({ params }: { params: { patientName?: string } }) {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Sense+ Medical Chatbot</h1>
      <p className="text-white/70 mb-6">Your 24/7 health assistant powered by AI</p>
      <SenseChat />
    </div>
  )
}
