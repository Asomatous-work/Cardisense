import type React from "react"
import type { Metadata } from "next"
import { FloatingNav } from "@/components/floating-nav"

export const metadata: Metadata = {
  title: "CARDISENSE - Patient Dashboard",
  description: "Monitor your health data and manage your medical information",
}

export default function DashboardLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: { patientName?: string }
}) {
  // This would normally come from the route params or context
  // For now we'll use a default name that will be overridden
  const patientName = params.patientName ? decodeURIComponent(params.patientName) : "Demo Patient"

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      <div className="flex-1 w-full p-4 sm:p-6 pb-28">{children}</div>
      <FloatingNav type="patient" />
    </div>
  )
}
