"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { AlertCircle, Download, FileText } from "lucide-react"
import { MedicalReport } from "@/components/medical-report"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { getPatientReportByName } from "@/lib/utils/sample-reports"

// Sample test results data
const bloodTestData = {
  Hematology: [
    { name: "Hemoglobin", value: "14.5", unit: "g/dL", normalRange: "13.5-17.5", status: "normal" },
    { name: "White Blood Cells", value: "9.6", unit: "10³/µL", normalRange: "4.5-11.0", status: "normal" },
    { name: "Red Blood Cells", value: "4.9", unit: "10⁶/µL", normalRange: "4.5-5.9", status: "normal" },
    { name: "Platelets", value: "350", unit: "10³/µL", normalRange: "150-450", status: "normal" },
  ],
  Chemistry: [
    { name: "Glucose", value: "110", unit: "mg/dL", normalRange: "70-99", status: "high" },
    { name: "Creatinine", value: "0.9", unit: "mg/dL", normalRange: "0.7-1.3", status: "normal" },
    { name: "BUN", value: "15", unit: "mg/dL", normalRange: "7-20", status: "normal" },
    { name: "Total Cholesterol", value: "205", unit: "mg/dL", normalRange: "<200", status: "high" },
  ],
  "Lipid Panel": [
    { name: "HDL Cholesterol", value: "42", unit: "mg/dL", normalRange: ">40", status: "normal" },
    { name: "LDL Cholesterol", value: "135", unit: "mg/dL", normalRange: "<100", status: "high" },
    { name: "Triglycerides", value: "148", unit: "mg/dL", normalRange: "<150", status: "normal" },
  ],
}

export default function ReportsPage({ params }: { params: { patientName?: string } }) {
  const [patientDetails, setPatientDetails] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [aiInsights, setAiInsights] = useState<string | null>(null)
  const [availableReports, setAvailableReports] = useState<any[]>([])

  const searchParams = useSearchParams()
  const patientName = params.patientName
    ? decodeURIComponent(params.patientName)
    : searchParams.get("name")
      ? decodeURIComponent(searchParams.get("name")!)
      : "Demo Patient"

  useEffect(() => {
    async function fetchPatientData() {
      setLoading(true)
      try {
        // Get patient report from our sample data
        const patientReport = getPatientReportByName(patientName)

        if (patientReport) {
          setPatientDetails(patientReport.patientDetails)

          // Generate AI insights based on the test results
          generateAiInsights(patientReport.resultData)

          // Set available reports
          setAvailableReports([
            {
              id: 1,
              name: patientReport.reportName,
              date: patientReport.reportDate,
              doctor: patientReport.doctorName,
              type: "Comprehensive",
              data: patientReport,
            },
            {
              id: 2,
              name: "Basic Health Checkup",
              date: "January 15, 2025",
              doctor: "JEYASURYA S",
              type: "Basic",
              data: null,
            },
            {
              id: 3,
              name: "Cardiac Stress Test",
              date: "December 10, 2024",
              doctor: "KIRUPA D",
              type: "Specialized",
              data: null,
            },
          ])
        } else {
          // Try to fetch from Supabase
          const supabase = createClientSupabaseClient()

          // Fetch patient data by name
          const { data, error } = await supabase.from("patients").select("*").eq("name", patientName)

          if (error) {
            console.error("Error fetching patient data:", error)
            setError("Failed to load patient data. Please try again.")
            return
          }

          // Check if we got any results
          if (!data || data.length === 0) {
            console.warn(`No patient found with name: ${patientName}. Using demo data.`)
            // Instead of showing an error, we'll use demo data
            setPatientDetails({
              name: patientName,
              id: `CS-${Math.floor(10000 + Math.random() * 90000)}`,
              gender: "Male",
              age: 32,
              bloodGroup: "O+",
              allergies: "Penicillin, Peanuts",
              chronicConditions: "Hypertension",
            })

            // Set available reports for demo
            setAvailableReports([
              {
                id: 1,
                name: "Comprehensive Blood Test",
                date: "April 10, 2025",
                doctor: "KIRUPA D",
                type: "Comprehensive",
                data: null,
              },
              {
                id: 2,
                name: "Basic Health Checkup",
                date: "January 15, 2025",
                doctor: "JEYASURYA S",
                type: "Basic",
                data: null,
              },
            ])
          } else {
            // If multiple patients found, use the first one but log a warning
            if (data.length > 1) {
              console.warn(`Multiple patients found with name: ${patientName}. Using the first one.`)
            }

            // Use the first patient in the results
            const patientData = data[0]
            setPatientDetails({
              name: patientData.name,
              id: patientData.patient_id || `CS-${Math.floor(10000 + Math.random() * 90000)}`,
              email: patientData.email,
              phone: patientData.phone_number,
              address: patientData.address,
              age: patientData.age || calculateAge(patientData.date_of_birth),
              dateOfBirth: patientData.date_of_birth
                ? new Date(patientData.date_of_birth).toLocaleDateString()
                : undefined,
              gender: patientData.gender,
              bloodGroup: patientData.blood_group,
              allergies: patientData.allergies,
              chronicConditions: patientData.chronic_conditions,
            })

            // Set available reports from database (mock for now)
            setAvailableReports([
              {
                id: 1,
                name: "Comprehensive Blood Test",
                date: "April 10, 2025",
                doctor: "KIRUPA D",
                type: "Comprehensive",
                data: null,
              },
              {
                id: 2,
                name: "Basic Health Checkup",
                date: "January 15, 2025",
                doctor: "JEYASURYA S",
                type: "Basic",
                data: null,
              },
            ])
          }

          // Generate AI insights based on the test results
          generateAiInsights(bloodTestData)
        }
      } catch (err) {
        console.error("Error in fetchPatientData:", err)
        setError("An unexpected error occurred. Please try again.")
      } finally {
        setLoading(false)
      }
    }

    fetchPatientData()
  }, [patientName])

  // Helper function to calculate age from date of birth
  const calculateAge = (dateOfBirth: string | null) => {
    if (!dateOfBirth) return undefined

    const dob = new Date(dateOfBirth)
    const today = new Date()
    let age = today.getFullYear() - dob.getFullYear()
    const monthDiff = today.getMonth() - dob.getMonth()

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
      age--
    }

    return age
  }

  // Function to generate AI insights based on test results
  const generateAiInsights = (resultData: any) => {
    // Simulate AI analysis
    const abnormalResults = []

    // Check for abnormal values in all categories
    for (const category in resultData) {
      for (const test of resultData[category]) {
        if (test.status !== "normal") {
          abnormalResults.push({
            name: test.name,
            value: test.value,
            status: test.status,
            category,
          })
        }
      }
    }

    // Generate insights based on abnormal results
    if (abnormalResults.length === 0) {
      setAiInsights(
        "All test results are within normal ranges. Continue with your current health regimen and schedule a follow-up in 12 months.",
      )
    } else {
      let insights = `AI Analysis detected ${abnormalResults.length} abnormal results that require attention:

`

      abnormalResults.forEach((result) => {
        if (result.name === "Glucose" && result.status === "high") {
          insights += `• Your glucose level (${result.value} mg/dL) is elevated. This may indicate prediabetes. Recommended actions: Reduce sugar intake, increase physical activity, and schedule a follow-up test in 3 months.

`
        } else if (result.name === "Total Cholesterol" && result.status === "high") {
          insights += `• Your total cholesterol (${result.value} mg/dL) is above the recommended range. Consider dietary changes including reducing saturated fats and increasing fiber intake.

`
        } else if (result.name === "LDL Cholesterol" && result.status === "high") {
          insights += `• Your LDL cholesterol (${result.value} mg/dL) is elevated. This is often referred to as "bad cholesterol" and increases risk of heart disease. Recommended actions: Increase exercise, consider Mediterranean diet, and discuss with your doctor.

`
        } else {
          insights += `• Your ${result.name} (${result.value}) is ${result.status}. Please consult with your healthcare provider for specific recommendations.

`
        }
      })

      insights += "These insights are generated by AI and should be reviewed by a healthcare professional."

      setAiInsights(insights)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Medical Reports for {patientName}</h1>

      {loading ? (
        <Card className="bg-white/5 border-white/10 p-6">
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-pink-500"></div>
          </div>
        </Card>
      ) : error ? (
        <Card className="bg-white/5 border-white/10 p-6">
          <div className="flex flex-col items-center gap-4 py-8">
            <div className="flex items-center gap-3 text-red-400">
              <AlertCircle className="h-5 w-5" />
              <p>{error}</p>
            </div>
            <Button
              onClick={() => (window.location.href = "/dashboard")}
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
            >
              Return to Dashboard
            </Button>
          </div>
        </Card>
      ) : (
        <>
          {/* Available Reports Section */}
          <Card className="bg-white/5 border-white/10 p-6 mb-6">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <FileText className="h-5 w-5 text-pink-500" />
              Available Reports
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="text-left py-3 px-4 text-white/70 font-medium">Report Name</th>
                    <th className="text-left py-3 px-4 text-white/70 font-medium">Date</th>
                    <th className="text-left py-3 px-4 text-white/70 font-medium">Doctor</th>
                    <th className="text-left py-3 px-4 text-white/70 font-medium">Type</th>
                    <th className="text-left py-3 px-4 text-white/70 font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {availableReports.map((report) => (
                    <tr key={report.id} className="border-b border-white/5 hover:bg-white/5">
                      <td className="py-3 px-4 font-medium">{report.name}</td>
                      <td className="py-3 px-4">{report.date}</td>
                      <td className="py-3 px-4">Dr. {report.doctor}</td>
                      <td className="py-3 px-4">{report.type}</td>
                      <td className="py-3 px-4">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 border-pink-500/40 text-pink-400 hover:bg-pink-500/10"
                          onClick={() => {
                            if (report.data) {
                              // If we have the report data, generate PDF directly
                              import("@/lib/utils/report-generator").then(({ generateMedicalReportPDF }) => {
                                generateMedicalReportPDF(report.data)
                              })
                            } else {
                              // Otherwise, generate a sample report based on patient name
                              const sampleReport = getPatientReportByName(patientName)
                              if (sampleReport) {
                                import("@/lib/utils/report-generator").then(({ generateMedicalReportPDF }) => {
                                  generateMedicalReportPDF({
                                    ...sampleReport,
                                    reportName: report.name,
                                    reportDate: report.date,
                                    doctorName: report.doctor,
                                  })
                                })
                              } else {
                                alert("Sample report not available for this patient")
                              }
                            }
                          }}
                        >
                          <Download className="h-4 w-4 mr-1" /> Download
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {aiInsights && (
            <Card className="bg-white/5 border-white/10 p-6 mb-6">
              <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-pink-500"
                >
                  <path d="M12 2a8 8 0 0 0-8 8c0 1.5.5 2.5 1.5 3.5L12 22l6.5-8.5c1-1 1.5-2 1.5-3.5a8 8 0 0 0-8-8z"></path>
                  <circle cx="12" cy="10" r="1"></circle>
                </svg>
                AI Health Insights
              </h2>
              <div className="bg-white/10 rounded-lg p-4 border border-white/10">
                {aiInsights.split("\n\n").map((paragraph, index) => (
                  <p key={index} className="text-white/80 mb-3">
                    {paragraph}
                  </p>
                ))}
              </div>
            </Card>
          )}

          {/* Display the report from the patient report data if available */}
          {patientDetails && (
            <MedicalReport
              patientName={patientName}
              patientId={patientDetails?.id || "CS-10842"}
              reportName="Comprehensive Blood Test"
              reportDate="April 10, 2025"
              doctorName="KIRUPA D"
              hospitalName="CARDISENSE Medical Center"
              resultData={getPatientReportByName(patientName)?.resultData || bloodTestData}
              patientDetails={patientDetails}
            />
          )}
        </>
      )}
    </div>
  )
}
