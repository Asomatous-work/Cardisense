import { FeatureSimulation } from "@/components/dashboard/feature-simulation"

export default function RewardsPage({ params }: { params: { patientName?: string } }) {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Rewards & Gamification</h1>
      <p className="text-white/70 mb-6">Earn points and rewards for maintaining your health</p>
      <FeatureSimulation initialFeature="Rewards" patientName={params.patientName || "Patient"} />
    </div>
  )
}
