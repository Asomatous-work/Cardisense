import { FeatureSimulation } from "@/components/dashboard/feature-simulation"

export default function PrescriptionsPage({ params }: { params: { patientName?: string } }) {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Smart Prescription Dashboard</h1>
      <p className="text-white/70 mb-6">View and manage your prescriptions in one place</p>
      <FeatureSimulation initialFeature="Medical Reports" patientName={params.patientName || "Patient"} />
    </div>
  )
}
