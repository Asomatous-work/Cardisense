"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, User, CheckCircle, AlertCircle } from "lucide-react"
import { AppointmentSelector } from "@/components/dashboard/appointment-selector"

export default function AppointmentsPage({ params }: { params: { patientName?: string } }) {
  const [activeTab, setActiveTab] = useState<"upcoming" | "past" | "new">("upcoming")
  const patientName = params.patientName || "Demo Patient"

  // Sample upcoming appointments
  const upcomingAppointments = [
    {
      id: 1,
      doctor: "KIRUPA D",
      specialty: "Cardiology",
      type: "Cardiology Checkup",
      date: "April 18, 2025",
      time: "10:30 AM",
      status: "confirmed",
    },
    {
      id: 2,
      doctor: "JEYASURYA S",
      specialty: "Internal Medicine",
      type: "Follow-up Consultation",
      date: "May 5, 2025",
      time: "2:00 PM",
      status: "pending",
    },
  ]

  // Sample past appointments
  const pastAppointments = [
    {
      id: 3,
      doctor: "KIRUPA D",
      specialty: "Cardiology",
      type: "Initial Consultation",
      date: "March 10, 2025",
      time: "11:00 AM",
      status: "completed",
      notes: "Patient reported occasional chest pain. Prescribed medication and recommended follow-up in 1 month.",
    },
    {
      id: 4,
      doctor: "MANDHRAMOORTHY N",
      specialty: "Neurology",
      type: "Neurological Assessment",
      date: "February 22, 2025",
      time: "9:30 AM",
      status: "completed",
      notes: "No significant neurological issues found. Recommended regular exercise and stress management.",
    },
  ]

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Appointments</h1>
      <p className="text-white/70 mb-6">Manage your medical appointments</p>

      {/* Tabs */}
      <div className="flex space-x-2 mb-6">
        <Button
          variant={activeTab === "upcoming" ? "default" : "outline"}
          onClick={() => setActiveTab("upcoming")}
          className={
            activeTab === "upcoming"
              ? "bg-gradient-to-r from-pink-600 to-purple-600"
              : "border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
          }
        >
          Upcoming
        </Button>
        <Button
          variant={activeTab === "past" ? "default" : "outline"}
          onClick={() => setActiveTab("past")}
          className={
            activeTab === "past"
              ? "bg-gradient-to-r from-pink-600 to-purple-600"
              : "border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
          }
        >
          Past
        </Button>
        <Button
          variant={activeTab === "new" ? "default" : "outline"}
          onClick={() => setActiveTab("new")}
          className={
            activeTab === "new"
              ? "bg-gradient-to-r from-pink-600 to-purple-600"
              : "border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
          }
        >
          Book New
        </Button>
      </div>

      {/* Upcoming Appointments */}
      {activeTab === "upcoming" && (
        <div className="space-y-4">
          {upcomingAppointments.length > 0 ? (
            upcomingAppointments.map((appointment) => (
              <Card key={appointment.id} className="bg-white/5 border-white/10 p-4">
                <div className="flex items-start gap-4">
                  <div
                    className={`h-12 w-12 rounded-full ${
                      appointment.status === "confirmed" ? "bg-green-500/20" : "bg-amber-500/20"
                    } flex items-center justify-center flex-shrink-0`}
                  >
                    <User
                      className={`h-6 w-6 ${appointment.status === "confirmed" ? "text-green-500" : "text-amber-500"}`}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium text-lg">Dr. {appointment.doctor}</h3>
                        <p className="text-white/70">{appointment.specialty}</p>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          appointment.status === "confirmed"
                            ? "bg-green-500/20 text-green-500"
                            : "bg-amber-500/20 text-amber-500"
                        }`}
                      >
                        {appointment.status === "confirmed" ? "Confirmed" : "Pending"}
                      </div>
                    </div>
                    <div className="mt-2">
                      <p className="text-white/80">{appointment.type}</p>
                      <div className="flex items-center gap-4 mt-1">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4 text-white/60" />
                          <span className="text-sm text-white/60">{appointment.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4 text-white/60" />
                          <span className="text-sm text-white/60">{appointment.time}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 mt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                      >
                        Reschedule
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-300"
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="bg-white/5 border-white/10 p-6 text-center">
              <div className="flex flex-col items-center justify-center py-8">
                <Calendar className="h-12 w-12 text-white/30 mb-4" />
                <h3 className="text-lg font-medium mb-2">No Upcoming Appointments</h3>
                <p className="text-white/60 mb-4">You don't have any upcoming appointments scheduled.</p>
                <Button
                  onClick={() => setActiveTab("new")}
                  className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
                >
                  Book an Appointment
                </Button>
              </div>
            </Card>
          )}
        </div>
      )}

      {/* Past Appointments */}
      {activeTab === "past" && (
        <div className="space-y-4">
          {pastAppointments.length > 0 ? (
            pastAppointments.map((appointment) => (
              <Card key={appointment.id} className="bg-white/5 border-white/10 p-4">
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="h-6 w-6 text-blue-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium text-lg">Dr. {appointment.doctor}</h3>
                        <p className="text-white/70">{appointment.specialty}</p>
                      </div>
                      <div className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-500 text-xs font-medium">
                        Completed
                      </div>
                    </div>
                    <div className="mt-2">
                      <p className="text-white/80">{appointment.type}</p>
                      <div className="flex items-center gap-4 mt-1">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4 text-white/60" />
                          <span className="text-sm text-white/60">{appointment.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4 text-white/60" />
                          <span className="text-sm text-white/60">{appointment.time}</span>
                        </div>
                      </div>
                    </div>
                    {appointment.notes && (
                      <div className="mt-3 p-3 bg-white/5 rounded-lg border border-white/10">
                        <p className="text-sm text-white/80">{appointment.notes}</p>
                      </div>
                    )}
                    <div className="flex justify-end gap-2 mt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-white/20 text-white/70 hover:bg-white/10 hover:text-white"
                      >
                        View Details
                      </Button>
                      <Button
                        size="sm"
                        className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
                      >
                        Book Follow-up
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="bg-white/5 border-white/10 p-6 text-center">
              <div className="flex flex-col items-center justify-center py-8">
                <AlertCircle className="h-12 w-12 text-white/30 mb-4" />
                <h3 className="text-lg font-medium mb-2">No Past Appointments</h3>
                <p className="text-white/60 mb-4">You don't have any past appointment records.</p>
              </div>
            </Card>
          )}
        </div>
      )}

      {/* Book New Appointment */}
      {activeTab === "new" && <AppointmentSelector patientName={patientName} />}
    </div>
  )
}
