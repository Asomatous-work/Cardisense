import { FeatureSimulation } from "@/components/dashboard/feature-simulation"

export default function NfcCardPage({ params }: { params: { patientName?: string } }) {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">NFC Medical Card</h1>
      <FeatureSimulation initialFeature="NFC Medical Card" patientName={params.patientName || "Patient"} />
    </div>
  )
}
