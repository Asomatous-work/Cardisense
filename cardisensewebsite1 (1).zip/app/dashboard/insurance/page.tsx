"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"
import { InsuranceSelector } from "@/components/dashboard/insurance-selector"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"

export default function InsurancePage({ params }: { params: { patientName?: string } }) {
  const { toast } = useToast()
  const [patientId, setPatientId] = useState<number | null>(null)
  const [patientEmail, setPatientEmail] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const searchParams = useSearchParams()
  const patientName = params.patientName
    ? decodeURIComponent(params.patientName)
    : searchParams.get("name")
      ? decodeURIComponent(searchParams.get("name")!)
      : "Demo Patient"
  const success = searchParams.get("success")

  useEffect(() => {
    // Show success toast if redirected from successful insurance selection
    if (success === "true") {
      toast({
        title: "Email Sent Successfully",
        description: "An insurance confirmation email has been sent to your registered email address.",
        variant: "default",
      })
    }
  }, [success, toast])

  useEffect(() => {
    async function fetchPatientData() {
      setLoading(true)
      try {
        const supabase = createClientSupabaseClient()

        // First try to fetch by name
        const { data, error } = await supabase.from("patients").select("id, email").eq("name", patientName)

        if (error) {
          console.error("Error fetching patient data:", error)
          setError("Failed to load patient data. Please try again.")
          return
        }

        // If no patient found, try to get any patient as a fallback
        if (!data || data.length === 0) {
          console.warn(`No patient found with name: ${patientName}. Trying to get any patient as fallback.`)

          const { data: fallbackData, error: fallbackError } = await supabase
            .from("patients")
            .select("id, email")
            .limit(1)

          if (fallbackError || !fallbackData || fallbackData.length === 0) {
            setError("No patient data found. Please create a patient profile first.")
            setLoading(false)
            return
          }

          // Use the fallback patient
          setPatientId(fallbackData[0].id)
          setPatientEmail(fallbackData[0].email)
          console.log("Using fallback patient:", fallbackData[0])
        } else {
          // If multiple patients found, use the first one but log a warning
          if (data.length > 1) {
            console.warn(`Multiple patients found with name: ${patientName}. Using the first one.`)
          }

          // Use the first patient in the results
          setPatientId(data[0].id)
          setPatientEmail(data[0].email)
        }
      } catch (err) {
        console.error("Error in fetchPatientData:", err)
        setError("An unexpected error occurred. Please try again.")
      } finally {
        setLoading(false)
      }
    }

    fetchPatientData()
  }, [patientName])

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Insurance & Appointments</h1>
      <p className="text-white/70 mb-6">Manage your health insurance and appointments for {patientName}</p>

      {loading ? (
        <Card className="bg-white/5 border-white/10 p-6">
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-pink-500"></div>
          </div>
        </Card>
      ) : error ? (
        <Card className="bg-white/5 border-white/10 p-6">
          <div className="flex flex-col items-center gap-4 py-8">
            <div className="flex items-center gap-3 text-red-400">
              <AlertCircle className="h-5 w-5" />
              <p>{error}</p>
            </div>
            <Button
              onClick={() => (window.location.href = "/dashboard")}
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500"
            >
              Return to Dashboard
            </Button>
          </div>
        </Card>
      ) : patientId ? (
        <InsuranceSelector patientId={patientId} patientEmail={patientEmail || undefined} />
      ) : (
        <Card className="bg-white/5 border-white/10 p-6">
          <div className="flex items-center gap-3 text-amber-400">
            <AlertCircle className="h-5 w-5" />
            <p>Patient data not found. Please update your profile information.</p>
          </div>
        </Card>
      )}
    </div>
  )
}
