import { NextResponse } from "next/server"
import { fetchPendingAppointments, fetchCompletedAppointments } from "@/lib/utils/patient-utils"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type") || "pending"
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    if (type === "completed") {
      const appointments = await fetchCompletedAppointments(limit)
      return NextResponse.json(appointments)
    } else {
      const appointments = await fetchPendingAppointments()
      return NextResponse.json(appointments)
    }
  } catch (error) {
    console.error("Error in appointments API route:", error)
    return NextResponse.json({ error: "Failed to fetch appointments" }, { status: 500 })
  }
}
