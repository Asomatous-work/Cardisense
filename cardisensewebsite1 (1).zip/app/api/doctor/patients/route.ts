import { NextResponse } from "next/server"
import { fetchPresentPatients } from "@/lib/utils/patient-utils"

export async function GET() {
  try {
    const patients = await fetchPresentPatients()
    return NextResponse.json(patients)
  } catch (error) {
    console.error("Error in patients API route:", error)
    return NextResponse.json({ error: "Failed to fetch patients" }, { status: 500 })
  }
}
