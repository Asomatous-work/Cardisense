import { NextResponse } from "next/server"
import { getEmailConfig, getSupabaseConfig } from "@/lib/utils/env-fallbacks"

export async function GET() {
  const supabaseConfig = getSupabaseConfig()
  const emailConfig = getEmailConfig()

  return NextResponse.json({
    supabase: supabaseConfig.available,
    email: emailConfig.available,
  })
}
