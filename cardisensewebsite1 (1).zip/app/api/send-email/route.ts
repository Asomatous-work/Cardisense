import { NextResponse } from "next/server"
import nodemailer from "nodemailer"
import { generateInsuranceEmailTemplate } from "@/lib/email/template-generator"
import { getEmailConfig, isDevelopment } from "@/lib/utils/env-fallbacks"

// Create a transporter for sending emails
const createTransporter = () => {
  const config = getEmailConfig()

  if (!config.available) {
    throw new Error("Email configuration is missing")
  }

  return nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "asomatous.work@gmail.com",
      pass: config.emailPassword,
    },
    tls: {
      rejectUnauthorized: false, // Only for development, remove in production
    },
  })
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const { patientEmail, patientName, insurancePlan, policyNumber, startDate, endDate } = data

    if (!patientEmail || !patientName || !insurancePlan) {
      console.error("Missing required fields:", { patientEmail, patientName, insurancePlan })
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    console.log(`Sending email to ${patientEmail} for patient ${patientName}`)

    // Check if EMAIL_PASSWORD is available
    const config = getEmailConfig()
    if (!config.available) {
      console.warn("EMAIL_PASSWORD environment variable is not set")
      // Return a "success" response in development to avoid breaking the flow
      if (isDevelopment) {
        return NextResponse.json({
          success: true,
          messageId: "mock-message-id",
          note: "Email not actually sent - missing EMAIL_PASSWORD",
        })
      }
      return NextResponse.json({ error: "Email configuration is missing" }, { status: 500 })
    }

    // Generate the email HTML using our string template generator - now with await
    const emailHtml = await generateInsuranceEmailTemplate({
      patientName,
      insurancePlan,
      policyNumber,
      startDate,
      endDate,
    })

    // Email options
    const mailOptions = {
      from: "CARDISENSE <asomatous.work@gmail.com>",
      to: patientEmail,
      subject: "Your CARDISENSE Insurance Plan Confirmation",
      html: emailHtml,
    }

    try {
      // Create transporter and send email
      const transporter = createTransporter()
      const info = await transporter.sendMail(mailOptions)
      console.log("Email sent successfully:", info.response)

      return NextResponse.json({ success: true, messageId: info.messageId })
    } catch (emailError) {
      console.error("Error sending email:", emailError)

      // In development, return success anyway to not break the flow
      if (isDevelopment) {
        return NextResponse.json({
          success: true,
          messageId: "mock-message-id",
          note: "Email not actually sent - error occurred",
        })
      }

      return NextResponse.json(
        {
          error: "Failed to send email",
          details: emailError instanceof Error ? emailError.message : String(emailError),
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Error processing request:", error)
    return NextResponse.json(
      { error: "Failed to process request", details: error instanceof Error ? error.message : String(error) },
      { status: 500 },
    )
  }
}
