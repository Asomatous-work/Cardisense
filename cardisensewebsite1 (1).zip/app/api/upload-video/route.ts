import { type NextRequest, NextResponse } from "next/server"
import { uploadVideo } from "@/lib/supabase/storage"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Generate a unique filename with timestamp
    const fileName = `cardisense-intro-${Date.now()}.mp4`

    // Upload the file to Supabase
    const publicUrl = await uploadVideo(file, fileName)

    return NextResponse.json({ success: true, url: publicUrl })
  } catch (error) {
    console.error("Error uploading video:", error)
    return NextResponse.json({ error: "Failed to upload video" }, { status: 500 })
  }
}
