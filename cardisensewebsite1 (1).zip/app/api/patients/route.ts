import { NextResponse } from "next/server"
import { getPatients, mockPatients } from "@/lib/supabase/server"

export async function GET() {
  try {
    const patients = await getPatients()
    return NextResponse.json(patients)
  } catch (error) {
    console.error("Error in patients API route:", error)
    // Return mock data instead of an error
    return NextResponse.json(mockPatients)
  }
}
