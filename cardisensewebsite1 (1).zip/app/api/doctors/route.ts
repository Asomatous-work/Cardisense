import { NextResponse } from "next/server"
import { getDoctors, mockDoctors } from "@/lib/supabase/server"

export async function GET() {
  try {
    const doctors = await getDoctors()
    return NextResponse.json(doctors)
  } catch (error) {
    console.error("Error in doctors API route:", error)
    // Return mock data instead of an error
    return NextResponse.json(mockDoctors)
  }
}
