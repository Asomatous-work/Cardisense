"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Calendar,
  FileText,
  Heart,
  Mail,
  MessageCircle,
  Shield,
  Trophy,
  X,
  ChevronRight,
  Info,
  Sparkles,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import PortalData from "@/components/portal-data"
import { TeamModal } from "@/components/team-modal"
import { FuturePlansModal } from "@/components/future-plans-modal"
import { FeatureSimulation } from "@/components/dashboard/feature-simulation"
import { MedicalReport } from "@/components/dashboard/medical-report"
import { SiteHeader } from "@/components/site-header"

// Direct video URL
const VIDEO_URL =
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/174086-850404739-QVNWanIAUdHY0SPEj4xiLUbTPvpF1d.mp4"

export default function Home() {
  const [previewFeature, setPreviewFeature] = useState<string | null>(null)
  const [featuresOpen, setFeaturesOpen] = useState(false)
  const [aboutOpen, setAboutOpen] = useState(false)
  const [showFloatingNav, setShowFloatingNav] = useState(true)
  const footerRef = useRef<HTMLElement>(null)
  const [teamModalOpen, setTeamModalOpen] = useState(false)
  const [futurePlansModalOpen, setFuturePlansModalOpen] = useState(false)

  // Handle scroll to hide floating navigation when near footer
  useEffect(() => {
    const handleScroll = () => {
      if (footerRef.current) {
        const footerTop = footerRef.current.getBoundingClientRect().top
        const windowHeight = window.innerHeight

        // Hide floating nav when footer is visible
        setShowFloatingNav(footerTop > windowHeight - 100)
      }
    }

    window.addEventListener("scroll", handleScroll)
    handleScroll() // Check initial position

    return () => {
      window.removeEventListener("scroll", handleScroll)
    }

    // Set background color on html and body to prevent white flashes
    document.documentElement.style.backgroundColor = "#0f172a" // slate-900
    document.body.style.backgroundColor = "#0f172a" // slate-900
  }, [])

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-violet-500/10 via-slate-900 to-fuchsia-500/20 text-white overflow-x-hidden">
      {/* Add the site header with install button */}
      <SiteHeader />

      {/* Rest of the component remains the same */}
      {/* Animated background elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {/* Bright circles */}
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-gradient-to-r from-pink-500/20 to-purple-500/20 backdrop-blur-sm"
            style={{
              width: Math.random() * 300 + 100,
              height: Math.random() * 300 + 100,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              x: [0, Math.random() * 100 - 50],
              y: [0, Math.random() * 100 - 50],
            }}
            transition={{
              duration: Math.random() * 20 + 15,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
              ease: "easeInOut",
            }}
          />
        ))}

        {/* Light beams */}
        <div className="absolute top-0 left-1/4 w-1/2 h-screen bg-gradient-to-b from-pink-500/10 to-transparent transform -rotate-45"></div>
        <div className="absolute top-0 right-1/4 w-1/2 h-screen bg-gradient-to-b from-purple-500/10 to-transparent transform rotate-45"></div>

        {/* Mesh grid */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage:
              "linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        ></div>
      </div>

      {/* Floating Contact Button */}
      <AnimatePresence>
        {showFloatingNav && (
          <motion.div
            className="fixed right-0 top-1/2 transform -translate-y-1/2 z-40"
            initial={{ x: 100 }}
            animate={{ x: 0 }}
            exit={{ x: 100 }}
            transition={{ delay: 1, duration: 0.5 }}
          >
            <a
              href="mailto:asomatous.work@gmail.com"
              className="flex items-center gap-2 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 px-4 py-3 rounded-l-lg shadow-lg group transition-all duration-300"
            >
              <Mail className="h-5 w-5" />
              <span className="opacity-0 max-w-0 group-hover:max-w-xs group-hover:opacity-100 transition-all duration-300 overflow-hidden whitespace-nowrap">
                Contact Us
              </span>
            </a>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Features Button */}
      <AnimatePresence>
        {showFloatingNav && (
          <motion.div
            className="fixed right-0 top-1/3 transform -translate-y-1/2 z-40"
            initial={{ x: 100 }}
            animate={{ x: 0 }}
            exit={{ x: 100 }}
            transition={{ delay: 1.2, duration: 0.5 }}
          >
            <Button
              onClick={() => setFeaturesOpen(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 px-4 py-3 rounded-l-lg shadow-lg group transition-all duration-300 h-auto"
            >
              <Sparkles className="h-5 w-5" />
              <span className="opacity-0 max-w-0 group-hover:max-w-xs group-hover:opacity-100 transition-all duration-300 overflow-hidden whitespace-nowrap">
                Features
              </span>
              <ChevronRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-all duration-300" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating About Button */}
      <AnimatePresence>
        {showFloatingNav && (
          <motion.div
            className="fixed right-0 top-2/3 transform -translate-y-1/2 z-40"
            initial={{ x: 100 }}
            animate={{ x: 0 }}
            exit={{ x: 100 }}
            transition={{ delay: 1.4, duration: 0.5 }}
          >
            <Button
              onClick={() => setAboutOpen(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 px-4 py-3 rounded-l-lg shadow-lg group transition-all duration-300 h-auto"
            >
              <Info className="h-5 w-5" />
              <span className="opacity-0 max-w-0 group-hover:max-w-xs group-hover:opacity-100 transition-all duration-300 overflow-hidden whitespace-nowrap">
                About Us
              </span>
              <ChevronRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-all duration-300" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section className="relative pt-16 pb-20 min-h-screen flex items-center">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl mx-auto text-center"
          >
            <motion.h1
              className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 text-transparent bg-clip-text"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              CARDISENSE
            </motion.h1>
            <motion.p
              className="text-xl md:text-2xl mb-8 text-white"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <span className="font-semibold">Connecting humans with medical technology</span> for a healthier tomorrow
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 border-0 text-white"
                onClick={() => setFuturePlansModalOpen(true)}
              >
                Get Started
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-pink-500 text-pink-500 hover:bg-pink-950/30"
                onClick={() => setTeamModalOpen(true)}
              >
                Learn More
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Video Section */}
      <section className="relative py-16 flex items-center justify-center">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-center bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 text-transparent bg-clip-text">
              See CARDISENSE in Action
            </h2>
            <div className="relative w-full max-w-4xl mx-auto rounded-xl overflow-hidden">
              <video className="w-full h-auto rounded-xl cursor-pointer" playsInline autoPlay muted loop preload="auto">
                <source src={VIDEO_URL} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer with Portal Switch */}
      <footer ref={footerRef} className="py-12 bg-gradient-to-r from-slate-900 to-slate-800 border-t border-white/10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center mb-8">
            <div className="flex items-center gap-2 mb-6">
              <Heart className="h-6 w-6 text-pink-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 text-transparent bg-clip-text">
                CARDISENSE
              </span>
            </div>

            {/* Portal Data Component */}
            <PortalData />
          </div>

          <div className="mt-8 text-center text-white/50 text-sm">
            &copy; {new Date().getFullYear()} CARDISENSE. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Features Panel */}
      <AnimatePresence>
        {featuresOpen && (
          <motion.div
            className="fixed inset-y-0 left-0 z-50 w-full sm:w-[500px] bg-gradient-to-br from-slate-900/95 to-purple-900/95 backdrop-blur-md border-r border-white/20 shadow-2xl overflow-auto"
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
          >
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-500 text-transparent bg-clip-text">
                  Our Features
                </h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setFeaturesOpen(false)}
                  className="hover:bg-white/10 text-white"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <p className="text-white/80 mb-8">
                Revolutionizing healthcare with cutting-edge technology and patient-centered design
              </p>

              <div className="space-y-6">
                {features.map((feature, index) => (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="group"
                  >
                    <Card className="bg-white/10 backdrop-blur-sm border-white/20 hover:border-pink-500/50 transition-all duration-300 shadow-xl hover:shadow-pink-500/20 overflow-hidden">
                      <div className="p-6">
                        <div className="flex items-start gap-4">
                          <div className="rounded-full bg-gradient-to-r from-pink-500/20 to-purple-500/20 w-12 h-12 flex items-center justify-center shrink-0">
                            <feature.icon className="h-6 w-6 text-pink-500" />
                          </div>
                          <div>
                            <h3 className="text-xl font-bold mb-2 text-white">{feature.title}</h3>
                            <p className="text-white/80 mb-4">{feature.description}</p>
                            <Button
                              variant="ghost"
                              className="text-pink-400 hover:text-pink-300 hover:bg-pink-950/30 justify-start p-0"
                              onClick={() => {
                                setPreviewFeature(feature.title)
                                setFeaturesOpen(false)
                              }}
                            >
                              Preview Feature
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* About Panel */}
      <AnimatePresence>
        {aboutOpen && (
          <motion.div
            className="fixed inset-y-0 left-0 z-50 w-full sm:w-[500px] bg-gradient-to-br from-slate-900/95 to-blue-900/95 backdrop-blur-md border-r border-white/20 shadow-2xl overflow-auto"
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
          >
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 text-transparent bg-clip-text">
                  About Us
                </h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setAboutOpen(false)}
                  className="hover:bg-white/10 text-white"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6 shadow-xl mb-8">
                <p className="text-lg mb-4 text-white">
                  At CARDISENSE, we believe in bridging technology with healthcare to build smarter, more accessible
                  cardiac care for everyone. Founded by a team of tech innovators and medical professionals, our mission
                  is to empower patients and doctors with seamless tools to monitor, communicate, and act faster when it
                  comes to heart health.
                </p>
                <p className="text-lg mb-4 text-white">
                  We started with a vision to eliminate delays in diagnosis and improve patient compliance through
                  real-time access to vital health data. From NFC-driven reports to AI-assisted support, every feature
                  is crafted with purpose: to reduce stress, save time, and deliver accurate care—right when it's
                  needed.
                </p>
                <p className="text-lg text-white">
                  CARDISENSE is more than a platform. It's a movement towards modern, connected, and compassionate
                  healthcare.
                </p>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-bold text-white">Our Vision</h3>
                <p className="text-white/80 mb-6">
                  To create a world where cardiac health is monitored seamlessly, diagnosed accurately, and treated
                  promptly through the power of technology.
                </p>

                <h3 className="text-xl font-bold text-white">Our Team</h3>
                <p className="text-white/80">
                  A dedicated group of healthcare professionals, technology experts, and patient advocates working
                  together to revolutionize cardiac care.
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Feature Preview Modal */}
      {previewFeature && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-gradient-to-br from-slate-800 to-slate-900 border border-white/20 rounded-xl max-w-4xl w-full max-h-[80vh] overflow-auto shadow-2xl"
          >
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-2xl font-bold text-white">{previewFeature}</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setPreviewFeature(null)}
                  className="hover:bg-white/10 text-white"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              {previewFeature === "Medical Reports" ? (
                <MedicalReport
                  patientName="Demo Patient"
                  patientId="CS-10842"
                  reportName="Comprehensive Blood Test"
                  reportDate="April 10, 2025"
                  doctorName="KIRUPA D"
                  hospitalName="CARDISENSE Medical Center"
                  resultData={{
                    General: [
                      { name: "Glucose", value: "110", unit: "mg/dL", normalRange: "70-99", status: "high" },
                      { name: "Hemoglobin", value: "14.5", unit: "g/dL", normalRange: "13.5-17.5", status: "normal" },
                      {
                        name: "White Blood Cells",
                        value: "9.6",
                        unit: "10³/µL",
                        normalRange: "4.5-11.0",
                        status: "normal",
                      },
                      { name: "Total Cholesterol", value: "205", unit: "mg/dL", normalRange: "<200", status: "high" },
                    ],
                  }}
                />
              ) : (
                <FeatureSimulation initialFeature={previewFeature} patientName="Demo User" />
              )}

              <div className="flex justify-end mt-4">
                <Button
                  onClick={() => setPreviewFeature(null)}
                  className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 border-0 text-white"
                >
                  Close Preview
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
      {/* Team Modal */}
      <TeamModal isOpen={teamModalOpen} onClose={() => setTeamModalOpen(false)} />

      {/* Future Plans Modal */}
      <FuturePlansModal isOpen={futurePlansModalOpen} onClose={() => setFuturePlansModalOpen(false)} />
    </div>
  )
}

const features = [
  {
    title: "NFC Medical Card",
    description:
      "Tap your card on any NFC-enabled device to instantly share your medical information with healthcare providers.",
    icon: Heart,
  },
  {
    title: "Medical Reports",
    description: "Patients can instantly retrieve their medical reports—no more waiting for printouts or emails.",
    icon: FileText,
  },
  {
    title: "Smart Prescription Dashboard",
    description:
      "View real-time prescriptions including medicines, meal schedules, and meditations. Each update by the doctor reflects immediately.",
    icon: Calendar,
  },
  {
    title: "Sense+ Chatbot",
    description:
      "An AI-powered assistant available 24/7 for medical queries, emotional support, and health-related guidance.",
    icon: MessageCircle,
  },
  {
    title: "Insurance & Appointments",
    description:
      "Track insurance claims, policy info, and appointment requests—all managed and updated by the admin in real-time.",
    icon: Shield,
  },
  {
    title: "Rewards",
    description: "Earn points by completing health surveys. Points can be redeemed as discount coupons or rewards.",
    icon: Trophy,
  },
]
