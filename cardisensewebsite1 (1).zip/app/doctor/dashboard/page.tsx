import type { Metadata } from "next"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardStats } from "@/components/dashboard/dashboard-stats"
import { PresentPatients } from "@/components/dashboard/present-patients"
import { AppointmentManagement } from "@/components/dashboard/appointment-management"
import { PatientMedicalHistory } from "@/components/dashboard/patient-medical-history"
import { PatientMessaging } from "@/components/dashboard/patient-messaging"
import { TelemedicineConsole } from "@/components/dashboard/telemedicine-console"
import { NotificationsPanel } from "@/components/dashboard/notifications-panel"
import { PaymentRequests } from "@/components/dashboard/payment-requests"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Doctor Dashboard | CARDISENSE",
  description: "Manage your patients, appointments, and medical records.",
}

export default function DoctorDashboardPage() {
  return (
    <div className="flex flex-col min-h-screen w-full bg-slate-950">
      <DashboardHeader heading="Doctor Dashboard" text="Manage your patients, appointments, and medical records." />

      <div className="flex-1 container py-6 space-y-6 max-w-7xl">
        <DashboardStats />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <PresentPatients />
          </div>
          <div className="lg:col-span-1">
            <NotificationsPanel />
          </div>
        </div>

        <Tabs defaultValue="appointments" className="w-full">
          <TabsList className="grid grid-cols-5 mb-6">
            <TabsTrigger value="appointments">Appointments</TabsTrigger>
            <TabsTrigger value="medical-history">Medical History</TabsTrigger>
            <TabsTrigger value="messaging">Messaging</TabsTrigger>
            <TabsTrigger value="telemedicine">Telemedicine</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
          </TabsList>

          <TabsContent value="appointments" className="mt-0">
            <AppointmentManagement />
          </TabsContent>

          <TabsContent value="medical-history" className="mt-0">
            <PatientMedicalHistory />
          </TabsContent>

          <TabsContent value="messaging" className="mt-0">
            <PatientMessaging />
          </TabsContent>

          <TabsContent value="telemedicine" className="mt-0">
            <TelemedicineConsole />
          </TabsContent>

          <TabsContent value="payments" className="mt-0">
            <PaymentRequests />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
