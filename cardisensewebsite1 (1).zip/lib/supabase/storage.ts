import { createClientSupabaseClient } from "./client"

// Bucket name for storing videos
const VIDEOS_BUCKET = "videos"

/**
 * Ensures the videos bucket exists in Supabase storage
 */
export async function ensureVideosBucketExists() {
  const supabase = createClientSupabaseClient()

  // Check if the bucket already exists
  const { data: buckets } = await supabase.storage.listBuckets()
  const bucketExists = buckets?.some((bucket) => bucket.name === VIDEOS_BUCKET)

  if (!bucketExists) {
    // Create the bucket if it doesn't exist
    const { error } = await supabase.storage.createBucket(VIDEOS_BUCKET, {
      public: true, // Make the bucket public so files can be accessed without authentication
    })

    if (error) {
      console.error("Error creating videos bucket:", error)
      throw error
    }

    console.log("Videos bucket created successfully")
  }
}

/**
 * Uploads a video file to Supabase storage
 * @param file The file to upload
 * @param fileName The name to give the file in storage
 * @returns The URL of the uploaded file
 */
export async function uploadVideo(file: File, fileName: string): Promise<string> {
  const supabase = createClientSupabaseClient()

  // Ensure the bucket exists
  await ensureVideosBucketExists()

  // Upload the file
  const { data, error } = await supabase.storage.from(VIDEOS_BUCKET).upload(fileName, file, {
    cacheControl: "3600",
    upsert: true,
  })

  if (error) {
    console.error("Error uploading video:", error)
    throw error
  }

  // Get the public URL
  const {
    data: { publicUrl },
  } = supabase.storage.from(VIDEOS_BUCKET).getPublicUrl(data.path)

  return publicUrl
}

/**
 * Gets the public URL for a video in Supabase storage
 * @param fileName The name of the file in storage
 * @returns The public URL of the file
 */
export function getVideoUrl(fileName: string): string {
  const supabase = createClientSupabaseClient()

  const {
    data: { publicUrl },
  } = supabase.storage.from(VIDEOS_BUCKET).getPublicUrl(fileName)

  return publicUrl
}
