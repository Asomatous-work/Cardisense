import { createClient } from "@supabase/supabase-js"
import { getSupabaseConfig } from "@/lib/utils/env-fallbacks"

// Create a singleton to avoid multiple instances
let supabaseClient: ReturnType<typeof createClient> | null = null

export const createClientSupabaseClient = () => {
  if (supabaseClient) return supabaseClient

  const config = getSupabaseConfig()

  if (!config.available) {
    console.warn("Using demo mode with mock Supabase client")
    // Create a dummy client that will fail gracefully
    const dummyClient = createClient("https://example.com", "dummy-key", {
      auth: {
        persistSession: false,
      },
    })

    // Add a custom property to identify this as a dummy client
    Object.defineProperty(dummyClient, "isDummy", {
      value: true,
      writable: false,
      configurable: false,
    })

    return dummyClient
  }

  supabaseClient = createClient(config.supabaseUrl, config.supabaseKey)
  return supabaseClient
}
