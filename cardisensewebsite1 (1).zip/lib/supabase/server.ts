import { createClient } from "@supabase/supabase-js"
import { getSupabaseConfig, isDevelopment } from "@/lib/utils/env-fallbacks"

export type Patient = {
  id: number
  patient_id: string
  name: string
  email: string
  status: "active" | "pending" | "inactive"
  created_at: string
}

export type Doctor = {
  id: number
  name: string
  specialty: string
  available: boolean
  email: string
  created_at: string
}

// Create a single supabase client for server-side operations
export const createServerSupabaseClient = () => {
  const config = getSupabaseConfig()

  if (!config.available) {
    if (isDevelopment) {
      console.warn("[SERVER]\nUsing mock data due to missing Supabase environment variables")
    }
    // Return a dummy client that will fail gracefully
    return createClient("https://example.com", "dummy-key", {
      auth: {
        persistSession: false,
      },
    })
  }

  return createClient(config.supabaseUrl, config.supabaseKey)
}

// Mock data for when Supabase is not available
export const mockPatients: Patient[] = [
  {
    id: 1,
    patient_id: "CS-10001",
    name: "ARAVIND G",
    email: "aravind@example.com",
    status: "active",
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    patient_id: "CS-10002",
    name: "RAFIKHAN L",
    email: "rafikhan@example.com",
    status: "active",
    created_at: new Date().toISOString(),
  },
  {
    id: 3,
    patient_id: "CS-10003",
    name: "SETHU RAJA P",
    email: "sethuraja@example.com",
    status: "pending",
    created_at: new Date().toISOString(),
  },
]

export const mockDoctors: Doctor[] = [
  {
    id: 1,
    name: "KIRUPA D",
    specialty: "Cardiology",
    available: true,
    email: "kirupa@example.com",
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    name: "JEYASURYA S",
    specialty: "Internal Medicine",
    available: false,
    email: "jeyasurya@example.com",
    created_at: new Date().toISOString(),
  },
  {
    id: 3,
    name: "MANDHRAMOORTHY N",
    specialty: "Neurology",
    available: true,
    email: "mandhramoorthy@example.com",
    created_at: new Date().toISOString(),
  },
]

export async function getPatients() {
  try {
    const supabase = createServerSupabaseClient()

    // Check if we're using the dummy client (missing env vars)
    if (supabase.supabaseUrl === "https://example.com") {
      if (isDevelopment) {
        console.log("[SERVER]\nUsing mock patient data due to missing environment variables")
      }
      return mockPatients
    }

    const { data, error } = await supabase.from("patients").select("*")

    if (error) {
      if (isDevelopment) {
        console.error("[SERVER]\nError fetching patients:", error)
      }
      return mockPatients
    }

    return data as Patient[]
  } catch (error) {
    if (isDevelopment) {
      console.error("[SERVER]\nError in getPatients:", error)
    }
    return mockPatients
  }
}

export async function getDoctors() {
  try {
    const supabase = createServerSupabaseClient()

    // Check if we're using the dummy client (missing env vars)
    if (supabase.supabaseUrl === "https://example.com") {
      if (isDevelopment) {
        console.log("[SERVER]\nUsing mock doctor data due to missing environment variables")
      }
      return mockDoctors
    }

    const { data, error } = await supabase.from("doctors").select("*")

    if (error) {
      if (isDevelopment) {
        console.error("[SERVER]\nError fetching doctors:", error)
      }
      return mockDoctors
    }

    return data as Doctor[]
  } catch (error) {
    if (isDevelopment) {
      console.error("[SERVER]\nError in getDoctors:", error)
    }
    return mockDoctors
  }
}
