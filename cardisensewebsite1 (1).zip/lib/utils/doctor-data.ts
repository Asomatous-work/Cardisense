/**
 * Doctor data including UPI IDs for payment
 */

export interface DoctorInfo {
  id: number
  name: string
  specialty: string
  upiId: string
  appointmentFees: AppointmentFee[]
}

export interface AppointmentFee {
  type: string
  description: string
  amount: number
}

export const doctors: DoctorInfo[] = [
  {
    id: 1,
    name: "KIRUPA D",
    specialty: "Cardiology",
    upiId: "lovelykirupa1610@okaxis",
    appointmentFees: [
      {
        type: "Basic Consultation",
        description: "Regular checkup and basic consultation",
        amount: 500,
      },
      {
        type: "Comprehensive Checkup",
        description: "Detailed examination with basic tests",
        amount: 1200,
      },
      {
        type: "Emergency Consultation",
        description: "Urgent care and immediate attention",
        amount: 2000,
      },
    ],
  },
  {
    id: 2,
    name: "MANDHRAMOORTHY N",
    specialty: "Internal Medicine",
    upiId: "mandhramoorthy7@okhdfcbank",
    appointmentFees: [
      {
        type: "Basic Consultation",
        description: "Regular checkup and basic consultation",
        amount: 450,
      },
      {
        type: "Follow-up Visit",
        description: "Follow-up after previous treatment",
        amount: 250,
      },
      {
        type: "Comprehensive Checkup",
        description: "Detailed examination with basic tests",
        amount: 1000,
      },
    ],
  },
  {
    id: 3,
    name: "JEYASURYA S",
    specialty: "Neurology",
    upiId: "jayasuriya9840@oksbi",
    appointmentFees: [
      {
        type: "Basic Consultation",
        description: "Regular checkup and basic consultation",
        amount: 600,
      },
      {
        type: "Neurological Assessment",
        description: "Comprehensive neurological evaluation",
        amount: 1500,
      },
      {
        type: "Follow-up Visit",
        description: "Follow-up after previous treatment",
        amount: 300,
      },
    ],
  },
]

/**
 * Get doctor information by name
 */
export function getDoctorByName(name: string): DoctorInfo | undefined {
  return doctors.find((doctor) => doctor.name.toLowerCase() === name.toLowerCase())
}

/**
 * Get doctor information by ID
 */
export function getDoctorById(id: number): DoctorInfo | undefined {
  return doctors.find((doctor) => doctor.id === id)
}

/**
 * Get UPI ID for a doctor by name
 */
export function getDoctorUpiId(doctorName: string): string {
  const doctor = getDoctorByName(doctorName)
  return doctor?.upiId || "doctor.default@okaxis"
}
