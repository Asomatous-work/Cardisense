"use client"

import QRCode from "qrcode"

/**
 * Generates a UPI payment link with the given parameters
 */
export function generateUPILink({
  upiId,
  amount,
  name,
  transactionNote,
}: {
  upiId: string
  amount: number
  name: string
  transactionNote: string
}) {
  // Format according to UPI deep link specifications
  // pa: payee address (UPI ID)
  // pn: payee name
  // am: amount
  // tn: transaction note
  // cu: currency (INR for Indian Rupee)
  return `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(
    name,
  )}&am=${amount}&tn=${encodeURIComponent(transactionNote)}&cu=INR`
}

/**
 * Generates a QR code data URL for a UPI payment
 */
export async function generateUPIQRCode({
  upiId,
  amount,
  name,
  transactionNote,
}: {
  upiId: string
  amount: number
  name: string
  transactionNote: string
}): Promise<string> {
  try {
    const upiLink = generateUPILink({ upiId, amount, name, transactionNote })

    // Generate QR code as data URL
    const qrCodeDataURL = await QRCode.toDataURL(upiLink, {
      width: 200,
      margin: 2,
      color: {
        dark: "#000000",
        light: "#FFFFFF",
      },
    })

    return qrCodeDataURL
  } catch (error) {
    console.error("Error generating QR code:", error)
    return ""
  }
}
