import { jsPDF } from "jspdf"
import autoTable from "jspdf-autotable"
import type { TestResult } from "@/components/medical-report"

/**
 * Generates and downloads a medical report as PDF
 */
export function generateMedicalReportPDF({
  patientName,
  patientId,
  reportName,
  reportDate,
  doctorName,
  hospitalName,
  resultData,
  patientDetails,
}: {
  patientName: string
  patientId: string
  reportName: string
  reportDate: string
  doctorName: string
  hospitalName: string
  resultData: Record<string, TestResult[]>
  patientDetails?: any
}) {
  // Create a new PDF document
  const doc = new jsPDF()

  // Add hospital logo/header
  doc.setFillColor(236, 72, 153) // Pink color
  doc.rect(0, 0, doc.internal.pageSize.width, 20, "F")

  doc.setTextColor(255, 255, 255)
  doc.setFontSize(16)
  doc.setFont("helvetica", "bold")
  doc.text("CARDISENSE MEDICAL CENTER", 105, 10, { align: "center" })

  // Report title
  doc.setTextColor(0, 0, 0)
  doc.setFontSize(18)
  doc.text(reportName, 105, 30, { align: "center" })

  doc.setFontSize(10)
  doc.setTextColor(100, 100, 100)
  doc.text(`Report Date: ${reportDate}`, 105, 38, { align: "center" })

  // Patient information section
  doc.setFontSize(12)
  doc.setTextColor(0, 0, 0)
  doc.setFont("helvetica", "bold")
  doc.text("Patient Information", 14, 50)

  doc.setFont("helvetica", "normal")
  doc.setFontSize(10)

  const patientInfo = [
    [`Name: ${patientName}`, `Patient ID: ${patientId}`],
    [`Gender: ${patientDetails?.gender || "Male"}`, `Age: ${patientDetails?.age || "32"} years`],
    [`Blood Group: ${patientDetails?.bloodGroup || "O+"}`, `Contact: ${patientDetails?.phone || "N/A"}`],
  ]

  autoTable(doc, {
    startY: 55,
    head: [],
    body: patientInfo,
    theme: "plain",
    styles: { cellPadding: 1, fontSize: 10 },
    columnStyles: { 0: { cellWidth: 90 }, 1: { cellWidth: 90 } },
  })

  // Doctor information
  doc.setFont("helvetica", "bold")
  doc.text("Test Information", 14, 80)

  doc.setFont("helvetica", "normal")
  const doctorInfo = [
    [`Doctor: Dr. ${doctorName}`, `Hospital: ${hospitalName}`],
    [`Collected on: ${reportDate.split(" ")[0]}`, `Report Status: Final`],
  ]

  autoTable(doc, {
    startY: 85,
    head: [],
    body: doctorInfo,
    theme: "plain",
    styles: { cellPadding: 1, fontSize: 10 },
    columnStyles: { 0: { cellWidth: 90 }, 1: { cellWidth: 90 } },
  })

  // Test results
  let yPos = 110

  for (const [category, tests] of Object.entries(resultData)) {
    // Category header
    doc.setFont("helvetica", "bold")
    doc.setFontSize(12)
    doc.text(`${category} Results`, 14, yPos)
    yPos += 5

    // Table headers
    const headers = [["Test", "Result", "Unit", "Normal Range", "Status"]]

    // Table data
    const data = tests.map((test) => [test.name, test.value, test.unit, test.normalRange, test.status.toUpperCase()])

    autoTable(doc, {
      startY: yPos,
      head: headers,
      body: data,
      theme: "striped",
      headStyles: {
        fillColor: [236, 72, 153],
        textColor: [255, 255, 255],
        fontStyle: "bold",
      },
      columnStyles: {
        0: { cellWidth: 50 },
        1: { cellWidth: 30 },
        2: { cellWidth: 30 },
        3: { cellWidth: 40 },
        4: { cellWidth: 30 },
      },
      didDrawCell: (data) => {
        // Color the status cell based on the value
        if (data.section === "body" && data.column.index === 4) {
          const status = data.cell.text[0].toLowerCase()
          if (status === "normal") {
            doc.setFillColor(34, 197, 94) // Green
          } else if (status === "high") {
            doc.setFillColor(245, 158, 11) // Amber
          } else if (status === "low") {
            doc.setFillColor(59, 130, 246) // Blue
          } else if (status === "critical") {
            doc.setFillColor(239, 68, 68) // Red
          }
          doc.setTextColor(255, 255, 255)

          // Draw a colored rectangle for the status
          const x = data.cell.x + 2
          const y = data.cell.y + 2
          const w = data.cell.width - 4
          const h = data.cell.height - 4
          doc.roundedRect(x, y, w, h, 2, 2, "F")

          // Add the text
          doc.setFontSize(8)
          doc.text(status.toUpperCase(), x + w / 2, y + h / 2 + 1, { align: "center", baseline: "middle" })
        }
      },
    })

    yPos = (doc as any).lastAutoTable.finalY + 10

    // Add a new page if we're running out of space
    if (yPos > 250 && Object.entries(resultData).indexOf([category, tests]) < Object.entries(resultData).length - 1) {
      doc.addPage()
      yPos = 20
    }
  }

  // Doctor's notes and interpretation
  if (yPos > 220) {
    doc.addPage()
    yPos = 20
  }

  doc.setFont("helvetica", "bold")
  doc.setFontSize(12)
  doc.setTextColor(0, 0, 0)
  doc.text("Interpretation", 14, yPos)

  doc.setFont("helvetica", "normal")
  doc.setFontSize(10)
  doc.text(
    "Based on the test results, your overall health indicators are within normal range with a few minor deviations. " +
      "No critical values were detected. Follow-up recommended in 6 months.",
    14,
    yPos + 8,
    { maxWidth: 180 },
  )

  doc.setFont("helvetica", "bold")
  doc.text("Notes", 14, yPos + 25)

  doc.setFont("helvetica", "normal")
  doc.text(
    "Please continue with your current medication. Maintain a healthy diet with reduced sodium intake. " +
      "Regular exercise is recommended. If you experience any concerning symptoms, please contact your healthcare provider.",
    14,
    yPos + 33,
    { maxWidth: 180 },
  )

  // Footer
  const pageCount = doc.getNumberOfPages()
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i)

    // Footer line
    doc.setDrawColor(200, 200, 200)
    doc.line(14, 280, 196, 280)

    // Footer text
    doc.setFontSize(8)
    doc.setTextColor(100, 100, 100)
    doc.text(
      `This report is generated by CARDISENSE Medical Center. For any queries, please contact support@cardisense.com`,
      105,
      285,
      { align: "center" },
    )

    // Page number
    doc.text(`Page ${i} of ${pageCount}`, 196, 285, { align: "right" })
  }

  // Save the PDF
  doc.save(`${patientName.replace(/\s+/g, "_")}_${reportName.replace(/\s+/g, "_")}.pdf`)
}
