/**
 * This file is just for documentation purposes to track the packages we're using
 *
 * Packages used in this project:
 * - qrcode: For generating QR codes for UPI payments
 * - framer-motion: For animations
 * - nodemailer: For sending emails
 * - @supabase/supabase-js: For database interactions
 * - jspdf: For generating PDF reports
 * - jspdf-autotable: For creating tables in PDF reports
 */

// Note: In a real project, these would be in package.json
// But since we're using Next.js, we just import them directly
