/**
 * Utility function to get the base URL for API calls
 * This handles different environments (development, preview, production)
 */
export function getApiBaseUrl(): string {
  // For server-side code
  if (typeof window === "undefined") {
    // On Vercel, use VERCEL_URL with https
    if (process.env.VERCEL_URL) {
      return `https://${process.env.VERCEL_URL}`
    }

    // Fallback to NEXT_PUBLIC_BASE_URL if available
    if (process.env.NEXT_PUBLIC_BASE_URL) {
      return process.env.NEXT_PUBLIC_BASE_URL
    }

    // Final fallback for local development
    return "http://localhost:3000"
  }

  // For client-side code, use the current origin
  return window.location.origin
}
