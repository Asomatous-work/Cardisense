import type { TestResult } from "@/components/medical-report"

export interface PatientReport {
  patientName: string
  patientId: string
  reportName: string
  reportDate: string
  doctorName: string
  hospitalName: string
  resultData: {
    [category: string]: TestResult[]
  }
  patientDetails?: {
    name: string
    id: string
    email?: string
    phone?: string
    address?: string
    age?: number
    dateOfBirth?: string
    gender?: string
    bloodGroup?: string
    allergies?: string
    chronicConditions?: string
  }
}

/**
 * Generate a sample report for ARAVIND G
 */
export function getAravindGReport(): PatientReport {
  return {
    patientName: "ARAVIND G",
    patientId: "CS-10001",
    reportName: "Comprehensive Blood Test",
    reportDate: "April 10, 2025",
    doctorName: "KIRUPA D",
    hospitalName: "CARDISENSE Medical Center",
    patientDetails: {
      name: "ARAVIND G",
      id: "CS-10001",
      email: "aravind@example.com",
      phone: "+91 9876543210",
      address: "123 Main Street, Mumbai, Maharashtra",
      age: 45,
      gender: "Male",
      bloodGroup: "B+",
      allergies: "Penicillin",
      chronicConditions: "Hypertension, Type 2 Diabetes",
    },
    resultData: {
      Hematology: [
        { name: "Hemoglobin", value: "13.2", unit: "g/dL", normalRange: "13.5-17.5", status: "low" },
        { name: "White Blood Cells", value: "9.6", unit: "10³/µL", normalRange: "4.5-11.0", status: "normal" },
        { name: "Red Blood Cells", value: "4.9", unit: "10⁶/µL", normalRange: "4.5-5.9", status: "normal" },
        { name: "Platelets", value: "350", unit: "10³/µL", normalRange: "150-450", status: "normal" },
      ],
      Chemistry: [
        { name: "Glucose", value: "142", unit: "mg/dL", normalRange: "70-99", status: "high" },
        { name: "HbA1c", value: "7.2", unit: "%", normalRange: "<5.7", status: "high" },
        { name: "Creatinine", value: "0.9", unit: "mg/dL", normalRange: "0.7-1.3", status: "normal" },
        { name: "BUN", value: "15", unit: "mg/dL", normalRange: "7-20", status: "normal" },
      ],
      "Lipid Panel": [
        { name: "Total Cholesterol", value: "220", unit: "mg/dL", normalRange: "<200", status: "high" },
        { name: "HDL Cholesterol", value: "38", unit: "mg/dL", normalRange: ">40", status: "low" },
        { name: "LDL Cholesterol", value: "145", unit: "mg/dL", normalRange: "<100", status: "high" },
        { name: "Triglycerides", value: "185", unit: "mg/dL", normalRange: "<150", status: "high" },
      ],
      "Cardiac Markers": [
        { name: "Troponin I", value: "0.01", unit: "ng/mL", normalRange: "<0.04", status: "normal" },
        { name: "CK-MB", value: "3.2", unit: "ng/mL", normalRange: "<5.0", status: "normal" },
        { name: "BNP", value: "85", unit: "pg/mL", normalRange: "<100", status: "normal" },
      ],
    },
  }
}

/**
 * Generate a sample report for RAFIKHAN L
 */
export function getRafikhanLReport(): PatientReport {
  return {
    patientName: "RAFIKHAN L",
    patientId: "CS-10002",
    reportName: "Annual Health Checkup",
    reportDate: "March 15, 2025",
    doctorName: "JEYASURYA S",
    hospitalName: "CARDISENSE Medical Center",
    patientDetails: {
      name: "RAFIKHAN L",
      id: "CS-10002",
      email: "rafikhan@example.com",
      phone: "+91 9876543211",
      address: "456 Park Avenue, Delhi, Delhi",
      age: 32,
      gender: "Male",
      bloodGroup: "O+",
      allergies: "None",
      chronicConditions: "Asthma",
    },
    resultData: {
      Hematology: [
        { name: "Hemoglobin", value: "13.8", unit: "g/dL", normalRange: "12.0-15.5", status: "normal" },
        { name: "White Blood Cells", value: "7.2", unit: "10³/µL", normalRange: "4.5-11.0", status: "normal" },
        { name: "Red Blood Cells", value: "4.6", unit: "10⁶/µL", normalRange: "4.0-5.2", status: "normal" },
        { name: "Platelets", value: "280", unit: "10³/µL", normalRange: "150-450", status: "normal" },
      ],
      Chemistry: [
        { name: "Glucose", value: "92", unit: "mg/dL", normalRange: "70-99", status: "normal" },
        { name: "Creatinine", value: "0.8", unit: "mg/dL", normalRange: "0.5-1.1", status: "normal" },
        { name: "BUN", value: "12", unit: "mg/dL", normalRange: "7-20", status: "normal" },
        { name: "Calcium", value: "9.8", unit: "mg/dL", normalRange: "8.5-10.5", status: "normal" },
      ],
      "Lipid Panel": [
        { name: "Total Cholesterol", value: "185", unit: "mg/dL", normalRange: "<200", status: "normal" },
        { name: "HDL Cholesterol", value: "62", unit: "mg/dL", normalRange: ">50", status: "normal" },
        { name: "LDL Cholesterol", value: "105", unit: "mg/dL", normalRange: "<100", status: "high" },
        { name: "Triglycerides", value: "90", unit: "mg/dL", normalRange: "<150", status: "normal" },
      ],
      "Thyroid Panel": [
        { name: "TSH", value: "2.8", unit: "µIU/mL", normalRange: "0.4-4.0", status: "normal" },
        { name: "Free T4", value: "1.2", unit: "ng/dL", normalRange: "0.8-1.8", status: "normal" },
        { name: "Free T3", value: "3.1", unit: "pg/mL", normalRange: "2.3-4.2", status: "normal" },
      ],
    },
  }
}

/**
 * Generate a sample report for SETHU RAJA P
 */
export function getSethuRajaPReport(): PatientReport {
  return {
    patientName: "SETHU RAJA P",
    patientId: "CS-10003",
    reportName: "Cardiac Evaluation",
    reportDate: "February 22, 2025",
    doctorName: "KIRUPA D",
    hospitalName: "CARDISENSE Medical Center",
    patientDetails: {
      name: "SETHU RAJA P",
      id: "CS-10003",
      email: "sethuraja@example.com",
      phone: "+91 9876543212",
      address: "789 Lake View, Bangalore, Karnataka",
      age: 58,
      gender: "Male",
      bloodGroup: "A-",
      allergies: "Sulfa drugs",
      chronicConditions: "Coronary Artery Disease, Hypertension",
    },
    resultData: {
      "Cardiac Markers": [
        { name: "Troponin I", value: "0.06", unit: "ng/mL", normalRange: "<0.04", status: "high" },
        { name: "CK-MB", value: "6.2", unit: "ng/mL", normalRange: "<5.0", status: "high" },
        { name: "BNP", value: "210", unit: "pg/mL", normalRange: "<100", status: "high" },
        { name: "hs-CRP", value: "3.8", unit: "mg/L", normalRange: "<3.0", status: "high" },
      ],
      "Lipid Panel": [
        { name: "Total Cholesterol", value: "240", unit: "mg/dL", normalRange: "<200", status: "high" },
        { name: "HDL Cholesterol", value: "35", unit: "mg/dL", normalRange: ">40", status: "low" },
        { name: "LDL Cholesterol", value: "165", unit: "mg/dL", normalRange: "<100", status: "high" },
        { name: "Triglycerides", value: "200", unit: "mg/dL", normalRange: "<150", status: "high" },
      ],
      "Blood Pressure": [
        { name: "Systolic", value: "158", unit: "mmHg", normalRange: "<120", status: "high" },
        { name: "Diastolic", value: "95", unit: "mmHg", normalRange: "<80", status: "high" },
        { name: "Heart Rate", value: "88", unit: "bpm", normalRange: "60-100", status: "normal" },
      ],
      "ECG Results": [
        { name: "PR Interval", value: "180", unit: "ms", normalRange: "120-200", status: "normal" },
        { name: "QRS Duration", value: "110", unit: "ms", normalRange: "<120", status: "normal" },
        { name: "QT Interval", value: "440", unit: "ms", normalRange: "<450", status: "normal" },
        { name: "ST Segment", value: "-1.2", unit: "mm", normalRange: "0±0.5", status: "low" },
      ],
    },
  }
}

/**
 * Generate a sample report for Ananya Desai
 */
export function getAnanyaDesaiReport(): PatientReport {
  return {
    patientName: "Ananya Desai",
    patientId: "CS-10004",
    reportName: "Preventive Health Screening",
    reportDate: "April 5, 2025",
    doctorName: "MANDHRAMOORTHY N",
    hospitalName: "CARDISENSE Medical Center",
    patientDetails: {
      name: "Ananya Desai",
      id: "CS-10004",
      email: "ananya@example.com",
      phone: "+91 9876543213",
      address: "234 Green Street, Chennai, Tamil Nadu",
      age: 29,
      gender: "Female",
      bloodGroup: "AB+",
      allergies: "Peanuts",
      chronicConditions: "None",
    },
    resultData: {
      Hematology: [
        { name: "Hemoglobin", value: "12.5", unit: "g/dL", normalRange: "12.0-15.5", status: "normal" },
        { name: "White Blood Cells", value: "6.8", unit: "10³/µL", normalRange: "4.5-11.0", status: "normal" },
        { name: "Red Blood Cells", value: "4.3", unit: "10⁶/µL", normalRange: "4.0-5.2", status: "normal" },
        { name: "Platelets", value: "320", unit: "10³/µL", normalRange: "150-450", status: "normal" },
      ],
      Chemistry: [
        { name: "Glucose", value: "85", unit: "mg/dL", normalRange: "70-99", status: "normal" },
        { name: "Creatinine", value: "0.7", unit: "mg/dL", normalRange: "0.5-1.1", status: "normal" },
        { name: "BUN", value: "10", unit: "mg/dL", normalRange: "7-20", status: "normal" },
        { name: "Calcium", value: "9.5", unit: "mg/dL", normalRange: "8.5-10.5", status: "normal" },
      ],
      "Lipid Panel": [
        { name: "Total Cholesterol", value: "175", unit: "mg/dL", normalRange: "<200", status: "normal" },
        { name: "HDL Cholesterol", value: "58", unit: "mg/dL", normalRange: ">50", status: "normal" },
        { name: "LDL Cholesterol", value: "95", unit: "mg/dL", normalRange: "<100", status: "normal" },
        { name: "Triglycerides", value: "110", unit: "mg/dL", normalRange: "<150", status: "normal" },
      ],
      "Vitamin Levels": [
        { name: "Vitamin D", value: "22", unit: "ng/mL", normalRange: "30-100", status: "low" },
        { name: "Vitamin B12", value: "450", unit: "pg/mL", normalRange: "200-900", status: "normal" },
        { name: "Folate", value: "12", unit: "ng/mL", normalRange: ">5.9", status: "normal" },
        { name: "Iron", value: "65", unit: "µg/dL", normalRange: "60-170", status: "normal" },
      ],
    },
  }
}

/**
 * Generate a sample report for Vikram Singh
 */
export function getVikramSinghReport(): PatientReport {
  return {
    patientName: "Vikram Singh",
    patientId: "CS-10005",
    reportName: "Post-Surgery Evaluation",
    reportDate: "March 30, 2025",
    doctorName: "KIRUPA D",
    hospitalName: "CARDISENSE Medical Center",
    patientDetails: {
      name: "Vikram Singh",
      id: "CS-10005",
      email: "vikram@example.com",
      phone: "+91 9876543214",
      address: "567 Mountain View, Hyderabad, Telangana",
      age: 52,
      gender: "Male",
      bloodGroup: "O-",
      allergies: "Latex",
      chronicConditions: "Post CABG Surgery, Hypertension",
    },
    resultData: {
      Hematology: [
        { name: "Hemoglobin", value: "11.8", unit: "g/dL", normalRange: "13.5-17.5", status: "low" },
        { name: "White Blood Cells", value: "12.5", unit: "10³/µL", normalRange: "4.5-11.0", status: "high" },
        { name: "Red Blood Cells", value: "4.2", unit: "10⁶/µL", normalRange: "4.5-5.9", status: "low" },
        { name: "Platelets", value: "380", unit: "10³/µL", normalRange: "150-450", status: "normal" },
      ],
      "Cardiac Markers": [
        { name: "Troponin I", value: "0.02", unit: "ng/mL", normalRange: "<0.04", status: "normal" },
        { name: "CK-MB", value: "4.8", unit: "ng/mL", normalRange: "<5.0", status: "normal" },
        { name: "BNP", value: "120", unit: "pg/mL", normalRange: "<100", status: "high" },
        { name: "hs-CRP", value: "4.2", unit: "mg/L", normalRange: "<3.0", status: "high" },
      ],
      "Coagulation Panel": [
        { name: "PT", value: "13.5", unit: "sec", normalRange: "11.0-13.5", status: "normal" },
        { name: "INR", value: "2.8", unit: "", normalRange: "2.0-3.0", status: "normal" },
        { name: "aPTT", value: "32", unit: "sec", normalRange: "25-35", status: "normal" },
      ],
      "Medication Levels": [
        { name: "Warfarin Effect", value: "2.8", unit: "INR", normalRange: "2.0-3.0", status: "normal" },
        { name: "Digoxin", value: "1.2", unit: "ng/mL", normalRange: "0.8-2.0", status: "normal" },
        { name: "Amiodarone", value: "1.5", unit: "µg/mL", normalRange: "0.5-2.5", status: "normal" },
      ],
    },
  }
}

/**
 * Get a patient report by name
 */
export function getPatientReportByName(name: string): PatientReport | null {
  const normalizedName = name.toLowerCase().trim()

  if (normalizedName.includes("aravind")) {
    return getAravindGReport()
  } else if (normalizedName.includes("rafikhan")) {
    return getRafikhanLReport()
  } else if (normalizedName.includes("sethu")) {
    return getSethuRajaPReport()
  } else if (normalizedName.includes("ananya")) {
    return getAnanyaDesaiReport()
  } else if (normalizedName.includes("vikram")) {
    return getVikramSinghReport()
  }

  return null
}
