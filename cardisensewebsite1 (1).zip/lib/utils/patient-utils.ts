import { createServerSupabaseClient } from "@/lib/supabase/server"

/**
 * Fetches real-time present patients from the database
 */
export async function fetchPresentPatients() {
  try {
    const supabase = createServerSupabaseClient()

    const { data, error } = await supabase
      .from("patients")
      .select("*")
      .eq("is_present", true)
      .order("appointment_time", { ascending: true })

    if (error) {
      console.error("Error fetching present patients:", error)
      return []
    }

    return data || []
  } catch (error) {
    console.error("Error in fetchPresentPatients:", error)
    return []
  }
}

/**
* Fetches pending appointment requests from the  error)
    return []
  }
}

/**
* Fetches pending appointment requests from the database
*/
export async function fetchPendingAppointments() {
  try {
    const supabase = createServerSupabaseClient()

    // First, fetch all patients to have their data available
    const { data: patientsData, error: patientsError } = await supabase
      .from("patients")
      .select("id, name, contact_number")

    if (patientsError) {
      console.error("Error fetching patients:", patientsError)
      return []
    }

    // Create a map of patient data by ID for easy lookup
    const patientsMap: Record<number, any> = {}
    patientsData?.forEach((patient) => {
      patientsMap[patient.id] = patient
    })

    // Now fetch appointments
    const { data, error } = await supabase
      .from("appointments")
      .select("*")
      .in("status", ["pending", "urgent"])
      .order("is_urgent", { ascending: false })
      .order("appointment_date", { ascending: true })

    if (error) {
      console.error("Error fetching pending appointments:", error)
      return []
    }

    // Transform the data to match our component's expected format
    const formattedData = (data || []).map((appointment) => {
      const patient = patientsMap[appointment.patient_id] || { name: "Unknown Patient", contact_number: "N/A" }

      return {
        id: appointment.id,
        patient: patient.name,
        patientId: appointment.patient_id,
        type: appointment.type,
        date: appointment.appointment_date ? new Date(appointment.appointment_date).toLocaleDateString() : "No date",
        time: appointment.appointment_time || "No time",
        status: appointment.status,
        notes: appointment.notes,
        contactNumber: patient.contact_number,
        isUrgent: appointment.is_urgent || appointment.status === "urgent",
      }
    })

    return formattedData
  } catch (error) {
    console.error("Error in fetchPendingAppointments:", error)
    return []
  }
}

/**
 * Fetches completed appointments from the database
 */
export async function fetchCompletedAppointments(limit = 5) {
  try {
    const supabase = createServerSupabaseClient()

    // First, fetch all patients to have their data available
    const { data: patientsData, error: patientsError } = await supabase
      .from("patients")
      .select("id, name, contact_number")

    if (patientsError) {
      console.error("Error fetching patients:", patientsError)
      return []
    }

    // Create a map of patient data by ID for easy lookup
    const patientsMap: Record<number, any> = {}
    patientsData?.forEach((patient) => {
      patientsMap[patient.id] = patient
    })

    // Now fetch appointments
    const { data, error } = await supabase
      .from("appointments")
      .select("*")
      .eq("status", "completed")
      .order("appointment_date", { ascending: false })
      .limit(limit)

    if (error) {
      console.error("Error fetching completed appointments:", error)
      return []
    }

    // Transform the data to match our component's expected format
    const formattedData = (data || []).map((appointment) => {
      const patient = patientsMap[appointment.patient_id] || { name: "Unknown Patient", contact_number: "N/A" }

      return {
        id: appointment.id,
        patient: patient.name,
        patientId: appointment.patient_id,
        type: appointment.type,
        date: appointment.appointment_date ? new Date(appointment.appointment_date).toLocaleDateString() : "No date",
        time: appointment.appointment_time || "No time",
        status: "completed",
        notes: appointment.notes,
        contactNumber: patient.contact_number,
        paymentStatus: appointment.payment_status,
      }
    })

    return formattedData
  } catch (error) {
    console.error("Error in fetchCompletedAppointments:", error)
    return []
  }
}

/**
 * Updates an appointment status in the database
 */
export async function updateAppointmentStatus(appointmentId: number, status: string) {
  try {
    const supabase = createServerSupabaseClient()

    const { error } = await supabase.from("appointments").update({ status }).eq("id", appointmentId)

    if (error) {
      console.error("Error updating appointment status:", error)
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (error) {
    console.error("Error in updateAppointmentStatus:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}
