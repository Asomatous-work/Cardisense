/**
 * Utility functions to handle missing environment variables gracefully
 */

// Check if we're in development mode
export const isDevelopment = process.env.NODE_ENV === "development"

// Email configuration fallbacks
export function getEmailConfig() {
  // For email functionality
  const emailPassword = process.env.EMAIL_PASSWORD

  if (!emailPassword) {
    if (isDevelopment) {
      console.warn("EMAIL_PASSWORD environment variable is not set - email functionality will be limited")
    }
    return {
      available: false,
      message: "Email configuration is missing. Using mock email service.",
    }
  }

  return {
    available: true,
    emailPassword,
  }
}

// Supabase configuration fallbacks
export function getSupabaseConfig() {
  // For Supabase functionality
  const supabaseUrl = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseKey =
    process.env.SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseKey) {
    if (isDevelopment) {
      console.warn("Supabase environment variables are not set - database functionality will be limited")
    }
    return {
      available: false,
      message: "Supabase configuration is missing. Using mock database.",
    }
  }

  return {
    available: true,
    supabaseUrl,
    supabaseKey,
  }
}
