"use server"

import { createServerSupabaseClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"

// Import the API URL utility
// import { getApiBaseUrl } from "@/lib/utils/api-url"

interface SelectInsuranceParams {
  patientId: number
  insurancePlanId: number
  startDate: string
  endDate: string
}

export async function selectInsurance({ patientId, insurancePlanId, startDate, endDate }: SelectInsuranceParams) {
  try {
    const supabase = createServerSupabaseClient()

    // First, check if the patient already has this insurance plan
    const { data: existingInsurance, error: checkError } = await supabase
      .from("patient_insurance")
      .select("*")
      .eq("patient_id", patientId)
      .eq("insurance_plan_id", insurancePlanId)
      .single()

    if (checkError && checkError.code !== "PGRST116") {
      // PGRST116 is the error code for "no rows returned" which is expected if no insurance exists
      console.error("Error checking existing insurance:", checkError)
      return { success: false, error: checkError.message }
    }

    // Generate a unique policy number (only if we don't have an existing one)
    let policyNumber = existingInsurance?.policy_number

    if (!policyNumber) {
      policyNumber = `HSC-${Math.floor(100000 + Math.random() * 900000)}-${String.fromCharCode(
        65 + Math.floor(Math.random() * 26),
      )}`
    }

    let insuranceData

    if (existingInsurance) {
      // Update the existing insurance record
      console.log("Updating existing insurance for patient:", patientId)

      const { data, error: updateError } = await supabase
        .from("patient_insurance")
        .update({
          start_date: startDate,
          end_date: endDate,
          status: "active", // Reactivate if it was inactive
        })
        .eq("patient_id", patientId)
        .eq("insurance_plan_id", insurancePlanId)
        .select()

      if (updateError) {
        console.error("Error updating insurance:", updateError)
        return { success: false, error: updateError.message }
      }

      insuranceData = data
    } else {
      // Insert a new insurance record
      console.log("Creating new insurance for patient:", patientId)

      const { data, error: insertError } = await supabase
        .from("patient_insurance")
        .insert({
          patient_id: patientId,
          insurance_plan_id: insurancePlanId,
          policy_number: policyNumber,
          start_date: startDate,
          end_date: endDate,
          status: "active",
          payment_status: "pending",
        })
        .select()

      if (insertError) {
        console.error("Error inserting insurance:", insertError)
        return { success: false, error: insertError.message }
      }

      insuranceData = data
    }

    // Get the patient details
    const { data: patientData, error: patientError } = await supabase
      .from("patients")
      .select("name, email")
      .eq("id", patientId)
      .single()

    if (patientError) {
      console.error("Error fetching patient:", patientError)
      return { success: false, error: patientError.message }
    }

    // Get the insurance plan details
    const { data: planData, error: planError } = await supabase
      .from("insurance_plans")
      .select("*")
      .eq("id", insurancePlanId)
      .single()

    if (planError) {
      console.error("Error fetching insurance plan:", planError)
      return { success: false, error: planError.message }
    }

    // Send the email notification only if this is a new selection or the user requests it
    let emailSent = false
    if (patientData.email && (!existingInsurance || true)) {
      // Always send email for now
      try {
        // Import the server action dynamically to avoid bundling issues
        const { sendInsuranceEmail } = await import("@/lib/actions/email-actions")

        const emailResult = await sendInsuranceEmail({
          patientEmail: patientData.email,
          patientName: patientData.name,
          insurancePlan: {
            name: planData.name,
            provider: planData.provider,
            coverageAmount: planData.coverage_amount,
            monthlyPremium: planData.monthly_premium,
            description: planData.description,
            benefits: planData.benefits,
          },
          policyNumber,
          startDate,
          endDate,
        })

        if (emailResult.success) {
          emailSent = true
        } else {
          console.error("Error sending email notification:", emailResult.error)
        }
      } catch (error) {
        console.error("Error sending email:", error)
      }
    }

    revalidatePath("/dashboard/insurance")

    // If this is a server action called from a form, redirect with success parameter
    if (emailSent) {
      redirect("/dashboard/insurance?success=true")
    }

    return {
      success: true,
      policyNumber,
      emailSent,
      isNewSelection: !existingInsurance,
    }
  } catch (error) {
    console.error("Error in selectInsurance:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}
