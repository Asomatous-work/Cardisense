"use server"

import { createServerSupabaseClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"
import { sendAppointmentConfirmationEmail } from "./email-actions"

interface BookAppointmentParams {
  patientId: number
  patientName: string
  patientEmail: string
  doctorId: number
  doctorName: string
  appointmentType: string
  appointmentDate: string
  appointmentTime: string
  notes?: string
}

export async function bookAppointment(params: BookAppointmentParams) {
  try {
    const {
      patientId,
      patientName,
      patientEmail,
      doctorId,
      doctorName,
      appointmentType,
      appointmentDate,
      appointmentTime,
      notes,
    } = params

    const supabase = createServerSupabaseClient()

    // Format the appointment date and time into a single datetime
    const appointmentDateTime = new Date(`${appointmentDate}T${appointmentTime}`).toISOString()

    // Insert the appointment into the database
    const { data, error } = await supabase
      .from("appointments")
      .insert({
        patient_id: patientId,
        doctor_id: doctorId,
        appointment_type: appointmentType,
        appointment_datetime: appointmentDateTime,
        status: "pending",
        notes: notes || "",
      })
      .select()

    if (error) {
      console.error("Error booking appointment:", error)
      return { success: false, error: error.message }
    }

    // Send confirmation email
    try {
      await sendAppointmentConfirmationEmail({
        patientEmail,
        patientName,
        doctorName,
        appointmentType,
        appointmentDate,
        appointmentTime,
      })
    } catch (emailError) {
      console.error("Error sending appointment confirmation email:", emailError)
      // Continue even if email fails
    }

    revalidatePath("/dashboard/appointments")

    return {
      success: true,
      appointmentId: data[0].id,
      message: "Appointment booked successfully. A confirmation email has been sent.",
    }
  } catch (error) {
    console.error("Error in bookAppointment:", error)
    return {
      success: false,
      error: "An unexpected error occurred while booking your appointment.",
    }
  }
}

export async function cancelAppointment(appointmentId: number) {
  try {
    const supabase = createServerSupabaseClient()

    const { error } = await supabase.from("appointments").update({ status: "cancelled" }).eq("id", appointmentId)

    if (error) {
      console.error("Error cancelling appointment:", error)
      return { success: false, error: error.message }
    }

    revalidatePath("/dashboard/appointments")

    return {
      success: true,
      message: "Appointment cancelled successfully.",
    }
  } catch (error) {
    console.error("Error in cancelAppointment:", error)
    return {
      success: false,
      error: "An unexpected error occurred while cancelling your appointment.",
    }
  }
}

export async function getAvailableAppointmentSlots(doctorId: number, date: string) {
  try {
    const supabase = createServerSupabaseClient()

    // Get all appointments for the doctor on the specified date
    const startOfDay = new Date(`${date}T00:00:00`).toISOString()
    const endOfDay = new Date(`${date}T23:59:59`).toISOString()

    const { data: bookedAppointments, error } = await supabase
      .from("appointments")
      .select("appointment_datetime")
      .eq("doctor_id", doctorId)
      .gte("appointment_datetime", startOfDay)
      .lte("appointment_datetime", endOfDay)
      .not("status", "eq", "cancelled")

    if (error) {
      console.error("Error fetching booked appointments:", error)
      return { success: false, error: error.message }
    }

    // Define all possible time slots (9 AM to 5 PM, 30-minute intervals)
    const allTimeSlots = []
    for (let hour = 9; hour < 17; hour++) {
      allTimeSlots.push(`${hour.toString().padStart(2, "0")}:00`)
      allTimeSlots.push(`${hour.toString().padStart(2, "0")}:30`)
    }

    // Filter out booked slots
    const bookedTimes = bookedAppointments.map((appt) => {
      const apptTime = new Date(appt.appointment_datetime)
      return `${apptTime.getHours().toString().padStart(2, "0")}:${apptTime.getMinutes().toString().padStart(2, "0")}`
    })

    const availableSlots = allTimeSlots.filter((slot) => !bookedTimes.includes(slot))

    return {
      success: true,
      availableSlots,
    }
  } catch (error) {
    console.error("Error in getAvailableAppointmentSlots:", error)
    return {
      success: false,
      error: "An unexpected error occurred while fetching available appointment slots.",
    }
  }
}
