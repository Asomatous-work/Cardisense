"use server"

import { cookies } from "next/headers"
import { revalidatePath } from "next/cache"
import { createServerSupabaseClient } from "@/lib/supabase/server"

// Known patient names from the database
const KNOWN_PATIENTS = [
  { id: 1, name: "Aravind G", email: "aravind@example.com" },
  { id: 2, name: "Rafikhan L", email: "rafikhan@example.com" },
  { id: 3, name: "Sethu Raja P", email: "sethuraja@example.com" },
]

export async function getPaymentRequests(filter: "all" | "pending" | "paid" | "overdue" = "all") {
  const cookieStore = cookies()
  const supabase = createServerSupabaseClient(cookieStore)

  let query = supabase.from("payment_requests").select(`
      id,
      amount,
      description,
      status,
      due_date,
      service_type,
      created_at,
      patient_id
    `)

  if (filter !== "all") {
    query = query.eq("status", filter)
  }

  const { data, error } = await query.order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching payment requests:", error)
    return []
  }

  // Fetch patient data separately
  const patientIds = data.map((item) => item.patient_id)

  if (patientIds.length > 0) {
    const { data: patients, error: patientsError } = await supabase
      .from("patients")
      .select("id, name, email")
      .in("id", patientIds)

    if (!patientsError && patients && patients.length > 0) {
      // Create a map of patient data for quick lookup
      const patientMap = patients.reduce(
        (acc, patient) => {
          acc[patient.id] = patient
          return acc
        },
        {} as Record<number, any>,
      )

      // Join the data
      return data.map((item) => ({
        ...item,
        patientName: patientMap[item.patient_id]?.name || findKnownPatient(item.patient_id)?.name || "Unknown Patient",
        patientEmail: patientMap[item.patient_id]?.email || findKnownPatient(item.patient_id)?.email || "",
      }))
    }
  }

  // Fallback to known patients if database query fails
  return data.map((item) => {
    const knownPatient = findKnownPatient(item.patient_id)
    return {
      ...item,
      patientName: knownPatient?.name || "Unknown Patient",
      patientEmail: knownPatient?.email || "",
    }
  })
}

// Helper function to find a known patient by ID
function findKnownPatient(id: number) {
  return KNOWN_PATIENTS.find((patient) => patient.id === id)
}

export async function getPaymentStats() {
  const cookieStore = cookies()
  const supabase = createServerSupabaseClient(cookieStore)

  // Get all payment requests
  const { data: allPayments, error: allError } = await supabase
    .from("payment_requests")
    .select("id, amount, status, created_at, due_date")

  if (allError) {
    console.error("Error fetching payment stats:", allError)
    return {
      totalOutstanding: 0,
      pendingCount: 0,
      collectedThisMonth: 0,
      paidThisMonth: 0,
      overdueAmount: 0,
      overdueCount: 0,
      successRate: 0,
      paidCount: 0,
      totalCount: 0,
    }
  }

  // Current date and first day of month
  const now = new Date()
  const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)

  // Calculate stats
  const pendingPayments = allPayments.filter((p) => p.status === "pending")
  const paidPayments = allPayments.filter((p) => p.status === "paid")
  const overduePayments = allPayments.filter((p) => p.status === "overdue")
  const paidThisMonth = paidPayments.filter((p) => {
    const paidDate = new Date(p.created_at)
    return paidDate >= firstDayOfMonth
  })

  const totalOutstanding = pendingPayments.reduce((sum, p) => sum + Number(p.amount), 0)
  const collectedThisMonth = paidThisMonth.reduce((sum, p) => sum + Number(p.amount), 0)
  const overdueAmount = overduePayments.reduce((sum, p) => sum + Number(p.amount), 0)

  const successRate = allPayments.length > 0 ? Math.round((paidPayments.length / allPayments.length) * 100) : 0

  return {
    totalOutstanding,
    pendingCount: pendingPayments.length,
    collectedThisMonth,
    paidThisMonth: paidThisMonth.length,
    overdueAmount,
    overdueCount: overduePayments.length,
    successRate,
    paidCount: paidPayments.length,
    totalCount: allPayments.length,
  }
}

export async function createPaymentRequest({
  patientId,
  amount,
  description,
  serviceType,
  dueDate,
}: {
  patientId: number
  amount: number
  description: string
  serviceType: string
  dueDate: Date
}) {
  const cookieStore = cookies()
  const supabase = createServerSupabaseClient(cookieStore)

  const { data, error } = await supabase
    .from("payment_requests")
    .insert({
      patient_id: patientId,
      amount,
      description,
      service_type: serviceType,
      due_date: dueDate.toISOString().split("T")[0],
      status: "pending",
    })
    .select()

  if (error) {
    console.error("Error creating payment request:", error)
    throw new Error("Failed to create payment request")
  }

  revalidatePath("/doctor-dashboard/payments")
  return data
}

export async function updatePaymentStatus(paymentId: number, status: string) {
  const cookieStore = cookies()
  const supabase = createServerSupabaseClient(cookieStore)

  const { error } = await supabase.from("payment_requests").update({ status }).eq("id", paymentId)

  if (error) {
    console.error("Error updating payment status:", error)
    throw new Error("Failed to update payment status")
  }

  revalidatePath("/doctor-dashboard/payments")
}

export async function sendPaymentReminder(paymentId: number, patientEmail: string) {
  // In a real application, you would integrate with an email service
  // For now, we'll just simulate sending an email
  console.log(`Sending payment reminder to ${patientEmail} for payment ID ${paymentId}`)

  // You could use the email-actions.ts file that was mentioned in the previous context
  // await sendEmail({
  //   to: patientEmail,
  //   subject: 'Payment Reminder',
  //   body: `This is a reminder that your payment is due. Please log in to your account to make the payment.`,
  // })

  return { success: true }
}
