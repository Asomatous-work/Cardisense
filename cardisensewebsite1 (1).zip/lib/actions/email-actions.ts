"use server"

import { generateInsuranceEmailTemplate } from "@/lib/email/template-generator"
import nodemailer from "nodemailer"
import { getEmailConfig, isDevelopment } from "@/lib/utils/env-fallbacks"

// Create a transporter for sending emails
const createTransporter = () => {
  const config = getEmailConfig()

  if (!config.available) {
    throw new Error("Email configuration is missing")
  }

  return nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "asomatous.work@gmail.com",
      pass: config.emailPassword,
    },
    tls: {
      rejectUnauthorized: false, // Only for development, remove in production
    },
  })
}

export interface SendInsuranceEmailParams {
  patientEmail: string
  patientName: string
  insurancePlan: {
    name: string
    provider: string
    coverageAmount: number
    monthlyPremium: number
    description: string
    benefits: string[]
  }
  policyNumber: string
  startDate: string
  endDate: string
}

// Enhance the email sending function with better error handling and logging
export async function sendInsuranceEmail(params: SendInsuranceEmailParams) {
  try {
    const { patientEmail, patientName, insurancePlan, policyNumber, startDate, endDate } = params
    const config = getEmailConfig()

    // Check if EMAIL_PASSWORD is available
    if (!config.available) {
      console.warn("EMAIL_PASSWORD environment variable is not set")

      // For demo purposes, log the email that would have been sent
      console.log(`[DEMO MODE] Email would be sent to: ${patientEmail}`)
      console.log(`[DEMO MODE] Subject: Your CARDISENSE Insurance Plan Confirmation`)
      console.log(`[DEMO MODE] Content: Insurance plan ${insurancePlan.name} confirmed for ${patientName}`)

      // Return a "success" response in development to avoid breaking the flow
      if (isDevelopment) {
        return {
          success: true,
          messageId: "mock-message-id",
          note: "Email not actually sent - missing EMAIL_PASSWORD, but would have been sent in production",
        }
      }
      return { success: false, error: "Email configuration is missing" }
    }

    // Generate the email HTML using our string template generator
    const emailHtml = await generateInsuranceEmailTemplate({
      patientName,
      insurancePlan,
      policyNumber,
      startDate,
      endDate,
    })

    // Email options
    const mailOptions = {
      from: "CARDISENSE <asomatous.work@gmail.com>",
      to: patientEmail,
      subject: "Your CARDISENSE Insurance Plan Confirmation",
      html: emailHtml,
    }

    try {
      // Create transporter and send email
      const transporter = createTransporter()

      // Log that we're attempting to send an email
      console.log(`Attempting to send email to ${patientEmail}...`)

      const info = await transporter.sendMail(mailOptions)
      console.log("Email sent successfully:", info.response)
      console.log("Message ID:", info.messageId)

      return { success: true, messageId: info.messageId }
    } catch (emailError) {
      console.error("Error sending email:", emailError)

      // In development, return success anyway to not break the flow
      if (isDevelopment) {
        console.log(`[DEMO MODE] Email would be sent to: ${patientEmail} in production`)
        return {
          success: true,
          messageId: "mock-message-id",
          note: "Email not actually sent - error occurred, but would have been sent in production",
        }
      }

      return {
        success: false,
        error: "Failed to send email",
        details: emailError instanceof Error ? emailError.message : String(emailError),
      }
    }
  } catch (error) {
    console.error("Error in sendInsuranceEmail:", error)
    return {
      success: false,
      error: "Failed to process request",
      details: error instanceof Error ? error.message : String(error),
    }
  }
}

// Add this new function for appointment confirmation emails
export async function sendAppointmentConfirmationEmail(params: {
  patientEmail: string
  patientName: string
  doctorName: string
  appointmentType: string
  appointmentDate: string
  appointmentTime: string
}) {
  try {
    const { patientEmail, patientName, doctorName, appointmentType, appointmentDate, appointmentTime } = params
    const config = getEmailConfig()

    // Check if EMAIL_PASSWORD is available
    if (!config.available) {
      console.warn("EMAIL_PASSWORD environment variable is not set")

      // For demo purposes, log the email that would have been sent
      console.log(`[DEMO MODE] Appointment confirmation email would be sent to: ${patientEmail}`)
      console.log(`[DEMO MODE] Subject: Your CARDISENSE Appointment Confirmation`)
      console.log(`[DEMO MODE] Content: Appointment with Dr. ${doctorName} on ${appointmentDate} at ${appointmentTime}`)

      // Return a "success" response in development to avoid breaking the flow
      if (isDevelopment) {
        return {
          success: true,
          messageId: "mock-message-id",
          note: "Email not actually sent - missing EMAIL_PASSWORD, but would have been sent in production",
        }
      }
      return { success: false, error: "Email configuration is missing" }
    }

    // Generate the email HTML
    const emailHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #f8f9fa; padding: 20px; text-align: center;">
          <h1 style="color: #e91e63; margin: 0;">CARDISENSE</h1>
          <p style="color: #666; font-size: 14px;">Connecting humans with medical technology</p>
        </div>

        <div style="padding: 20px;">
          <h2 style="color: #333;">Appointment Confirmation</h2>
          <p>Dear ${patientName},</p>
          <p>
            Your appointment has been successfully scheduled. Here are the details:
          </p>

          <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-top: 20px;">
            <h3 style="color: #e91e63; margin-top: 0;">Appointment Details</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tbody>
                <tr>
                  <td style="padding: 8px 0; font-weight: bold;">Doctor:</td>
                  <td style="padding: 8px 0;">Dr. ${doctorName}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; font-weight: bold;">Type:</td>
                  <td style="padding: 8px 0;">${appointmentType}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; font-weight: bold;">Date:</td>
                  <td style="padding: 8px 0;">${appointmentDate}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; font-weight: bold;">Time:</td>
                  <td style="padding: 8px 0;">${appointmentTime}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div style="margin-top: 20px;">
            <p>
              Please arrive 15 minutes before your scheduled appointment time. If you need to reschedule or cancel,
              please do so at least 24 hours in advance.
            </p>
          </div>

          <div style="margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px;">
            <p>
              If you have any questions, please don't hesitate to contact our support team at
              <a href="mailto:support@cardisense.com" style="color: #e91e63;">
                support@cardisense.com
              </a>
              or call us at +91 9876543210.
            </p>
            <p>Thank you for choosing CARDISENSE for your healthcare needs.</p>
            <p>
              Warm regards,<br/>
              The CARDISENSE Team
            </p>
          </div>
        </div>

        <div style="background-color: #333; color: white; padding: 20px; text-align: center; font-size: 12px;">
          <p>© ${new Date().getFullYear()} CARDISENSE. All rights reserved.</p>
        </div>
      </div>
    `

    // Email options
    const mailOptions = {
      from: "CARDISENSE <asomatous.work@gmail.com>",
      to: patientEmail,
      subject: "Your CARDISENSE Appointment Confirmation",
      html: emailHtml,
    }

    try {
      // Create transporter and send email
      const transporter = createTransporter()
      const info = await transporter.sendMail(mailOptions)
      console.log("Appointment confirmation email sent successfully:", info.response)

      return { success: true, messageId: info.messageId }
    } catch (emailError) {
      console.error("Error sending appointment confirmation email:", emailError)

      // In development, return success anyway to not break the flow
      if (isDevelopment) {
        return {
          success: true,
          messageId: "mock-message-id",
          note: "Email not actually sent - error occurred, but would have been sent in production",
        }
      }

      return {
        success: false,
        error: "Failed to send email",
        details: emailError instanceof Error ? emailError.message : String(emailError),
      }
    }
  } catch (error) {
    console.error("Error in sendAppointmentConfirmationEmail:", error)
    return {
      success: false,
      error: "Failed to process request",
      details: error instanceof Error ? error.message : String(error),
    }
  }
}
