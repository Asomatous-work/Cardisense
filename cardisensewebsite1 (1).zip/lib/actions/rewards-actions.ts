"use server"

import { createServerSupabaseClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

interface CompleteSurveyParams {
  patientId: number
  surveyId: number
  responses: Record<string, string | number | boolean>
}

export async function completeSurvey(params: CompleteSurveyParams) {
  try {
    const { patientId, surveyId, responses } = params
    const supabase = createServerSupabaseClient()

    // First, check if the survey has already been completed
    const { data: existingResponse, error: checkError } = await supabase
      .from("survey_responses")
      .select("id")
      .eq("patient_id", patientId)
      .eq("survey_id", surveyId)
      .single()

    if (checkError && checkError.code !== "PGRST116") {
      // PGRST116 is the error code for "no rows returned" which is expected
      console.error("Error checking existing survey response:", checkError)
      return { success: false, error: checkError.message }
    }

    if (existingResponse) {
      return {
        success: false,
        error: "You have already completed this survey.",
      }
    }

    // Insert the survey response
    const { error: insertError } = await supabase.from("survey_responses").insert({
      patient_id: patientId,
      survey_id: surveyId,
      responses: responses,
      completed_at: new Date().toISOString(),
    })

    if (insertError) {
      console.error("Error inserting survey response:", insertError)
      return { success: false, error: insertError.message }
    }

    // Get the survey details to determine points
    const { data: survey, error: surveyError } = await supabase
      .from("surveys")
      .select("points_reward")
      .eq("id", surveyId)
      .single()

    if (surveyError) {
      console.error("Error fetching survey details:", surveyError)
      return { success: false, error: surveyError.message }
    }

    const pointsToAward = survey.points_reward || 50 // Default to 50 points if not specified

    // Award points to the patient
    const { error: pointsError } = await supabase.from("patient_rewards").insert({
      patient_id: patientId,
      points: pointsToAward,
      activity: "survey_completion",
      activity_id: surveyId,
      awarded_at: new Date().toISOString(),
    })

    if (pointsError) {
      console.error("Error awarding points:", pointsError)
      return { success: false, error: pointsError.message }
    }

    // Update the patient's total points
    const { data: patientData, error: patientError } = await supabase
      .from("patients")
      .select("total_points")
      .eq("id", patientId)
      .single()

    if (patientError) {
      console.error("Error fetching patient points:", patientError)
      return { success: false, error: patientError.message }
    }

    const currentPoints = patientData.total_points || 0
    const newTotalPoints = currentPoints + pointsToAward

    const { error: updateError } = await supabase
      .from("patients")
      .update({ total_points: newTotalPoints })
      .eq("id", patientId)

    if (updateError) {
      console.error("Error updating patient points:", updateError)
      return { success: false, error: updateError.message }
    }

    revalidatePath("/dashboard/rewards")

    return {
      success: true,
      pointsAwarded: pointsToAward,
      newTotalPoints,
      message: `Survey completed successfully! You earned ${pointsToAward} points.`,
    }
  } catch (error) {
    console.error("Error in completeSurvey:", error)
    return {
      success: false,
      error: "An unexpected error occurred while submitting your survey.",
    }
  }
}

export async function redeemReward(patientId: number, rewardId: number) {
  try {
    const supabase = createServerSupabaseClient()

    // Get the reward details
    const { data: reward, error: rewardError } = await supabase.from("rewards").select("*").eq("id", rewardId).single()

    if (rewardError) {
      console.error("Error fetching reward details:", rewardError)
      return { success: false, error: rewardError.message }
    }

    // Get the patient's current points
    const { data: patient, error: patientError } = await supabase
      .from("patients")
      .select("total_points")
      .eq("id", patientId)
      .single()

    if (patientError) {
      console.error("Error fetching patient points:", patientError)
      return { success: false, error: patientError.message }
    }

    // Check if the patient has enough points
    if (patient.total_points < reward.points_cost) {
      return {
        success: false,
        error: `You don't have enough points. This reward requires ${reward.points_cost} points.`,
      }
    }

    // Create a redemption record
    const { error: redemptionError } = await supabase.from("reward_redemptions").insert({
      patient_id: patientId,
      reward_id: rewardId,
      points_used: reward.points_cost,
      redeemed_at: new Date().toISOString(),
      status: "active",
      expiry_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
    })

    if (redemptionError) {
      console.error("Error creating redemption record:", redemptionError)
      return { success: false, error: redemptionError.message }
    }

    // Update the patient's total points
    const newTotalPoints = patient.total_points - reward.points_cost
    const { error: updateError } = await supabase
      .from("patients")
      .update({ total_points: newTotalPoints })
      .eq("id", patientId)

    if (updateError) {
      console.error("Error updating patient points:", updateError)
      return { success: false, error: updateError.message }
    }

    revalidatePath("/dashboard/rewards")

    return {
      success: true,
      rewardName: reward.name,
      pointsUsed: reward.points_cost,
      newTotalPoints,
      message: `You've successfully redeemed ${reward.name} for ${reward.points_cost} points!`,
    }
  } catch (error) {
    console.error("Error in redeemReward:", error)
    return {
      success: false,
      error: "An unexpected error occurred while redeeming your reward.",
    }
  }
}

export async function getAvailableCoupons(patientId: number) {
  try {
    const supabase = createServerSupabaseClient()

    const { data, error } = await supabase
      .from("reward_redemptions")
      .select(`
        id,
        points_used,
        redeemed_at,
        expiry_date,
        status,
        rewards (
          id,
          name,
          description,
          discount_amount,
          discount_type
        )
      `)
      .eq("patient_id", patientId)
      .eq("status", "active")
      .gte("expiry_date", new Date().toISOString())

    if (error) {
      console.error("Error fetching available coupons:", error)
      return { success: false, error: error.message }
    }

    return {
      success: true,
      coupons: data,
    }
  } catch (error) {
    console.error("Error in getAvailableCoupons:", error)
    return {
      success: false,
      error: "An unexpected error occurred while fetching your available coupons.",
    }
  }
}

export async function applyDiscountToAppointment(appointmentId: number, couponId: number) {
  try {
    const supabase = createServerSupabaseClient()

    // Get the coupon details
    const { data: redemption, error: redemptionError } = await supabase
      .from("reward_redemptions")
      .select(`
        id,
        status,
        rewards (
          id,
          name,
          discount_amount,
          discount_type
        )
      `)
      .eq("id", couponId)
      .single()

    if (redemptionError) {
      console.error("Error fetching coupon details:", redemptionError)
      return { success: false, error: redemptionError.message }
    }

    // Check if the coupon is still active
    if (redemption.status !== "active") {
      return {
        success: false,
        error: "This coupon has already been used or has expired.",
      }
    }

    // Get the appointment details
    const { data: appointment, error: appointmentError } = await supabase
      .from("appointments")
      .select("*")
      .eq("id", appointmentId)
      .single()

    if (appointmentError) {
      console.error("Error fetching appointment details:", appointmentError)
      return { success: false, error: appointmentError.message }
    }

    // Calculate the discount
    let discountAmount = 0
    const baseAmount = appointment.amount || 0

    if (redemption.rewards.discount_type === "percentage") {
      discountAmount = (baseAmount * redemption.rewards.discount_amount) / 100
    } else {
      discountAmount = redemption.rewards.discount_amount
    }

    // Make sure the discount doesn't exceed the appointment cost
    discountAmount = Math.min(discountAmount, baseAmount)

    // Update the appointment with the discount
    const { error: updateError } = await supabase
      .from("appointments")
      .update({
        discount_amount: discountAmount,
        discount_coupon_id: couponId,
        final_amount: baseAmount - discountAmount,
      })
      .eq("id", appointmentId)

    if (updateError) {
      console.error("Error applying discount to appointment:", updateError)
      return { success: false, error: updateError.message }
    }

    // Mark the coupon as used
    const { error: couponUpdateError } = await supabase
      .from("reward_redemptions")
      .update({ status: "used", used_at: new Date().toISOString() })
      .eq("id", couponId)

    if (couponUpdateError) {
      console.error("Error marking coupon as used:", couponUpdateError)
      // Continue even if this fails
    }

    revalidatePath("/dashboard/appointments")

    return {
      success: true,
      discountAmount,
      finalAmount: baseAmount - discountAmount,
      message: `Discount of ₹${discountAmount} applied successfully!`,
    }
  } catch (error) {
    console.error("Error in applyDiscountToAppointment:", error)
    return {
      success: false,
      error: "An unexpected error occurred while applying the discount.",
    }
  }
}
