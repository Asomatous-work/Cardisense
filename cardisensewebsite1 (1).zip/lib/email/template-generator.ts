"use server"

/**
 * Generates an HTML email template for insurance notifications
 * This approach avoids using React components for email templates
 */
export async function generateInsuranceEmailTemplate(data: {
  patientName: string
  insurancePlan: {
    name: string
    provider: string
    coverageAmount: number
    monthlyPremium: number
    description: string
    benefits: string[]
  }
  policyNumber: string
  startDate: string
  endDate: string
}): Promise<string> {
  const { patientName, insurancePlan, policyNumber, startDate, endDate } = data

  // Generate benefits list HTML
  const benefitsList = insurancePlan.benefits
    .map((benefit) => `<li style="margin-bottom: 5px;">${benefit}</li>`)
    .join("")

  // Return a plain HTML string template
  return `
   <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
     <div style="background-color: #f8f9fa; padding: 20px; text-align: center;">
       <h1 style="color: #e91e63; margin: 0;">CARDISENSE</h1>
       <p style="color: #666; font-size: 14px;">Connecting humans with medical technology</p>
     </div>

     <div style="padding: 20px;">
       <h2 style="color: #333;">Insurance Plan Confirmation</h2>
       <p>Dear ${patientName},</p>
       <p>
         Thank you for choosing CARDISENSE for your healthcare needs. We're pleased to confirm your insurance plan
         selection.
       </p>

       <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-top: 20px;">
         <h3 style="color: #e91e63; margin-top: 0;">Insurance Details</h3>
         <table style="width: 100%; border-collapse: collapse;">
           <tbody>
             <tr>
               <td style="padding: 8px 0; font-weight: bold;">Plan Name:</td>
               <td style="padding: 8px 0;">${insurancePlan.name}</td>
             </tr>
             <tr>
               <td style="padding: 8px 0; font-weight: bold;">Provider:</td>
               <td style="padding: 8px 0;">${insurancePlan.provider}</td>
             </tr>
             <tr>
               <td style="padding: 8px 0; font-weight: bold;">Policy Number:</td>
               <td style="padding: 8px 0;">${policyNumber}</td>
             </tr>
             <tr>
               <td style="padding: 8px 0; font-weight: bold;">Coverage Amount:</td>
               <td style="padding: 8px 0;">₹${insurancePlan.coverageAmount.toLocaleString()}</td>
             </tr>
             <tr>
               <td style="padding: 8px 0; font-weight: bold;">Monthly Premium:</td>
               <td style="padding: 8px 0;">₹${insurancePlan.monthlyPremium.toLocaleString()}</td>
             </tr>
             <tr>
               <td style="padding: 8px 0; font-weight: bold;">Coverage Period:</td>
               <td style="padding: 8px 0;">${startDate} to ${endDate}</td>
             </tr>
           </tbody>
         </table>
       </div>

       <div style="margin-top: 20px;">
         <h3 style="color: #e91e63;">Plan Benefits</h3>
         <ul style="padding-left: 20px;">
           ${benefitsList}
         </ul>
       </div>

       <div style="margin-top: 20px;">
         <h3 style="color: #e91e63;">Payment Information</h3>
         <p>
           Your first premium payment of ₹${insurancePlan.monthlyPremium.toLocaleString()} is due within 7 days. You can
           make the payment through the CARDISENSE dashboard or using the payment link below:
         </p>
         <div style="text-align: center; margin: 20px 0;">
           <a
             href="#"
             style="background-color: #e91e63; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;"
           >
             Make Payment
           </a>
         </div>
       </div>

       <div style="margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px;">
         <p>
           If you have any questions about your insurance plan or need assistance, please don't hesitate to contact our
           support team at
           <a href="mailto:support@cardisense.com" style="color: #e91e63;">
             support@cardisense.com
           </a>
           or call us at +91 9876543210.
         </p>
         <p>Thank you for trusting CARDISENSE with your healthcare needs.</p>
         <p>
           Warm regards,<br/>
           The CARDISENSE Team
         </p>
       </div>
     </div>

     <div style="background-color: #333; color: white; padding: 20px; text-align: center; font-size: 12px;">
       <p>© ${new Date().getFullYear()} CARDISENSE. All rights reserved.</p>
       <p>This email was sent to you because you selected an insurance plan through CARDISENSE.</p>
     </div>
   </div>
 `
}
