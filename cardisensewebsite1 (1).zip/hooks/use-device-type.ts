"use client"

import { useState, useEffect } from "react"
import { isDevelopment } from "@/lib/utils/env-fallbacks"

type DeviceType = "mobile" | "tablet" | "desktop" | "unknown"

export function useDeviceType() {
  const [deviceType, setDeviceType] = useState<DeviceType>("unknown")

  useEffect(() => {
    const detectDeviceType = () => {
      const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera

      // Check if iOS device
      const isIOSDevice = /iPad|iPhone|iPod/.test(userAgent) && !(window as any).MSStream

      // Check if Android device
      const isAndroidDevice = /android/i.test(userAgent)

      // Check if macOS device
      const isMacOSDevice = /Macintosh/.test(userAgent) && !isIOSDevice

      // Check if Windows device
      const isWindowsDevice = /Windows/.test(userAgent)

      // Only log in development mode
      if (isDevelopment) {
        console.log("Device detection:", {
          isIOSDevice,
          isAndroidDevice,
          isMacOSDevice,
          isWindowsDevice,
        })
      }

      // Detect standalone mode
      const mediaQuery = window.matchMedia("(display-mode: standalone)").matches
      const androidApp = document.referrer.includes("android-app://")
      const webView = userAgent.includes("wv") || userAgent.includes("CARDISENSE")

      // Only log in development mode
      if (isDevelopment) {
        console.log("Standalone detection:", {
          mediaQuery,
          androidApp,
          webView,
          userAgent,
        })
      }

      // Determine device type based on screen width
      const width = window.innerWidth
      if (width < 768) {
        setDeviceType("mobile")
      } else if (width < 1024) {
        setDeviceType("tablet")
      } else {
        setDeviceType("desktop")
      }
    }

    detectDeviceType()
    window.addEventListener("resize", detectDeviceType)

    return () => {
      window.removeEventListener("resize", detectDeviceType)
    }
  }, [])

  return { deviceType }
}
